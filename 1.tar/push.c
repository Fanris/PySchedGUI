/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function pushes the particles in check collision with walls
 ******************************************************************************/
void PushParticles(GRID *Grid, SPECIES *Species)
{
	int_m i;
	int_m GridPoint;
	float_m Distance;
	float_m Position;
	float_m Velocity;
	float_m VelocityT;
	float_m VelocityN;
	float_m Energy;
	float_m Angle;
	float_m DeltaEnergy;
	float_m DeltaAngle;
	int_m EnergyBin;
	int_m AngleBin;
	float_m Temp;
	int_m NumberParticles;
	int_m WallNumber;
	int_m WallIndex[2*MaxNumberSuperParticlesPerCell];
	int_m NLeft, NCenter, NRight;
	
	float_m PositionAverage;
	
	NLeft=0.0;
	NCenter=0.0;
	NRight=0.0;
	
	for (i = 0; i < NumberGridPoints; i++)
	{
		(*Species).Electrons.Flux1[i] = 0.0;
		(*Species).Ions.Flux1[i] = 0.0;
	}
	
	
	QConvOld = QConv;
	/*if (CurrentSourceFlag == 1) QConvNew = 0.0;*/
	
	/* Cartesian grid */
	if (CoordinateSystem == 0)
	{
		/* Push electrons */
		NumberParticles = (*Species).Electrons.Number;
		WallNumber = 0;
		memset( WallIndex, 0, sizeof( WallIndex ) );

	/*	#pragma omp parallel for private(Position,Velocity,GridPoint,Distance,Temp)*/
		for (i = 0; i < NumberParticles; i++)
		{
			Position = (*Species).Electrons.Position[i];
			Velocity = (*Species).Electrons.Velocity1[i];
			/* GridPoint left from the ith particle */
			GridPoint = (int_m) ( Position / DeltaX );
			/* Distance between GridPoint and the ith particle */
			Distance = Position - (float_m) GridPoint * DeltaX;

			/* New Velocity of the ith particle */
			Temp =  (*Grid).ElectricField1[GridPoint] 
				- Distance/DeltaX * (*Grid).ElectricField1[GridPoint] 
				+ Distance/DeltaX * (*Grid).ElectricField1[GridPoint + 1];
			Temp *= DeltaT * (*Species).Electrons.Charge 
				/ (*Species).Electrons.Mass;
			Velocity += Temp;
			/* New Position */
			Position += DeltaT * Velocity;
			(*Species).Electrons.PositionOld[i] = (*Species).Electrons.Position[i];			
			(*Species).Electrons.Position[i] = Position;			
			(*Species).Electrons.Velocity1[i] = Velocity;
			
			/* Calculating electron flux */
			PositionAverage = ( (*Species).Electrons.Position[i]
							   + (*Species).Electrons.PositionOld[i] ) / 2.0;
	/*		if (PositionAverage > GapSize) PositionAverage = (*Species).Electrons.PositionOld[i] 
				+ (GapSize - (*Species).Electrons.PositionOld[i] )/ 2.0;*/
			if (PositionAverage >= 0  && PositionAverage <= GapSize)
			{
				GridPoint = (int_m) ( PositionAverage / DeltaX );			
				Distance = PositionAverage
					/ DeltaX - (float_m) GridPoint;
				/* Left node */
				Temp = (*Species).Electrons.Flux1[GridPoint];
				Temp += (1.0 - Distance) * Weight
					* (*Species).Electrons.Velocity1[i];
				(*Species).Electrons.Flux1[GridPoint] = Temp;
				/* Right node */
				Temp = (*Species).Electrons.Flux1[GridPoint+1];
				Temp += Distance * Weight
					* (*Species).Electrons.Velocity1[i] ;
				(*Species).Electrons.Flux1[GridPoint + 1] = Temp;
			}
			
			/* Calculating the EEDFs */
			if (EEDFReportFlag == 1
				&& TimeStep >= (int_m)NumberTimeStepsStartLastPeriodsEEDF ) 
			{
				/* Left EEDF */
				if ( Position >= LeftGridPointEEDFLeft * DeltaX
					&& Position <=  RightGridPointEEDFLeft * DeltaX)
				{
					Temp = (*Species).Electrons.Velocity1[i] * (*Species).Electrons.Velocity1[i]
						+ (*Species).Electrons.Velocity2[i] * (*Species).Electrons.Velocity2[i]
						+ (*Species).Electrons.Velocity3[i] * (*Species).Electrons.Velocity3[i];
					Energy = 0.5 * Temp 
						* ElectronMass / ElementaryCharge;
					if (Energy > (float_m)MaximumElectronEnergy)
						Energy = (float_m)MaximumElectronEnergy;
					EnergyBin = (int_m)(Energy/ElectronEnergyBinWidth);
					DeltaEnergy = (Energy/ElectronEnergyBinWidth - (float_m)EnergyBin);
					EEDFLeft[EnergyBin] += (1.0 - DeltaEnergy)*InitialPlasmaDensity*GapSize
						/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
					EEDFLeft[EnergyBin+1] += DeltaEnergy*InitialPlasmaDensity*GapSize
						/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
				}									
				/* Center EEDF */
				if ( Position >= LeftGridPointEEDFCenter * DeltaX 
					&& Position <=  RightGridPointEEDFCenter * DeltaX)
				{
					Temp = (*Species).Electrons.Velocity1[i] * (*Species).Electrons.Velocity1[i]
						+ (*Species).Electrons.Velocity2[i] * (*Species).Electrons.Velocity2[i]
						+ (*Species).Electrons.Velocity3[i] * (*Species).Electrons.Velocity3[i];
					Energy = 0.5 * Temp 
						* ElectronMass / ElementaryCharge;
					if (Energy > (float_m)MaximumElectronEnergy)
						Energy = (float_m)MaximumElectronEnergy;
					EnergyBin = (int_m)(Energy/ElectronEnergyBinWidth);
					DeltaEnergy = (Energy/ElectronEnergyBinWidth - (float_m)EnergyBin);
					EEDFCenter[EnergyBin] += (1.0 - DeltaEnergy)*InitialPlasmaDensity*GapSize
						/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
					EEDFCenter[EnergyBin+1] += DeltaEnergy*InitialPlasmaDensity*GapSize
						/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
				}
				/* Right EEDF */
				if ( Position >= LeftGridPointEEDFRight * DeltaX
					&& Position <= RightGridPointEEDFRight * DeltaX)
				{
					Temp = (*Species).Electrons.Velocity1[i] * (*Species).Electrons.Velocity1[i]
						+ (*Species).Electrons.Velocity2[i] * (*Species).Electrons.Velocity2[i]
						+ (*Species).Electrons.Velocity3[i] * (*Species).Electrons.Velocity3[i];
					Energy = 0.5 * Temp 
						* ElectronMass / ElementaryCharge;
					if (Energy > (float_m)MaximumElectronEnergy)
						Energy = (float_m)MaximumElectronEnergy;
					EnergyBin = (int_m)(Energy/ElectronEnergyBinWidth);
					DeltaEnergy = (Energy/ElectronEnergyBinWidth - (float_m)EnergyBin);
					EEDFRight[EnergyBin] += (1.0 - DeltaEnergy)*InitialPlasmaDensity*GapSize
						/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
					EEDFRight[EnergyBin+1] += DeltaEnergy*InitialPlasmaDensity*GapSize
						/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
				}	
			}

			/* Check collisions of particles with wall */
			if (Position <= 0.0 || Position >= GapSize)
			{
				if ( BoundaryReflectionFlag
				&& (RandomNumber() <= ReflectedElectronGamma) )
				{
				/* Do the reflection of electrons from the electrode */
					if (Position <= 0.0) (*Species).Electrons.Position[i] 
						= (*Grid).Position[1];
					if (Position >= GapSize) (*Species).Electrons.Position[i] 
						= (*Grid).Position[NumberGridPoints-2];
					(*Species).Electrons.Velocity1[i] *= -1.0;	
				}
				else
				{
					if (Position <= 0.0) QConv += (*Species).Electrons.Charge
						* DeltaX*InnerElectrodeArea*Weight;
				
					WallIndex[WallNumber] = i;
					WallNumber +=1;
				}
			}
		}
		
		/* Remove electrons which hit the wall */
		for ( i = WallNumber-1; i >= 0; i--) 
		{
			(*Species).Electrons.Position[WallIndex[i]] 
				= (*Species).Electrons.Position[NumberParticles-1];
			(*Species).Electrons.PositionOld[WallIndex[i]] 
				= (*Species).Electrons.PositionOld[NumberParticles-1];
			(*Species).Electrons.Velocity1[WallIndex[i]] 
				= (*Species).Electrons.Velocity1[NumberParticles-1];
			(*Species).Electrons.Velocity2[WallIndex[i]] 
				= (*Species).Electrons.Velocity2[NumberParticles-1];
			(*Species).Electrons.Velocity3[WallIndex[i]] 
				= (*Species).Electrons.Velocity3[NumberParticles-1];
			NumberParticles -= 1;		
		}
		(*Species).Electrons.Number = NumberParticles;
		
		/* Push ions */
		NumberParticles = (*Species).Ions.Number;
		WallNumber = 0;
		memset( WallIndex, 0, sizeof( WallIndex ) );
	
		for (i = 0; i < NumberParticles; i++)
		{
			Position = (*Species).Ions.Position[i];
			Velocity = (*Species).Ions.Velocity1[i];
			/* GridPoint left from the ith particle */
			GridPoint = (int_m) ( Position / DeltaX );
			/* Distance between GridPoint and the ith particle */
			Distance = Position - (float_m) GridPoint * DeltaX;
			/* New Velocity of the ith particle */
			Temp =  (*Grid).ElectricField1[GridPoint] 
				- Distance/DeltaX * (*Grid).ElectricField1[GridPoint] 
				+ Distance/DeltaX * (*Grid).ElectricField1[GridPoint + 1];
			Temp *= DeltaT * (*Species).Ions.Charge / (*Species).Ions.Mass;
			Velocity += Temp;
			/* New Position */
			Position += DeltaT * Velocity;
			(*Species).Ions.PositionOld[i] = (*Species).Ions.Position[i];
			(*Species).Ions.Position[i] = Position;		
			(*Species).Ions.Velocity1[i] = Velocity;
			
			/* Calculating ion flux */
			PositionAverage = ((*Species).Ions.Position[i]
							   + (*Species).Ions.PositionOld[i] ) / 2.0;
	/*		if (PositionAverage < 0) PositionAverage=0.0;*/
			if (PositionAverage >= 0  && PositionAverage <= GapSize)
			{
				GridPoint = (int_m) ( PositionAverage / DeltaX );
				Distance = PositionAverage
					/ DeltaX - (float_m) GridPoint;
				/* Left node */
				Temp = (*Species).Ions.Flux1[GridPoint];
				Temp += (1.0 - Distance) * Weight
					* (*Species).Ions.Velocity1[i];
				(*Species).Ions.Flux1[GridPoint] = Temp;
				/* Right node */
				Temp = (*Species).Ions.Flux1[GridPoint+1];
				Temp += Distance * Weight
					* (*Species).Ions.Velocity1[i];
				(*Species).Ions.Flux1[GridPoint + 1] = Temp;			
			}			
			
			/* Check collisions of particles with wall */
			if (Position <= 0.0 || Position >= GapSize)
			{
				if ( BoundaryReflectionFlag
				&& (RandomNumber() <= ReflectedIonGamma) )
				{
					/* Do the reflection of ions from the electrode */
					if (Position <= 0.0) (*Species).Ions.Position[i] 
						= (*Grid).Position[1];
					if (Position >= GapSize) (*Species).Ions.Position[i] 
						= (*Grid).Position[NumberGridPoints-2];
					(*Species).Ions.Velocity1[i] *= -1.0;	
				}
				else
				{
					/* Count particles for charging external capacitance */
					if (Position <= 0.0) QConv += (*Species).Ions.Charge 
						* DeltaX*InnerElectrodeArea*Weight;
					/* Count particles for secondary electron emission */
					if (Position <= 0.0) NumberSecondaryElectronsLeft += 1;
					if (Position >= GapSize) NumberSecondaryElectronsRight += 1;					
					/* Calculate IEDF */
					if (IEDFReportFlag == 1
						&& TimeStep >= (int_m)NumberTimeStepsStartLastPeriodsIEDF ) 
					{
						if (Position <= 0.0)
						{
							VelocityT = (*Species).Ions.Velocity2[i] 
								* (*Species).Ions.Velocity2[i] 
								+ (*Species).Ions.Velocity3[i] 
								* (*Species).Ions.Velocity3[i];
							VelocityN = (*Species).Ions.Velocity1[i];	
							Energy = 0.5 * Velocity * Velocity 
								* (*Species).Ions.Mass / (*Species).Ions.Charge;
							if (Energy > (float_m)MaximumIonEnergy) Energy 
								= (float_m)MaximumIonEnergy;
							EnergyBin = (int_m)(Energy / IonEnergyBinWidth);
							DeltaEnergy = (Energy/IonEnergyBinWidth - (float_m)EnergyBin);
							Angle = atan( sqrt(VelocityT) / abs(VelocityN) + 1E-5) 
								* ( 90 / ( 0.5 * Pi) );
							AngleBin = (int_m)(Angle/IonAngleBinWidth);
							DeltaAngle = (Angle/IonAngleBinWidth - (float_m)AngleBin);
							IEDFLeft[EnergyBin][AngleBin] 
								+= (1.0 - DeltaEnergy) + (1.0 - DeltaAngle);
							IEDFLeft[EnergyBin + 1][AngleBin +1] 
								+= DeltaEnergy + DeltaAngle;
				/*			printf("%e \t %ld \t %e \t %e \n",Energy, EnergyBin, (DeltaEnergy), (1.0 - DeltaEnergy));*/
						}
						else if (Position >= GapSize)
						{
							VelocityT = (*Species).Ions.Velocity2[i] 
								* (*Species).Ions.Velocity2[i] 
								+ (*Species).Ions.Velocity3[i] 
								* (*Species).Ions.Velocity3[i];
							VelocityN = (*Species).Ions.Velocity1[i];	
							Energy = 0.5 * Velocity * Velocity 
								* (*Species).Ions.Mass / (*Species).Ions.Charge;
							if (Energy > (float_m)MaximumIonEnergy) Energy 
								= (float_m)MaximumIonEnergy;
							EnergyBin = (int_m)(Energy / IonEnergyBinWidth);
							DeltaEnergy = (Energy/IonEnergyBinWidth - (float_m)EnergyBin);
							Angle = atan( sqrt(VelocityT) / abs(VelocityN) + 1E-5) 
							* ( 90 / ( 0.5 * Pi) );
							AngleBin = (int_m)(Angle/IonAngleBinWidth);
							DeltaAngle = (Angle/IonAngleBinWidth - (float_m)AngleBin);
							IEDFRight[EnergyBin][AngleBin] 
								+= (1.0 - DeltaEnergy) + (1.0 - DeltaAngle);
							IEDFRight[EnergyBin + 1][AngleBin +1] 
								+= DeltaEnergy + DeltaAngle;	
						}
					}
					WallIndex[WallNumber] = i;
					WallNumber +=1;
				}
			}
		}

	
		/* Remove ions which hit the wall */
		for ( i = WallNumber-1; i >= 0; i--) 
		{
			(*Species).Ions.Position[WallIndex[i]] 
				= (*Species).Ions.Position[NumberParticles-1];
			(*Species).Ions.PositionOld[WallIndex[i]] 
				= (*Species).Ions.PositionOld[NumberParticles-1];
			(*Species).Ions.Velocity1[WallIndex[i]] 
				= (*Species).Ions.Velocity1[NumberParticles-1];
			(*Species).Ions.Velocity2[WallIndex[i]] 
				= (*Species).Ions.Velocity2[NumberParticles-1];
			(*Species).Ions.Velocity3[WallIndex[i]] 
				= (*Species).Ions.Velocity3[NumberParticles-1];
			NumberParticles -= 1;
		}
		(*Species).Ions.Number = NumberParticles;		
	}
	else if (CoordinateSystem==1)
	{			
		/* Push electrons */
		NumberParticles = (*Species).Electrons.Number;
		WallNumber = 0;
		memset( WallIndex, 0, sizeof( WallIndex ) );
		for (i = 0; i < NumberParticles; i++)
		{
			Position = (*Species).Electrons.Position[i];
			Velocity = (*Species).Electrons.Velocity1[i];
			/* GridPoint left from the ith particle */
			GridPoint = (int_m) ( (Position-InnerElectrodeRadius) / DeltaX );
			/* Distance between GridPoint and the ith particle */
			Distance = (Position-InnerElectrodeRadius) 
				- (float_m) GridPoint * DeltaX;
						
			/* New Velocity of the ith particle */
			Temp =  (*Grid).ElectricField1[GridPoint] 
				- Distance/DeltaX * (*Grid).ElectricField1[GridPoint] 
				+ Distance/DeltaX * (*Grid).ElectricField1[GridPoint + 1];
			Temp *= DeltaT * (*Species).Electrons.Charge 
				/ (*Species).Electrons.Mass;
			Velocity += Temp;
			/* New Position */
			Position += DeltaT * Velocity;
			(*Species).Electrons.PositionOld[i] = (*Species).Electrons.Position[i];		
			(*Species).Electrons.Position[i] = Position;
			(*Species).Electrons.Velocity1[i] = Velocity;
			
		
			
			/* Calculating electron flux */
			PositionAverage = ( (*Species).Electrons.Position[i]
							   + (*Species).Electrons.PositionOld[i] ) / 2.0;
			/*		if (PositionAverage > GapSize) PositionAverage = (*Species).Electrons.PositionOld[i] 
			 + (GapSize - (*Species).Electrons.PositionOld[i] )/ 2.0;*/

			if (PositionAverage >= InnerElectrodeRadius  && PositionAverage <= InnerElectrodeRadius+GapSize)
			{
				GridPoint = (int_m) ( (PositionAverage-InnerElectrodeRadius) / DeltaX );
				/* Distance between GridPoint and the ith particle */
				Distance = (PositionAverage-InnerElectrodeRadius) 
				- (float_m) GridPoint * DeltaX;

			
				/* Left node */
				Temp = (*Species).Electrons.Flux1[GridPoint];
				Temp += (1.0 - Distance) * SphericalWeight[GridPoint]
				* (*Species).Electrons.Velocity1[i];
				(*Species).Electrons.Flux1[GridPoint] = Temp;
				
				
				/* Right node */
				Temp = (*Species).Electrons.Flux1[GridPoint+1];
				Temp += Distance * SphericalWeight[GridPoint+1]
				* (*Species).Electrons.Velocity1[i] ;
				(*Species).Electrons.Flux1[GridPoint + 1] = Temp;
	
			}
			
			
			
			
			
			
			
			/* Calculating the EEDFs */
			if (EEDFReportFlag == 1
				&& TimeStep >= (int_m)NumberTimeStepsStartLastPeriodsEEDF ) 
			{
				/* Left EEDF */
				if ( Position >= LeftGridPointEEDFLeft * DeltaX + InnerElectrodeRadius
					&& Position <=  RightGridPointEEDFLeft * DeltaX + InnerElectrodeRadius)
				{
					Temp = (*Species).Electrons.Velocity1[i] * (*Species).Electrons.Velocity1[i]
						+ (*Species).Electrons.Velocity2[i] * (*Species).Electrons.Velocity2[i]
						+ (*Species).Electrons.Velocity3[i] * (*Species).Electrons.Velocity3[i];
					Energy = 0.5 * Temp 
						* ElectronMass / ElementaryCharge;
					if (Energy > (float_m)MaximumElectronEnergy)
						Energy = (float_m)MaximumElectronEnergy;
					EnergyBin = (int_m)(Energy/ElectronEnergyBinWidth);
					DeltaEnergy = (Energy/ElectronEnergyBinWidth - (float_m)EnergyBin);
					EEDFLeft[EnergyBin] += (1.0 - DeltaEnergy) /NumberTimeStepsLastPeriodsEEDF;
					EEDFLeft[EnergyBin+1] += DeltaEnergy /NumberTimeStepsLastPeriodsEEDF;
				}									
				/* Center EEDF */
				if ( Position >= LeftGridPointEEDFCenter * DeltaX + InnerElectrodeRadius
					&& Position <=  RightGridPointEEDFCenter * DeltaX + InnerElectrodeRadius)
				{
					Temp = (*Species).Electrons.Velocity1[i] * (*Species).Electrons.Velocity1[i]
						+ (*Species).Electrons.Velocity2[i] * (*Species).Electrons.Velocity2[i]
						+ (*Species).Electrons.Velocity3[i] * (*Species).Electrons.Velocity3[i];
					Energy = 0.5 * Temp 
						* ElectronMass / ElementaryCharge;
					if (Energy > (float_m)MaximumElectronEnergy)
						Energy = (float_m)MaximumElectronEnergy;
					EnergyBin = (int_m)(Energy/ElectronEnergyBinWidth);
					DeltaEnergy = (Energy/ElectronEnergyBinWidth - (float_m)EnergyBin);
					EEDFCenter[EnergyBin] += (1.0 - DeltaEnergy)/NumberTimeStepsLastPeriodsEEDF;
					EEDFCenter[EnergyBin+1] += DeltaEnergy/NumberTimeStepsLastPeriodsEEDF;
				}
				/* Right EEDF */
				if ( Position >= LeftGridPointEEDFRight * DeltaX + InnerElectrodeRadius
					&& Position <= RightGridPointEEDFRight * DeltaX + InnerElectrodeRadius)
				{
					Temp = (*Species).Electrons.Velocity1[i] * (*Species).Electrons.Velocity1[i]
						+ (*Species).Electrons.Velocity2[i] * (*Species).Electrons.Velocity2[i]
						+ (*Species).Electrons.Velocity3[i] * (*Species).Electrons.Velocity3[i];
					Energy = 0.5 * Temp 
						* ElectronMass / ElementaryCharge;
					if (Energy > (float_m)MaximumElectronEnergy)
						Energy = (float_m)MaximumElectronEnergy;
					EnergyBin = (int_m)(Energy/ElectronEnergyBinWidth);
					DeltaEnergy = (Energy/ElectronEnergyBinWidth - (float_m)EnergyBin);
					EEDFRight[EnergyBin] += (1.0 - DeltaEnergy)/NumberTimeStepsLastPeriodsEEDF;
					EEDFRight[EnergyBin+1] += DeltaEnergy/NumberTimeStepsLastPeriodsEEDF;
				}	
			}			
			
			/* Check collisions of particles with wall */
			if (Position <= InnerElectrodeRadius 
				|| Position >= InnerElectrodeRadius+GapSize)
			{
				if ( BoundaryReflectionFlag
				&& (RandomNumber() <= ReflectedElectronGamma) )
				{
					/* Do the reflection of electrons from the electrode */
					if (Position <= InnerElectrodeRadius) 
						(*Species).Electrons.Position[i] 
						= (*Grid).Position[1];
					if (Position >= InnerElectrodeRadius+GapSize) 
						(*Species).Electrons.Position[i] 
						= (*Grid).Position[NumberGridPoints-2];
					(*Species).Electrons.Velocity1[i] *= -1.0;	
				}
				else
				{
					if (Position <= InnerElectrodeRadius) 
						QConv += (*Species).Electrons.Charge
						* DeltaX*(4.0*Pi*InnerElectrodeRadius*InnerElectrodeRadius)*SphericalWeight[0];
					WallIndex[WallNumber] = i;
					WallNumber +=1;
				}
			}
		}
		/* Remove electrons which hit the wall */
		for ( i = WallNumber-1; i >= 0; i--) 
		{
			(*Species).Electrons.Position[WallIndex[i]] 
				= (*Species).Electrons.Position[NumberParticles-1];
			(*Species).Electrons.Velocity1[WallIndex[i]] 
				= (*Species).Electrons.Velocity1[NumberParticles-1];
			(*Species).Electrons.Velocity2[WallIndex[i]] 
				= (*Species).Electrons.Velocity2[NumberParticles-1];
			(*Species).Electrons.Velocity3[WallIndex[i]] 
				= (*Species).Electrons.Velocity3[NumberParticles-1];
			NumberParticles -= 1;		
		}
		(*Species).Electrons.Number = NumberParticles;
		
		/* Push ions */
		NumberParticles = (*Species).Ions.Number;
		WallNumber = 0;
		memset( WallIndex, 0, sizeof( WallIndex ) );
		for (i = 0; i < NumberParticles; i++)
		{
			Position = (*Species).Ions.Position[i];
			Velocity = (*Species).Ions.Velocity1[i];
			/* GridPoint left from the ith particle */
			GridPoint = (int_m) ( (Position-InnerElectrodeRadius) / DeltaX );
			/* Distance between GridPoint and the ith particle */
			Distance = (Position-InnerElectrodeRadius) 
				- (float_m) GridPoint * DeltaX;
			/* New Velocity of the ith particle */
			Temp =  (*Grid).ElectricField1[GridPoint] 
				- Distance/DeltaX * (*Grid).ElectricField1[GridPoint] 
				+ Distance/DeltaX * (*Grid).ElectricField1[GridPoint + 1];
			Temp *= DeltaT * (*Species).Ions.Charge / (*Species).Ions.Mass;
			Velocity += Temp;
			/* New Position */
			Position += DeltaT * Velocity;
			
			(*Species).Ions.PositionOld[i] = (*Species).Ions.Position[i];			
			(*Species).Ions.Position[i] = Position;
			(*Species).Ions.Velocity1[i] = Velocity;
			
			

			
			
			
			/* Calculating ion flux */
			PositionAverage = ((*Species).Ions.Position[i]
							   + (*Species).Ions.PositionOld[i] ) / 2.0;
			/*		if (PositionAverage < 0) PositionAverage=0.0;*/
			if (PositionAverage >= InnerElectrodeRadius  && PositionAverage <= InnerElectrodeRadius+GapSize)
			{
				GridPoint = (int_m) ( (PositionAverage-InnerElectrodeRadius) / DeltaX );
				/* Distance between GridPoint and the ith particle */
				Distance = (PositionAverage-InnerElectrodeRadius) 
				- (float_m) GridPoint * DeltaX;
				
				/* Left node */
				Temp = (*Species).Ions.Flux1[GridPoint];
				Temp += (1.0 - Distance) * SphericalWeight[GridPoint]
				* (*Species).Ions.Velocity1[i];
				(*Species).Ions.Flux1[GridPoint] = Temp;
				/* Right node */
				Temp = (*Species).Ions.Flux1[GridPoint+1];
				Temp += Distance * SphericalWeight[GridPoint]
				* (*Species).Ions.Velocity1[i];
				(*Species).Ions.Flux1[GridPoint + 1] = Temp;			
			}			
			
			
			
			
			
			/* Check collisions of particles with wall */
			if (Position <= InnerElectrodeRadius 
				|| Position >= InnerElectrodeRadius+GapSize)
			{
				/* Count particles for charging external capacitance */
				if (Position <= InnerElectrodeRadius) 
					QConv += (*Species).Ions.Charge 
						* DeltaX*(4.0*Pi*InnerElectrodeRadius*InnerElectrodeRadius)*SphericalWeight[0];
				/* Count particles for secondary electron emission */
				if (Position <= InnerElectrodeRadius) 
					NumberSecondaryElectronsLeft += 1;
				if (Position >= InnerElectrodeRadius+GapSize) 
					NumberSecondaryElectronsRight += 1;				
				/* Calculate IEDF */
				if (IEDFReportFlag == 1
					&& TimeStep >= (int_m)NumberTimeStepsStartLastPeriodsIEDF) 
				{
					if (Position <= InnerElectrodeRadius)
					{
						VelocityT = (*Species).Ions.Velocity2[i] 
							* (*Species).Ions.Velocity2[i] 
							+ (*Species).Ions.Velocity3[i] 
							* (*Species).Ions.Velocity3[i];
						VelocityN = (*Species).Ions.Velocity1[i];	
						Energy = 0.5 * Velocity * Velocity 
							* (*Species).Ions.Mass / (*Species).Ions.Charge;
						if (Energy > (float_m)MaximumIonEnergy) Energy 
							= (float_m)MaximumIonEnergy;
						EnergyBin = (int_m)(Energy / IonEnergyBinWidth);
						DeltaEnergy = (Energy/IonEnergyBinWidth - (float_m)EnergyBin);
						Angle = atan( sqrt(VelocityT) / abs(VelocityN) + 1E-5) 
							* ( 90 / ( 0.5 * Pi) );
						AngleBin = (int_m)(Angle/IonAngleBinWidth);
						DeltaAngle = (Angle/IonAngleBinWidth - (float_m)AngleBin);
						IEDFLeft[EnergyBin][AngleBin] 
							+= (1.0 - DeltaEnergy) + (1.0 - DeltaAngle);
						IEDFLeft[EnergyBin + 1][AngleBin +1] 
							+= DeltaEnergy + DeltaAngle;
					}
					else if (Position >= InnerElectrodeRadius+GapSize)
					{
						VelocityT = (*Species).Ions.Velocity2[i] 
							* (*Species).Ions.Velocity2[i] 
							+ (*Species).Ions.Velocity3[i] 
							* (*Species).Ions.Velocity3[i];
						VelocityN = (*Species).Ions.Velocity1[i];	
						Energy = 0.5 * Velocity * Velocity 
							* (*Species).Ions.Mass / (*Species).Ions.Charge;
						if (Energy > (float_m)MaximumIonEnergy) Energy 
							= (float_m)MaximumIonEnergy;
						EnergyBin = (int_m)(Energy / IonEnergyBinWidth);
						DeltaEnergy = (Energy/IonEnergyBinWidth - (float_m)EnergyBin);
						Angle = atan( sqrt(VelocityT) / abs(VelocityN) + 1E-5) 
							* ( 90 / ( 0.5 * Pi) );
						AngleBin = (int_m)(Angle/IonAngleBinWidth);
						DeltaAngle = (Angle/IonAngleBinWidth - (float_m)AngleBin);
						IEDFRight[EnergyBin][AngleBin] 
							+= (1.0 - DeltaEnergy) + (1.0 - DeltaAngle);
						IEDFRight[EnergyBin + 1][AngleBin +1] 
							+= DeltaEnergy + DeltaAngle;
					}
				}
				WallIndex[WallNumber] = i;
				WallNumber +=1;
			}
		}
		/* Remove ions which hit the wall */
		for ( i = WallNumber-1; i >= 0; i--) 
		{
			(*Species).Ions.Position[WallIndex[i]] 
				= (*Species).Ions.Position[NumberParticles-1];
			(*Species).Ions.Velocity1[WallIndex[i]] 
				= (*Species).Ions.Velocity1[NumberParticles-1];
			(*Species).Ions.Velocity2[WallIndex[i]] 
				= (*Species).Ions.Velocity2[NumberParticles-1];
			(*Species).Ions.Velocity3[WallIndex[i]] 
				= (*Species).Ions.Velocity3[NumberParticles-1];
			NumberParticles -= 1;
		}
		(*Species).Ions.Number = NumberParticles;
	}
	else if (CoordinateSystem == 2)
	{			
	}
	
	(*Species).Electrons.Flux1[0] *= 2.0;
	(*Species).Electrons.Flux1[NumberGridPoints-1] *= 2.0;
	(*Species).Ions.Flux1[0] *= 2.0;
	(*Species).Ions.Flux1[NumberGridPoints-1] *= 2.0;

 }

/*******************************************************************************
 * Function pushes the particles with magnetic field in check collision with walls
 ******************************************************************************/
void BorisPushParticles(GRID *Grid, SPECIES *Species)
{
	int_m i;
	int_m GridPoint;
	float_m Distance;
	float_m Position;
	float_m Velocity1;
	float_m Velocity2;
	float_m Velocity3;
	float_m VelocityT;
	float_m VelocityN;
	float_m Energy;
	float_m Angle;
	float_m DeltaEnergy;
	float_m DeltaAngle;
	int_m EnergyBin;
	int_m AngleBin;
	float_m TempU1;
	float_m TempU2;
	float_m TempU3;
	float_m TempE1;
	float_m TempB1;
	float_m TempB2;
	float_m TempB3;
	float_m CoefficientFields;
	float_m CoefficientPusher;
	int_m NumberParticles;
	int_m WallNumber;
	int_m WallIndex[2*MaxNumberSuperParticlesPerCell];
	float_m Temp;
	float PositionAverage;
	
	QConvOld = QConv;
	
	for (i = 0; i < NumberGridPoints; i++)
	{
		(*Species).Electrons.Flux1[i] = 0.0;
		(*Species).Ions.Flux1[i] = 0.0;
	}
	
	/* Cartesian grid */
	if (CoordinateSystem == 0)
	{
		/* Push electrons */
		NumberParticles = (*Species).Electrons.Number;
		WallNumber = 0;
		memset( WallIndex, 0, sizeof( WallIndex ) );
		/* Coefficient to normalize fields */
		CoefficientFields = DeltaT * (*Species).Electrons.Charge
		/ 2.0 / (*Species).Electrons.Mass;
		for (i = 0; i < NumberParticles; i++)
		{
			Position = (*Species).Electrons.Position[i];
			Velocity1 = (*Species).Electrons.Velocity1[i];
			Velocity2 = (*Species).Electrons.Velocity2[i];
			Velocity3 = (*Species).Electrons.Velocity3[i];
			/* GridPoint left from the ith particle */
			GridPoint = (int_m) ( Position / DeltaX );
			/* Distance between GridPoint and the ith particle */
			Distance = Position - (float_m) GridPoint * DeltaX;
			/* Normalized electric field */
			TempE1 = (*Grid).ElectricField1[GridPoint] + Distance/DeltaX * 
			( - (*Grid).ElectricField1[GridPoint] 
			 + (*Grid).ElectricField1[GridPoint + 1] );
			TempE1 *= CoefficientFields;
			/* Normalized magnetic field */
			TempB1 = (*Grid).MagneticField1[GridPoint] + Distance/DeltaX * 
			( - (*Grid).MagneticField1[GridPoint] 
			 + (*Grid).MagneticField1[GridPoint + 1] );
			TempB1 *= CoefficientFields;
			TempB2 = (*Grid).MagneticField2[GridPoint] + Distance/DeltaX * 
			( - (*Grid).MagneticField2[GridPoint] 
			 + (*Grid).MagneticField2[GridPoint + 1] );
			TempB2 *= CoefficientFields;
			TempB3 = (*Grid).MagneticField3[GridPoint] + Distance/DeltaX * 
			( - (*Grid).MagneticField3[GridPoint] 
			 + (*Grid).MagneticField3[GridPoint + 1] );
			TempB3 *= CoefficientFields;
			/* Coefficient for magnetic field push */
			CoefficientPusher = 2.0 / ( 1.0 + pow(TempB1, 2) + pow(TempB2, 2)
									   + pow(TempB3, 2) );
			/* New Velocity of the ith particle */
			/* First step: 1/2 electric field */
			Velocity1 += TempE1;
			/* Second step: magnetic field */
			TempU1 = Velocity1 + Velocity2*TempB3 - Velocity3*TempB2;
			TempU2 = Velocity2 + Velocity3*TempB1 - Velocity1*TempB3;
			TempU3 = Velocity3 + Velocity1*TempB2 - Velocity2*TempB1;
			TempU1 = Velocity1 + CoefficientPusher
			*(TempU2*TempB3 - TempU3*TempB2);
			TempU2 = Velocity2 + CoefficientPusher
			*(TempU3*TempB1 - TempU1*TempB3);
			TempU3 = Velocity3 + CoefficientPusher
			*(TempU1*TempB2 - TempU2*TempB1);
			/* Third step: 2/2 electric field */
			Velocity1 = TempU1 + TempE1;
			Velocity2 = TempU2;
			Velocity3 = TempU3;
			/* New Position */
			Position += DeltaT * Velocity1;
			(*Species).Electrons.PositionOld[i] = (*Species).Electrons.Position[i];
			(*Species).Electrons.Position[i] = Position;
			(*Species).Electrons.Velocity1[i] = Velocity1;
			(*Species).Electrons.Velocity2[i] = Velocity2;
			(*Species).Electrons.Velocity3[i] = Velocity3;
			
			/* Calculating electron flux */
			PositionAverage = ( (*Species).Electrons.Position[i]
							   + (*Species).Electrons.PositionOld[i] ) / 2.0;
			/*if (PositionAverage < 0.0) PositionAverage = 0.0;*/
			GridPoint = (int_m) ( PositionAverage / DeltaX );
			Distance = PositionAverage
			/ DeltaX - (float_m) GridPoint;
			/* Left node */
			Temp = (*Species).Electrons.Flux1[GridPoint];
			Temp += (1.0 - Distance) * Weight
			* (*Species).Electrons.Velocity1[i];
			(*Species).Electrons.Flux1[GridPoint] = Temp;
			/* Right node */
			Temp = (*Species).Electrons.Flux1[GridPoint + 1];
			Temp += Distance * Weight
			* (*Species).Electrons.Velocity1[i] ;
			(*Species).Electrons.Flux1[GridPoint + 1] = Temp;
			
			/* Calculating the EEDFs */
			if (EEDFReportFlag == 1
				&& TimeStep >= (int_m)NumberTimeStepsStartLastPeriodsEEDF ) 
			{
				/* Left EEDF */
				if ( Position >= LeftGridPointEEDFLeft * DeltaX
					&& Position <=  RightGridPointEEDFLeft * DeltaX)
				{
					Temp = (*Species).Electrons.Velocity1[i] * (*Species).Electrons.Velocity1[i]
					+ (*Species).Electrons.Velocity2[i] * (*Species).Electrons.Velocity2[i]
					+ (*Species).Electrons.Velocity3[i] * (*Species).Electrons.Velocity3[i];
					Energy = 0.5 * Temp 
					* ElectronMass / ElementaryCharge;
					if (Energy > (float_m)MaximumElectronEnergy)
						Energy = (float_m)MaximumElectronEnergy;
					EnergyBin = (int_m)(Energy/ElectronEnergyBinWidth);
					DeltaEnergy = (Energy/ElectronEnergyBinWidth - (float_m)EnergyBin);
					EEDFLeft[EnergyBin] += (1.0 - DeltaEnergy)*InitialPlasmaDensity*GapSize
					/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
					EEDFLeft[EnergyBin+1] += DeltaEnergy*InitialPlasmaDensity*GapSize
					/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
				}									
				/* Center EEDF */
				
				if ( Position >= LeftGridPointEEDFCenter * DeltaX 
					&& Position <=  RightGridPointEEDFCenter * DeltaX)
				{
					Temp = (*Species).Electrons.Velocity1[i] * (*Species).Electrons.Velocity1[i]
					+ (*Species).Electrons.Velocity2[i] * (*Species).Electrons.Velocity2[i]
					+ (*Species).Electrons.Velocity3[i] * (*Species).Electrons.Velocity3[i];
					Energy = 0.5 * Temp 
					* ElectronMass / ElementaryCharge;
					if (Energy > (float_m)MaximumElectronEnergy)
						Energy = (float_m)MaximumElectronEnergy;
					EnergyBin = (int_m)(Energy/ElectronEnergyBinWidth);
					DeltaEnergy = (Energy/ElectronEnergyBinWidth - (float_m)EnergyBin);
					EEDFCenter[EnergyBin] += (1.0 - DeltaEnergy)*InitialPlasmaDensity*GapSize
					/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
					EEDFCenter[EnergyBin+1] += DeltaEnergy*InitialPlasmaDensity*GapSize
					/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
				}
				/* Right EEDF */
				if ( Position >= LeftGridPointEEDFRight * DeltaX
					&& Position <= RightGridPointEEDFRight * DeltaX)
				{
					Temp = (*Species).Electrons.Velocity1[i] * (*Species).Electrons.Velocity1[i]
					+ (*Species).Electrons.Velocity2[i] * (*Species).Electrons.Velocity2[i]
					+ (*Species).Electrons.Velocity3[i] * (*Species).Electrons.Velocity3[i];
					Energy = 0.5 * Temp 
					* ElectronMass / ElementaryCharge;
					if (Energy > (float_m)MaximumElectronEnergy)
						Energy = (float_m)MaximumElectronEnergy;
					EnergyBin = (int_m)(Energy/ElectronEnergyBinWidth);
					DeltaEnergy = (Energy/ElectronEnergyBinWidth - (float_m)EnergyBin);
					EEDFRight[EnergyBin] += (1.0 - DeltaEnergy)*InitialPlasmaDensity*GapSize
					/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
					EEDFRight[EnergyBin+1] += DeltaEnergy*InitialPlasmaDensity*GapSize
					/ InitialNumberParticles / DeltaX /NumberTimeStepsLastPeriodsEEDF;
				}	
			}
			
			/* Check collisions of particles with wall */
			if (Position <= 0.0 || Position >= GapSize)
			{
				if ( BoundaryReflectionFlag
					&& (RandomNumber() <= ReflectedElectronGamma) )
				{
					/* Do the reflection of electrons from the electrode */
					if (Position <= 0.0) (*Species).Electrons.Position[i] 
						= (*Grid).Position[1];
					if (Position >= GapSize) (*Species).Electrons.Position[i] 
						= (*Grid).Position[NumberGridPoints-2];
					(*Species).Electrons.Velocity1[i] *= -1.0;	
				}
				else
				{
					if (Position <= 0.0) QConv += (*Species).Electrons.Charge
						* DeltaX*InnerElectrodeArea*Weight;
					WallIndex[WallNumber] = i;
					WallNumber +=1;
				}
			}
		}
		
		/* Remove electrons which hit the wall */
		for ( i = WallNumber-1; i >= 0; i--) 
		{
			(*Species).Electrons.Position[WallIndex[i]] 
			= (*Species).Electrons.Position[NumberParticles-1];
			(*Species).Electrons.PositionOld[WallIndex[i]] 
			= (*Species).Electrons.PositionOld[NumberParticles-1];
			(*Species).Electrons.Velocity1[WallIndex[i]] 
			= (*Species).Electrons.Velocity1[NumberParticles-1];
			(*Species).Electrons.Velocity2[WallIndex[i]] 
			= (*Species).Electrons.Velocity2[NumberParticles-1];
			(*Species).Electrons.Velocity3[WallIndex[i]] 
			= (*Species).Electrons.Velocity3[NumberParticles-1];
			NumberParticles -= 1;		
		}
		(*Species).Electrons.Number = NumberParticles;
		
		/* Push ions */
		NumberParticles = (*Species).Ions.Number;
		WallNumber = 0;
		memset( WallIndex, 0, sizeof( WallIndex ) );
		/* Coefficient to normalize fields */
		CoefficientFields = DeltaT * (*Species).Ions.Charge
		/ 2.0 / (*Species).Ions.Mass;
		for (i = 0; i < NumberParticles; i++)
		{
			Position = (*Species).Ions.Position[i];
			Velocity1 = (*Species).Ions.Velocity1[i];
			Velocity2 = (*Species).Ions.Velocity2[i];
			Velocity3 = (*Species).Ions.Velocity3[i];
			/* GridPoint left from the ith particle */
			GridPoint = (int_m) ( Position / DeltaX );
			/* Distance between GridPoint and the ith particle */
			Distance = Position - (float_m) GridPoint * DeltaX;
			/* Normalized electric field */
			TempE1 = (*Grid).ElectricField1[GridPoint] + Distance/DeltaX * 
			( - (*Grid).ElectricField1[GridPoint] 
			 + (*Grid).ElectricField1[GridPoint + 1] );
			TempE1 *= CoefficientFields;
			/* Normalized magnetic field */
			TempB1 = (*Grid).MagneticField1[GridPoint] + Distance/DeltaX * 
			( - (*Grid).MagneticField1[GridPoint] 
			 + (*Grid).MagneticField1[GridPoint + 1] );
			TempB1 *= CoefficientFields;
			TempB2 = (*Grid).MagneticField2[GridPoint] + Distance/DeltaX * 
			( - (*Grid).MagneticField2[GridPoint] 
			 + (*Grid).MagneticField2[GridPoint + 1] );
			TempB2 *= CoefficientFields;
			TempB3 = (*Grid).MagneticField3[GridPoint] + Distance/DeltaX * 
			( - (*Grid).MagneticField3[GridPoint] 
			 + (*Grid).MagneticField3[GridPoint + 1] );
			TempB3 *= CoefficientFields;
			/* Coefficient for magnetic field push */
			CoefficientPusher = 2.0 / ( 1.0 + pow(TempB1, 2) + pow(TempB2, 2)
									   + pow(TempB3, 2) );
			/* New Velocity of the ith particle */
			/* First step: 1/2 electric field */
			Velocity1 += TempE1;
			/* Second step: magnetic field */
			TempU1 = Velocity1 + Velocity2*TempB3 - Velocity3*TempB2;
			TempU2 = Velocity2 + Velocity3*TempB1 - Velocity1*TempB3;
			TempU3 = Velocity3 + Velocity1*TempB2 - Velocity2*TempB1;
			TempU1 = Velocity1 + CoefficientPusher
			*(TempU2*TempB3 - TempU3*TempB2);
			TempU2 = Velocity2 + CoefficientPusher
			*(TempU3*TempB1 - TempU1*TempB3);
			TempU3 = Velocity3 + CoefficientPusher
			*(TempU1*TempB2 - TempU2*TempB1);
			/* Third step: 2/2 electric field */
			Velocity1 = TempU1 + TempE1;
			Velocity2 = TempU2;
			Velocity3 = TempU3;
			/* New Position */
			Position += DeltaT * Velocity1;
			(*Species).Ions.PositionOld[i] = (*Species).Ions.Position[i];
			(*Species).Ions.Position[i] = Position;
			(*Species).Ions.Velocity1[i] = Velocity1;
			(*Species).Ions.Velocity2[i] = Velocity2;
			(*Species).Ions.Velocity3[i] = Velocity3;
			
			/* Calculating ion flux */
			PositionAverage = ((*Species).Ions.Position[i]
							   + (*Species).Ions.PositionOld[i] ) / 2.0;
			GridPoint = (int_m) ( PositionAverage / DeltaX );
			Distance = PositionAverage
			/ DeltaX - (float_m) GridPoint;
			/* Left node */
			Temp = (*Species).Ions.Flux1[GridPoint];
			Temp += (1.0 - Distance) * Weight
			* (*Species).Ions.Velocity1[i];
			(*Species).Ions.Flux1[GridPoint] = Temp;
			/* Right node */
			Temp = (*Species).Ions.Flux1[GridPoint + 1];
			Temp += Distance * Weight
			* (*Species).Ions.Velocity1[i];
			(*Species).Ions.Flux1[GridPoint + 1] = Temp;			
			
			/* Check collisions of particles with wall */
			if (Position <= 0.0 || Position >= GapSize)
			{
				if ( BoundaryReflectionFlag
					&& (RandomNumber() <= ReflectedIonGamma) )
				{
					/* Do the reflection of ions from the electrode */
					if (Position <= 0.0) (*Species).Ions.Position[i] 
						= (*Grid).Position[1];
					if (Position >= GapSize) (*Species).Ions.Position[i] 
						= (*Grid).Position[NumberGridPoints-2];
					(*Species).Ions.Velocity1[i] *= -1.0;	
				}
				else
				{
					/* Count particles for charging external capacitance */
					if (Position <= 0.0) QConv += (*Species).Ions.Charge 
						* DeltaX*InnerElectrodeArea*Weight;
					/* Count particles for secondary electron emission */
					if (Position <= 0.0) NumberSecondaryElectronsLeft += 1;
					if (Position >= GapSize) NumberSecondaryElectronsRight += 1;
					/* Calculate IEDF */
					if (IEDFReportFlag == 1
						&& TimeStep >= (int_m)NumberTimeStepsStartLastPeriodsIEDF ) 
					{
						if (Position <= 0.0)
						{
							VelocityT = (*Species).Ions.Velocity2[i] 
							* (*Species).Ions.Velocity2[i] 
							+ (*Species).Ions.Velocity3[i] 
							* (*Species).Ions.Velocity3[i];
							VelocityN = (*Species).Ions.Velocity1[i];
							Energy = 0.5 * Velocity1 * Velocity1 
							* (*Species).Ions.Mass / (*Species).Ions.Charge;
							if (Energy > (float_m)MaximumIonEnergy) Energy 
								= (float_m)MaximumIonEnergy;
							EnergyBin = (int_m)(Energy/IonEnergyBinWidth);
							DeltaEnergy = Energy/IonEnergyBinWidth - (float_m)EnergyBin;
							Angle = atan( sqrt(VelocityT) / abs(VelocityN) + 1E-5) 
							* ( 90 / ( 0.5 * Pi) );
							AngleBin = (int_m)(Angle/ IonAngleBinWidth);
							DeltaAngle = Angle/ IonAngleBinWidth - (float_m)AngleBin;
							IEDFLeft[EnergyBin][AngleBin] 
							+= (1.0 - DeltaEnergy) + (1.0 - DeltaAngle);
							IEDFLeft[EnergyBin + 1][AngleBin +1] 
							+= DeltaEnergy + DeltaAngle;
						}
						else if (Position >= GapSize)
						{
							VelocityT = (*Species).Ions.Velocity2[i] 
							* (*Species).Ions.Velocity2[i] 
							+ (*Species).Ions.Velocity3[i] 
							* (*Species).Ions.Velocity3[i];
							VelocityN = (*Species).Ions.Velocity1[i];	
							Energy = 0.5 * Velocity1 * Velocity1 
							* (*Species).Ions.Mass / (*Species).Ions.Charge;
							if (Energy > (float_m)MaximumIonEnergy) Energy 
								= (float_m)MaximumIonEnergy;
							EnergyBin = (int_m)(Energy/IonEnergyBinWidth);
							DeltaEnergy = Energy/IonEnergyBinWidth - (float_m)EnergyBin;
							Angle = atan( sqrt(VelocityT) / abs(VelocityN) + 1E-5) 
							* ( 90 / ( 0.5 * Pi) );
							AngleBin = (int_m)(Angle/ IonAngleBinWidth);
							DeltaAngle = Angle/ IonAngleBinWidth - (float_m)AngleBin;
							IEDFRight[EnergyBin][AngleBin] 
							+= (1.0 - DeltaEnergy) + (1.0 - DeltaAngle);
							IEDFRight[EnergyBin + 1][AngleBin +1] 
							+= DeltaEnergy + DeltaAngle;	
						}
					}
					WallIndex[WallNumber] = i;
					WallNumber +=1;
				}
			}
		}
		/* Remove ions which hit the wall */
		for ( i = WallNumber-1; i >= 0; i--) 
		{
			(*Species).Ions.Position[WallIndex[i]] 
			= (*Species).Ions.Position[NumberParticles-1];
			(*Species).Ions.PositionOld[WallIndex[i]] 
			= (*Species).Ions.PositionOld[NumberParticles-1];
			(*Species).Ions.Velocity1[WallIndex[i]] 
			= (*Species).Ions.Velocity1[NumberParticles-1];
			(*Species).Ions.Velocity2[WallIndex[i]] 
			= (*Species).Ions.Velocity2[NumberParticles-1];
			(*Species).Ions.Velocity3[WallIndex[i]] 
			= (*Species).Ions.Velocity3[NumberParticles-1];
			NumberParticles -= 1;
		}
		(*Species).Ions.Number = NumberParticles;
	}
	/* Spherical or cylindrical grid */
	else if (CoordinateSystem == 1 || CoordinateSystem == 2)
	{
		
	}
	
	(*Species).Electrons.Flux1[0] *= 2.0;
	(*Species).Electrons.Flux1[NumberGridPoints-1] *= 2.0;
	(*Species).Ions.Flux1[0] *= 2.0;
	(*Species).Ions.Flux1[NumberGridPoints-1] *= 2.0;
	
}
