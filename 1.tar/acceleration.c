/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Functions realizes acceleration schemes
 ******************************************************************************/

void ParticleMultiplication(GRID *Grid, SPECIES *Species)
{
	int_m i;
	int_m Temp;
	Temp=(*Species).Electrons.Number;
	(*Species).Electrons.Number=ParticleMultiplicationFactor*Temp;	
	for (i=Temp;i<(*Species).Electrons.Number;i++)
	{
		(*Species).Electrons.Velocity1[i]=(*Species).Electrons.Velocity1[i-Temp];
		(*Species).Electrons.Velocity2[i]=(*Species).Electrons.Velocity2[i-Temp];
		(*Species).Electrons.Velocity3[i]=(*Species).Electrons.Velocity3[i-Temp];
		if (CoordinateSystem == 0)
		{
			(*Species).Electrons.Position[i]=(*Species).Electrons.Position[i-Temp];
			(*Species).Electrons.PositionOld[i]=(*Species).Electrons.PositionOld[i-Temp];
		}
		else if (CoordinateSystem==1||CoordinateSystem==2)
		{
			(*Species).Electrons.Position[i]=(*Species).Electrons.Position[i-Temp];
			(*Species).Electrons.PositionOld[i]=(*Species).Electrons.PositionOld[i-Temp];
		}
	}
	Temp=(*Species).Ions.Number;
	(*Species).Ions.Number=ParticleMultiplicationFactor*Temp;
	
	for (i=Temp;i<(*Species).Ions.Number;i++)
	{
		
		(*Species).Ions.Velocity1[i]=(*Species).Ions.Velocity1[i-Temp];
		(*Species).Ions.Velocity2[i]=(*Species).Ions.Velocity2[i-Temp];
		(*Species).Ions.Velocity3[i]=(*Species).Ions.Velocity3[i-Temp];
		if (CoordinateSystem == 0)
		{
			(*Species).Ions.Position[i]=(*Species).Ions.Position[i-Temp];
			(*Species).Ions.PositionOld[i]=(*Species).Ions.PositionOld[i-Temp];
		}
		else if (CoordinateSystem==1||CoordinateSystem==2)
		{
			(*Species).Ions.Position[i]=(*Species).Ions.Position[i-Temp];
			(*Species).Ions.PositionOld[i]=(*Species).Ions.PositionOld[i-Temp];
		}
	}
	if (CoordinateSystem==0)
	{
		Weight=Weight/ParticleMultiplicationFactor;
	}
	else if (CoordinateSystem==1)
	{
		for (i=0;i<NumberGridPoints;i++)
		{
			SphericalWeight[i]=SphericalWeight[i]/ParticleMultiplicationFactor;
		}
	}
	else if (CoordinateSystem==2)
	{
	}
	AdaptiveWeightNumberParticles=(int_m)(AdaptiveWeightNumberParticles*ParticleMultiplicationFactor);
	np=(*Species).Ions.Number;
	npold=np;
	DeltaParticle_i=0.0;
	DeltaParticle_p=0.0;
	DeltaParticle_d=0.0;
}

void AdaptiveWeighting(GRID *Grid,SPECIES *Species)
{
	int_m i;
	if (TimeStep%(NumberTimeStepsPerCycle)==0&&TimeStep>0)
	{
		npold=np;
		np=(*Species).Ions.Number;
		DeltaParticle_i+=(float_m)(DeltaParticle_p)/(float_m)(AdaptiveWeightNumberParticles);
		DeltaParticle_p=(float_m)(np-AdaptiveWeightNumberParticles)/(float_m)(AdaptiveWeightNumberParticles);
		DeltaParticle_d=(float_m)(np-npold)/(float_m)npold;
		if (CoordinateSystem==0)
		{
			Weight=Weight*(1.0+AdaptiveWeightChange_i*DeltaParticle_i
						   +AdaptiveWeightChange_p*DeltaParticle_p+AdaptiveWeightChange_d*DeltaParticle_d);
		}
		else if (CoordinateSystem==1)
		{
			for (i=0;i<NumberGridPoints;i++)
			{
				SphericalWeight[i]=SphericalWeight[i]*(1.0+AdaptiveWeightChange_i*DeltaParticle_i
					+AdaptiveWeightChange_p*DeltaParticle_p+AdaptiveWeightChange_d*DeltaParticle_d);
			}
		}
		else if (CoordinateSystem==2)
		{
		}
	}
}