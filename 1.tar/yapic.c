/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

int main(int argc, char **argv)
{
	GRID Grid;
	SPECIES Species;
	Success = system("rm -f ./Report*"); 
	Welcome();
	InitializeParameters();
	GenerateGrid(&Grid);
	if (TabXSectFlag==1) ReadXSections();
	if (CrossSectionReportFlag==1) ReportCrossSections(&Species);
	GenerateSpecies(&Species); 
	SetMagneticField(&Grid);	
	PrintInitialScreen(&Grid,&Species);
	StartRun=clock();
	for (TimeStep=0;TimeStep<MaxNumberTimeSteps;TimeStep++)
	{
		if (TimeStep!=0&&TimeStep%(int_m)NumberTimeStepsPerCycle==0) NumberPeriod++;
		if (TimeStep%(int_m)WriteDataEveryNumberTimeSteps==0)
		{
			EndCycle=clock();
			TimePerCycle=(float_m)(EndCycle-StartCycle)/CLOCKS_PER_SEC/WriteDataEveryNumberTimeSteps;			
			if (GridReportFlag==1 ) ReportDataGrid(&Grid,&Species);
			if (ConvergenceReportFlag==1) ReportDataConvergence(&Grid,&Species);
			if (PrintDataFlag==1) PrintScreen(&Grid,&Species); 
			StartCycle=clock();
		}		
		if (ExternalMagnetFieldFlag==1) BorisPushParticles(&Grid,&Species);
		else PushParticles(&Grid, &Species);		
		CalculateChargeDensity(&Grid,&Species);
		CalculateField(&Grid);
		if (CurrentDensityFlag==1) CalculateCurrentDensity(&Grid,&Species);
		if (SecondaryElectronGamma!=0.0) DoSecondaryElectronEmission(&Grid,&Species);
		if (CollisionReportFlag==1&&TimeStep%NumberTimeStepsPerCycle==0&&TimeStep>=NumberTimeStepsPerCycle)
		{
			ReportNumberCollisions();
			pel1=0;pel2=0;pel3=0;pel4=0;pion1=0;pion2=0;
		}
		DoCollisions(&Grid,&Species); 
		if (AdaptiveWeightFlag==1 && TimeStep <= (NumberTimeStepsAdaptiveWeightEnd))
			AdaptiveWeighting(&Grid,&Species);
		if (ParticleMultiplicationFlag==1 && TimeStep == (NumberTimesStepParticleMultiplication)) 
			ParticleMultiplication(&Grid,&Species);		
		if (LastPeriodsAveragingFlag==1 &&
			TimeStep>=(int_m)NumberTimeStepsStartLastPeriodsAveraging)
			LastPeriodsAveragedDiagnostics(&Grid,&Species);
		if (SpaceTimeReportFlag==1 && 
			TimeStep>=(int_m)NumberTimeStepsStartLastPeriodsAveraging && 
			(TimeStep-(int_m)NumberTimeStepsStartLastPeriodsAveraging)%((int_m)NTSPCToSNTSPC)==0)
			LastPeriodsResolvedDiagnostics(&Grid,&Species);
		if (SpaceTimeReportFlag==1 && 
			TimeStep>=(int_m)NumberTimeStepsStartLastPeriodsEvents &&
			(TimeStep-(int_m)NumberTimeStepsStartLastPeriodsAveraging)%((int_m)NTSPCToSNTSPC)==0) 
			RecordCollisionEvents(&Grid,&Species);
		if (TrackElectronFlag==1 &&
			TimeStep>=(int_m)NumberTimeStepsStartElectronTracking && 
			(TimeStep-(int_m)NumberTimeStepsStartLastPeriodsAveraging)%((int_m)NTSPCToSNTSPC)==0)
			TrackElectronTrajectories(&Species);	
		Time+=DeltaT;
		ComputationTime=clock();
	}
	EndRun=clock();
	if (LastPeriodsAveragingFlag==1) ReportDataGridAve(&Grid,&Species);
	if (SpaceTimeReportFlag==1) ReportDataXT(&Grid);
	if (IEDFReportFlag==1) ReportDataIEDF();
	if (EEDFReportFlag==1) ReportDataEEDF();	
	if (SheathReportFlag==1) ReportDataSheath(&Grid);
	if (TrackElectronFlag==1) ReportDataTrackedElectrons(&Grid);
	if (FourierReportFlag==1) ReportFourierSpectra();
	printf("The run took %e seconds ...\n",(float_m)(EndRun-StartRun)/CLOCKS_PER_SEC);
	printf("Bye ...\n\n");
	return 0;
}
