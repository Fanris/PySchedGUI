#define VSourceAmplitudeLeft1 450.0          /* in V */
#define VSourceFrequencyLeft1 13.56e6        /* in Hz */
#define GapSize 0.067                        /* in m */
#define GasPressure 3.9996                   /* in Pa */
/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <omp.h>

#if defined DEFINITIIONS
#else
#define DEFINITIONS

/* Voltage driven cases for the 2011/12 benchmarking activity
 * together with Eremin, Turner, and Donko
 * Case 1: V_RF=450, N_ini=65536,  n_ini=2.56e14, p=3.99966, NGAS=9.64e20,  NGP=129, NTSPC=400,  RFC=1280
 * Case 2: V_RF=200, N_ini=65536,  n_ini=5.12e14, p=13.3322, NGAS=32.1e20,  NGP=257, NTSPC=800,  RFC=5120
 * Case 3: V_RF=150, N_ini=65536,  n_ini=5.12e14, p=39.9966, NGAS=96.4e20,  NGP=513, NTSPC=1600, RFC=5120
 * Case 4: V_RF=120, N_ini=32768,  n_ini=3.84e14, p=133.322, NGAS=321.0e20, NGP=513, NTSPC=3200, RFC=15360
 */ 

/******************************************************************************
 * Definition of the coordinate system 
 * 0 cartesian, 1 spherical, 2 cylindrical (not implented yet)
 *****************************************************************************/
#define CoordinateSystem 0

/******************************************************************************
 * Definition of the spatial grid 
 *****************************************************************************/
#define NumberGridPoints 129
#define NumberCells (NumberGridPoints)      /* currently not used */

#define DeltaX (GapSize/(NumberCells-1))    /* in m */
#define InnerElectrodeRadius 0.05         /* in m */
#define CylinderLength 0.12                 /* coaxial electrode length in m */

/******************************************************************************
 * Definition of the initial plasma state 
 *****************************************************************************/
#define MaxNumberSuperParticles 80000
#define MaxNumberSuperParticlesPerCell 5000            /* currently not used */
#define InitialNumberParticles 65536
#define InitialPlasmaDensity 2.56e14/* in m^-3 */
#define HomogeneousInitialDensityFlag  1 
#define InitialElectronTemperature 30000.0             /* in K */
#define InitialIonTemperature 300.0                    /* in K */

/******************************************************************************
 * Definition of secondary boundary effects 
 *****************************************************************************/
#define BoundaryReflectionFlag 0
#define ReflectedElectronGamma 0.0
#define ReflectedIonGamma 0.0
#define SecondaryElectronGamma 0.0

/******************************************************************************
 * Definitions for the temporal evolution of the plasma
 *****************************************************************************/
#define AdaptiveWeightFlag 0
#define NumberTimeStepsAdaptiveWeightEnd (850*NumberTimeStepsPerCycle)

#define AdaptiveWeightChange_i 5.0                           /*  */
#define AdaptiveWeightChange_p 2.2                             /*  */
#define AdaptiveWeightChange_d 30.5                            /*  */

#define ParticleMultiplicationFlag 0
#define NumberTimesStepParticleMultiplication (750*NumberTimeStepsPerCycle)
#define ParticleMultiplicationFactor 6

#define SmoothingFlagDensities 0
#define MaxNumberCycles 1280
#define AC                                                       /* AC or DC */
#ifdef AC
#define NumberTimeStepsPerCycle 400
#define DeltaT (1.0/NumberTimeStepsPerCycle/VSourceFrequencyLeft1)
#define PeriodLength (1.0/VSourceFrequencyLeft1)
#define ACFlag 1
#endif
#ifdef DC
#define NumberTimeStepsPerCycle 2000 
#define DeltaT (4.609e-14) /* in s */
#define PeriodLength (NumberTimeStepsPerCycle*DeltaT)
#define ACFlag 1
#endif
#define MaxNumberTimeSteps (NumberTimeStepsPerCycle*MaxNumberCycles)

/******************************************************************************
 * Definition of the external circuit 
 *****************************************************************************/
#define CurrentSourceFlag 0                  /* 0 v source, 1 c source */
#define JSourceAmplitudeLeft1 10.0           /* in A/m^2 */
#define JSourceFrequencyLeft1 13.56e6        /* in Hz */
#define JSourcePhaseShiftLeft1 0.0           /* in % of 2*Pi */
#define ExternalR 0.e-9                     /* in V/A, active for v source */
#define ExternalC 1.0e16                      /* in As/V, active for v source */
#define ExternalL 0.0e-10                    /* in Vs/A, active for v source */
#define VSourceDCLeft 0.0                    /* in V */
#define VSourcePhaseShiftLeft1 0.0           /* in % of 2*Pi */
#define VSourceAmplitudeLeft2  0.0          /* in V */
#define VSourceFrequencyLeft2 27.12e6        /* in Hz */
#define VSourcePhaseShiftLeft2 0.0           /* in % of 2*Pi */
#define VSourceAmplitudeLeft3 0.0            /* in V */
#define VSourceFrequencyLeft3 60.0e6         /* in Hz */
#define VSourcePhaseShiftLeft3 0.0           /* in % of 2*Pi */
#define VSourceDCRight 0.0                   /* in V*/
#define VSourceAmplitudeRight1 0.0           /* in V */
#define VSourceFrequencyRight1 0.0e6         /* in Hz */
#define VSourcePhaseShiftRight1 0.0          /* in % of 2*Pi */
#define VSourceAmplitudeRight2 0.0           /* in V */
#define VSourceFrequencyRight2 27.12e6       /* in Hz */
#define VSourcePhaseShiftRight2 0.0          /* in % of 2*Pi */

/******************************************************************************
 * Definition of the external static, inhomogenous magnetic field 
 *****************************************************************************/
#define ExternalMagnetFieldFlag 0
#define BSourceShape 1             /* 0 Rect, 1 Max*(Ga^Be/(Ga^Be+(x-Al)^Be) */
#define BSourceMax 0.0e-4          /* in Tesla (10 mT=100 G) */
#define BSourceCenter 0.5*GapSize  /* Center of the Rect */
#define BSourceWidth 0.5*GapSize   /* Width of the Rect */
#define BSourceAlpha 0.5*GapSize   /* See Lorenzian formula */
#define BSourceBeta 4.0            /* See Lorenzian formula */
#define BSourceGamma 0.1*GapSize   /* See Lorenzian formula */
#define BSourcePolarization 2      /* 1 x, 2 y, 3 z */

/******************************************************************************
 * Definition of the background gas properties 
 *****************************************************************************/
#define He                                              /* currently Ar, He */
#define GasTemperature 300.0                                         /* in K */
#define GasDensity (GasPressure/BoltzmannConstant/GasTemperature) /* in m^-3 */
#define GasEnergy (GasTemperature*BoltzmannConstant/ElementaryCharge)  /* eV */
#define NumberGasParticles (GasDensity*GapSize*InnerElectrodeArea)
#define ArgonMassFactor 39.98
#define ArgonIonAtomicNumber 1
#define ArgonIonizationEnergy 15.76
#define ArgonExcitationEnergy 12.00 /* 11.55 */
#define HeliumMassFactor 4.016765/*4.002602*/
#define HeliumIonAtomicNumber 1
#define HeliumIonizationEnergy 2.459e+1                         /* Biagi 7.1 */
#define HeliumExcitationEnergyTrip 1.982e+1                     /* Biagi 7.1 */
#define HeliumExcitationEnergySing 2.061e+1                     /* Biagi 7.1 */
#ifdef Ar
#define GasFlag 1
#define GasVelocity (sqrt(GasEnergy/ArgonMassFactor/AtomicMassUnit*1.602e-19))
#define FastElectronsThreshold 15.76          /* for recording fast electons */
#endif
#ifdef He
#define GasFlag 2
#define GasVelocity (sqrt(GasEnergy/HeliumMassFactor/AtomicMassUnit*1.602e-19))
#define FastElectronsThreshold 24.59          /* for recording fast electons */
#endif
#define TabXSectFlag 1         /* Read He cross section from the Biagi table */
#define NumberXSectDataA 171   /* Number of values in the Biagi table for He */
#define NumberXSectDataB 201   /* Number of values in the Biagi table for He */
#define NumberXSectDataC 201   /* Number of values in the Biagi table for He */
#define NumberXSectDataD 201   /* Number of values in the Biagi table for He */
#define NumberXSectDataE 100    /* Number of values in the Biagi table for He */
#define NumberXSectDataF 100    /* Number of values in the Biagi table for He */ 
#define MaximumElEnergyXSect 625.0       /* Maximum energy for electron col */
#define MaximumIonEnergyXSect 9999.9/*9900.0*/      /* Maximum energy for ion col */

/******************************************************************************
 * Definition of the calculating IEDF and IDAF 
 *****************************************************************************/
#define MaximumIonEnergy 1000
#define MaximumIonAngle 5
#define MaximumNumberIonEnergyBins 5000
#define MaximumNumberIonAngleBins 400

/******************************************************************************
 * Definition of the calculating EEDF 
 *****************************************************************************/
#define NumberEEDFCells 64
#define LeftGridPointEEDFLeft NumberEEDFCells
#define RightGridPointEEDFLeft (NumberEEDFCells+NumberEEDFCells)
#define LeftGridPointEEDFCenter ((NumberGridPoints-1)/2-NumberEEDFCells/2)
#define RightGridPointEEDFCenter ((NumberGridPoints-1)/2-NumberEEDFCells/2+NumberEEDFCells)
#define LeftGridPointEEDFRight (NumberGridPoints-2*NumberEEDFCells)
#define RightGridPointEEDFRight (NumberGridPoints-2*NumberEEDFCells+NumberEEDFCells)
#define MaximumElectronEnergy 120
#define MaximumNumberElectronEnergyBins 15000

/******************************************************************************
 * Definition of diagnostics parameters 
 *****************************************************************************/
#define IEDFReportFlag 0
#define EEDFReportFlag 0
#define SmoothingFlagChargeDensity 0
#define GridReportFlag 1
#define ConvergenceReportFlag 1
#define CollisionReportFlag 1
#define PrintDataFlag 1
#define SpaceTimeReportFlag 0
#define LastPeriodsAveragingFlag 1
#define CrossSectionReportFlag 0
#define EventIonizationFlag 0
#define EventExcitationFlag 0
#define FastElectronsFlag 0
#define SheathReportFlag 0
#define TrackElectronFlag 0
#define FourierReportFlag 0
#define CurrentDensityFlag 0
#define WriteDataEveryNumberTimeSteps 400
#define StoredNumberTimeStepsPerCycle 500
#define NumberLastPeriodsAveraging 32
#define NumberLastPeriodsResolved 1
#define NumberLastPeriodsEEDF 32
#define NumberLastPeriodsIEDF 32
#define NumberLastPeriodsEvents 32
#define NumberHarmonics 100
#define NumberTrackedElectrons 4
#define NTSPCToSNTSPC (NumberTimeStepsPerCycle/StoredNumberTimeStepsPerCycle)
#define StoredDeltaT PeriodLength/StoredNumberTimeStepsPerCycle
#define NumberTimeStepsLastPeriodsAveraging (NumberTimeStepsPerCycle*NumberLastPeriodsAveraging)
#define NumberTimeStepsStartLastPeriodsAveraging (MaxNumberTimeSteps-NumberTimeStepsLastPeriodsAveraging)
#define NumberTimeStepsLastPeriodsResolved (StoredNumberTimeStepsPerCycle*NumberLastPeriodsResolved)
#define AveToResRatio (NumberLastPeriodsAveraging/NumberLastPeriodsResolved)
#define NumberTimeStepsLastPeriodsEEDF (NumberTimeStepsPerCycle*NumberLastPeriodsEEDF)
#define NumberTimeStepsStartLastPeriodsEEDF ((MaxNumberCycles-NumberLastPeriodsEEDF)*NumberTimeStepsPerCycle)
#define NumberTimeStepsLastPeriodsIEDF (NumberTimeStepsPerCycle*NumberLastPeriodsIEDF)
#define NumberTimeStepsStartLastPeriodsIEDF ((MaxNumberCycles-NumberLastPeriodsIEDF)*NumberTimeStepsPerCycle)
#define NumberTimeStepsLastPeriodsEvents (NumberTimeStepsPerCycle*NumberLastPeriodsEvents)
#define NumberTimeStepsStartLastPeriodsEvents ((MaxNumberCycles-NumberLastPeriodsEvents)*NumberTimeStepsPerCycle)
#define AveToEventsRatio (NumberLastPeriodsAveraging/NumberLastPeriodsEvents)
#define NumberTimeStepsStartElectronTracking ((MaxNumberCycles-NumberLastPeriodsResolved)*NumberTimeStepsPerCycle)

/******************************************************************************
 * Fundamental constants 
 *****************************************************************************/
#define Pi 3.1415926535897932384626433833
#define ElectronMass 9.10938e-31 /* in kg */
#define ElementaryCharge 1.602e-19 /* in eV */
#define AtomicMassUnit 1.66054e-27 /* in kg */
#define VacuumPermittivity 8.85418817e-12 /* in As/Vm */
#define BoltzmannConstant 1.3806488e-23 /* in J/K */

/*******************************************************************************
 * Definition of the types used in the code
 ******************************************************************************/
typedef double float_m;
typedef long int int_m; 

/*******************************************************************************
 * Misc variables
 ******************************************************************************/
clock_t StartCycle,EndCycle,StartRun,EndRun,ComputationTime;
int_m Success,Seed,TimeStep;
int_m TimeStepTrackedElectrons,TimeStepCollisionEvents,TimeStepResolvedDiagnostics;
int_m NumberPeriod,NumberSecondaryElectronsLeft,NumberSecondaryElectronsRight;
int_m np,npold;
int_m AdaptiveWeightNumberParticles;
/*float_m DeltaParticle;*/
int_m EstimatedTotalTime, ElapsedTotalTime;
float_m DeltaParticle_i, DeltaParticle_p, DeltaParticle_d;
float_m Time,TimePerCycle;
float_m VSourceLeft,VSourceRight,VBias,VElectrodeLeft,VElectrodeRight,Current;
float_m Alpha0,Alpha1,Alpha2,Alpha3,Alpha4,K;
float_m QBias,QBiasOld,QBiasOldOld,QBiasOldOldOld,QBiasOldOldOldOld;
float_m QConv,QConvOld,Sigma,SigmaOld;
float_m ElectricField1,ElectricField1Old;
float_m IonEnergyBinWidth,IonAngleBinWidth,ElectronEnergyBinWidth;
float_m AveragedElectronDensity,AveragedIonDensity;
float_m InnerElectrodeArea;/*NumberParticlesPerSuperParticles*/
float_m CollisionFrequencyElectrons;
float_m Weight,InitialWeight;
float_m SphericalWeight[NumberGridPoints],SphericalInitialWeight[NumberGridPoints];

/*******************************************************************************
 * A large number of arrays for diagnostics purposes
 ******************************************************************************/
float_m EEDFLeft[MaximumNumberElectronEnergyBins];
float_m EEDFCenter[MaximumNumberElectronEnergyBins];
float_m EEDFRight[MaximumNumberElectronEnergyBins];
float_m IEDFLeft[MaximumNumberIonEnergyBins][MaximumNumberIonAngleBins];
float_m IEDFRight[MaximumNumberIonEnergyBins][MaximumNumberIonAngleBins];
float_m ElectronDensityAve[NumberGridPoints];
float_m ElectronFluxAve[NumberGridPoints];
float_m IonDensityAve[NumberGridPoints];
float_m IonFluxAve[NumberGridPoints];
float_m ChargeDensityAve[NumberGridPoints];
float_m ElectricField1Ave[NumberGridPoints];
float_m ReducedElectricField1Ave[NumberGridPoints];
float_m PotentialAve[NumberGridPoints];
float_m CurrentDensity1Ave[NumberGridPoints];
float_m DisplacementCurrent1Ave[NumberGridPoints];
float_m PowerDensityAve[NumberGridPoints];
float_m ElectronDensityXT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m IonDensityXT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m ChargeDensityXT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m ReducedElectricField1XT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m PotentialXT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m ElectricField1XT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m DisplacementCurrent1XT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m CurrentDensity1XT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m PowerDensityXT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m EventIonizationXT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m EventExcitationXT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m FastElectronsXT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m TrackedElectronsXT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m ElectronFluxXT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
float_m IonFluxXT[NumberGridPoints][(int_m)NumberTimeStepsLastPeriodsResolved];
int_m TrackedElectronIndex[NumberTrackedElectrons];
float_m CurrentT[(int_m)NumberTimeStepsLastPeriodsResolved];
float_m BiasT[(int_m)NumberTimeStepsLastPeriodsResolved];
float_m VoltageElectrodeLeftT[(int_m)NumberTimeStepsLastPeriodsResolved];
float_m VoltageElectrodeRightT[(int_m)NumberTimeStepsLastPeriodsResolved];
float_m SheathWidthLeft[(int_m)NumberTimeStepsLastPeriodsResolved];
float_m SheathWidthRight[(int_m)NumberTimeStepsLastPeriodsResolved];
float_m SheathVoltageLeft[(int_m)NumberTimeStepsLastPeriodsResolved];
float_m SheathVoltageRight[(int_m)NumberTimeStepsLastPeriodsResolved];
float_m SheathChargeLeft[(int_m)NumberTimeStepsLastPeriodsResolved];
float_m SheathChargeRight[(int_m)NumberTimeStepsLastPeriodsResolved];
float_m SheathIonFluxLeft[(int_m)NumberTimeStepsLastPeriodsResolved];
float_m SheathIonFluxRight[(int_m)NumberTimeStepsLastPeriodsResolved];
int_m pel1,pel2,pel3,pel4,pion1,pion2;

/*******************************************************************************
 * Arrays for tabulated cross section data (for Biagi 7.1 He Xsections)
 * These arrays are used for benchmarking the codes of Turner, Donko
 * Eremin, and Mussenbrock
 ******************************************************************************/
float_m EnergyElEla[NumberXSectDataA];
float_m XSectElEla[NumberXSectDataA];
float_m EnergyElIon[NumberXSectDataB];
float_m XSectElIon[NumberXSectDataB];
float_m EnergyElExcTrip[NumberXSectDataC];
float_m XSectElExcTrip[NumberXSectDataC];
float_m EnergyElExcSing[NumberXSectDataD];
float_m XSectElExcSing[NumberXSectDataD];
float_m EnergyIonEla[NumberXSectDataE];
float_m XSectIonEla[NumberXSectDataE];
float_m EnergyIonCex[NumberXSectDataF];
float_m XSectIonCex[NumberXSectDataF];

/*******************************************************************************
 * Definition of the structure "GRID"
 ******************************************************************************/
typedef struct
{
	float_m *Position;
	float_m *Potential;
	float_m *ElectricField1;
	float_m *ElectricFieldOld1;
	float_m *DisplacementCurrent1;	
	float_m *CurrentDensity1;
	float_m *MagneticField1;
	float_m *MagneticField2;
	float_m *MagneticField3;
	float_m *ChargeDensity;
	float_m *EventIonization;
	float_m *EventExcitation;
	float_m *FastElectrons;
	float_m *PowerDensity;
} GRID;

/*******************************************************************************
 * Definition of the structure "ELECTRONS"
 ******************************************************************************/
typedef struct
{
	float_m InitialEnergy;
	int_m Number;
	float_m Mass;
	float_m Charge; 
	float_m *Position;
	float_m *PositionOld;
	float_m *Velocity1;
	float_m *Velocity2;
	float_m *Velocity3;
	float_m *Flux1;
	float_m *Density;
	float_m CollisionProbability;
	float_m CollisionExtraFactor;
	float_m MaxCollisionParameter;
	float_m (*ProcessE1Sigma)(float_m);
	float_m (*ProcessE2Sigma)(float_m);
	float_m (*ProcessE3Sigma)(float_m);
	float_m (*ProcessE4Sigma)(float_m);
} ELECTRONS;

/*******************************************************************************
 * Definition of the structure "IONS"
 ******************************************************************************/
typedef struct
{
	float_m InitialEnergy;
	int_m Number;
	float_m Mass;
	float_m Charge;
	float_m *Position;
	float_m *PositionOld;
	float_m *Velocity1;
	float_m *Velocity2;
	float_m *Velocity3;
	float_m *Flux1;
	float_m *Density;
	float_m CollisionProbability;
	float_m CollisionExtraFactor;
	float_m MaxCollisionParameter;
	float_m (*ProcessI1Sigma)(float_m);
	float_m (*ProcessI2Sigma)(float_m);
} IONS;

/*******************************************************************************
 * Definition of the structure "SPECIES"
 ******************************************************************************/
typedef struct
{
	ELECTRONS Electrons;
	IONS Ions;
} SPECIES;

#endif

/*******************************************************************************
 * Function prototypes
 ******************************************************************************/
void Welcome();
void GenerateGrid(GRID *);
void GenerateSpecies(SPECIES *);
void MaxwellDistribution(float_m *,float_m *,float_m *,float_m);
void CalculateChargeDensity(GRID *, SPECIES *);
void SetMagneticField(GRID *);
void CalculateField(GRID *);
void CalculateCurrentDensity(GRID *,SPECIES *);
void PushParticles(GRID *, SPECIES *);
void BorisPushParticles(GRID *,SPECIES *);
void DoCollisions(GRID *, SPECIES *);
void NewVelocity(SPECIES *,float_m *,float_m *,float_m *,float_m*,float_m *,int_m);
void ReportDataConvergence(GRID *,SPECIES *);
void ReportDataXT(GRID *);
void ReportDataGrid(GRID *,SPECIES *);
void ReportDataGridAve(GRID *,SPECIES *);
void ReportDataIEDF();
void ReportDataEEDF();
void ReportFourierSpectra();
void ReportCrossSections(SPECIES *);
void ReportNumberCollisions();
void ReportDataSheath(GRID *);
void ReportDataTrackedElectrons(GRID *);
void DoSecondaryElectronEmission(GRID *,SPECIES *);
void AdaptiveWeighting(GRID *,SPECIES *);
void ParticleMultiplication(GRID *,SPECIES *);
void ReadXSections();
void InitializeParameters();
void PrintInitialScreen(GRID *,SPECIES *);
void PrintScreen(GRID *, SPECIES *);
void TrackElectronTrajectories(SPECIES *);
void RecordCollisionEvents(GRID *,SPECIES *);
void LastPeriodsAveragedDiagnostics(GRID *,SPECIES *);
void LastPeriodsResolvedDiagnostics(GRID *,SPECIES *);
float_m ArgonElectronScatteringSigma(float_m);
float_m ArgonElectronIonizationSigma(float_m);
float_m ArgonElectronExcitationSigma(float_m);
float_m ArgonIonScatteringSigma(float_m);
float_m ArgonIonChargeExchangeSigma(float_m);
float_m HeliumElectronScatteringSigma(float_m);
float_m HeliumElectronIonizationSigma(float_m);
float_m HeliumElectronExcitationSigmaTrip(float_m);
float_m HeliumElectronExcitationSigmaSing(float_m);
float_m HeliumIonScatteringSigma(float_m);
float_m HeliumIonChargeExchangeSigma(float_m);
float_m VoltageSourceLeft();
float_m VoltageSourceRight();
float_m CurrentDensitySourceLeft();
float_m RandomNumber();
