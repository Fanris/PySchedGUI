/*******************************************************************************
 * y a p i c 
 * Version 2.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function calculates Maxwell distribution (Box Muller Transform)
 ******************************************************************************/
void LastPeriodsResolvedDiagnostics(GRID *Grid, SPECIES *Species)
{	

	int x;

	if (TimeStepResolvedDiagnostics % ((int_m)NumberTimeStepsLastPeriodsResolved) == 0) TimeStepResolvedDiagnostics=0;
	
	for (x=0; x < NumberGridPoints; x++)
	{
		ElectronDensityXT[x][TimeStepResolvedDiagnostics] += (*Species).Electrons.Density[x]
		/ AveToResRatio;
		IonDensityXT[x][TimeStepResolvedDiagnostics] += (*Species).Ions.Density[x]
		/ AveToResRatio;
		ChargeDensityXT[x][TimeStepResolvedDiagnostics] += (*Grid).ChargeDensity[x]
		/ AveToResRatio;
		ReducedElectricField1XT[x][TimeStepResolvedDiagnostics] += (*Grid).ElectricField1[x]
		/ GasDensity * 1e21 / AveToResRatio;
		PotentialXT[x][TimeStepResolvedDiagnostics] += (*Grid).Potential[x]
		/ AveToResRatio;
		FastElectronsXT[x][TimeStepResolvedDiagnostics] += (*Grid).FastElectrons[x] / AveToResRatio;
		ElectricField1XT[x][TimeStepResolvedDiagnostics] += (*Grid).ElectricField1[x] / AveToResRatio;
		DisplacementCurrent1XT[x][TimeStepResolvedDiagnostics] += (*Grid).DisplacementCurrent1[x] / AveToResRatio;
		CurrentDensity1XT[x][TimeStepResolvedDiagnostics] += (*Grid).CurrentDensity1[x] / AveToResRatio;
		PowerDensityXT[x][TimeStepResolvedDiagnostics] += ((*Grid).CurrentDensity1[x]*(*Grid).ElectricField1[x]) / AveToResRatio;
		ElectronFluxXT[x][TimeStepResolvedDiagnostics] += (*Species).Electrons.Flux1[x]/ AveToResRatio;
		IonFluxXT[x][TimeStepResolvedDiagnostics] += (*Species).Ions.Flux1[x]/ AveToResRatio;
	}
	CurrentT[TimeStepResolvedDiagnostics] += Current / AveToResRatio;
	BiasT[TimeStepResolvedDiagnostics] += VBias / AveToResRatio;
	VoltageElectrodeLeftT[TimeStepResolvedDiagnostics] += (*Grid).Potential[0] 
	/ AveToResRatio;
	VoltageElectrodeRightT[TimeStepResolvedDiagnostics] 
	+= (*Grid).Potential[(int_m)NumberGridPoints-1] / AveToResRatio;
	TimeStepResolvedDiagnostics++;
}
