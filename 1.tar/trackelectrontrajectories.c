/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function calculates Maxwell distribution (Box Muller Transform)
 ******************************************************************************/
void TrackElectronTrajectories(SPECIES *Species)
{	
	int_m i,gp;
	float_m Temp;
	Temp=0.0;
	for (i=0;i<(int_m)NumberTrackedElectrons;i++)
	{
		if (CoordinateSystem==0)
			gp=(int)((*Species).Electrons.Position[TrackedElectronIndex[i]]/DeltaX);
		else if (CoordinateSystem==1)
			gp=(int)(((*Species).Electrons.Position[TrackedElectronIndex[i]]-InnerElectrodeRadius)/DeltaX);
		Temp=(*Species).Electrons.Velocity1[i]*(*Species).Electrons.Velocity1[i]
			+(*Species).Electrons.Velocity2[i]*(*Species).Electrons.Velocity2[i]
			+(*Species).Electrons.Velocity3[i]*(*Species).Electrons.Velocity3[i];
		Temp=Temp*(*Species).Electrons.Mass/2.0/fabs((*Species).Electrons.Charge);
		TrackedElectronsXT[gp][TimeStepTrackedElectrons]=1.0+(float_m)i;
	}
	TimeStepTrackedElectrons++;
}