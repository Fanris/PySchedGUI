/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Random number generator (Park and Miller's pseudo-random number generator)
 ******************************************************************************/

float_m RandomNumber()
{	
	
	int_m af;
	int_m mf;
	int_m qf;
	int_m r;
	int_m hi;
	int_m lo;
	float_m number;
	af = 16807;
	mf = 2147483647;
	qf = 127773;
	r = 2836;
	hi = Seed / qf;
	lo = Seed - qf * hi;
	Seed = af * lo - r * hi;
	if (Seed <= 0) Seed = Seed + mf;
	number = (float_m)Seed / 2147483646.0;
	return number;	 

/* return (float_m)rand () / (float_m)RAND_MAX; */
}

