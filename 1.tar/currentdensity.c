/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function calculates current density on the grid
 ******************************************************************************/
void CalculateCurrentDensity(GRID *Grid,SPECIES *Species)
{
	int_m i;
	for (i=0;i<NumberGridPoints;i++)
	{
		(*Grid).DisplacementCurrent1[i]=0.0;
		(*Grid).CurrentDensity1[i]=0.0;
	}
	/* Calculating the current density on the grid */
	for (i=0;i<NumberGridPoints;i++)
	{
		(*Grid).DisplacementCurrent1[i]=VacuumPermittivity/DeltaT
			*((*Grid).ElectricField1[i]-(*Grid).ElectricFieldOld1[i]);
		(*Grid).CurrentDensity1[i]=(*Species).Electrons.Charge*(*Species).Electrons.Flux1[i]
			+0.0*(*Species).Ions.Charge*(*Species).Ions.Flux1[i]
			+0.0*(*Grid).DisplacementCurrent1[i];
	}
}