/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function calculates Maxwell distribution (Box Muller Transform)
 ******************************************************************************/
void RecordCollisionEvents(GRID *Grid, SPECIES *Species)
{	
	int_m x;
/*	tb=0;*/
	
	for (x=0; x < NumberGridPoints; x++)
	{
		EventIonizationXT[x][TimeStepCollisionEvents] += (*Grid).EventIonization[x];
		EventExcitationXT[x][TimeStepCollisionEvents] += (*Grid).EventExcitation[x];
	}
	TimeStepCollisionEvents++;
	if ( TimeStepCollisionEvents % ((int_m)NumberTimeStepsLastPeriodsResolved) == 0) TimeStepCollisionEvents=0;
	for (x=0; x < NumberGridPoints; x++)
	{
		(*Grid).EventIonization[x] = 0.0;
		(*Grid).EventExcitation[x] = 0.0;
	}	
}
