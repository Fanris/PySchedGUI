/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function prints initial simulation parameters on the screen
 ******************************************************************************/
void PrintInitialScreen(GRID *Grid, SPECIES *Species)
{	
	/* Print a number of numbers on the screen */
	printf("Calculating simulation parameters ...\n");
	printf("... Gas pressure -> %e Pa\n",GasPressure);
	printf("... Gas energy -> %e eV\n",GasEnergy);
	printf("... Gas particles -> %e\n",NumberGasParticles);
	printf("... Gas density -> %e m^-3\n",GasDensity);
	printf("... Initial plasma density -> %e m^-3\n",InitialPlasmaDensity);
	printf("... Initial electron temperature -> %e K\n",InitialElectronTemperature);	
	printf("... Initial ion temperature -> %e K\n",InitialIonTemperature);
	printf("... Delta x -> %e m\n",DeltaX);
	printf("... Delta t -> %e s\n",DeltaT);
	printf("... Debye length / Delta x-> %e\n",sqrt(VacuumPermittivity
		*(*Species).Electrons.InitialEnergy/InitialPlasmaDensity/ElementaryCharge)/DeltaX);
	printf("... Delta t * Plasma frequency -> %e\n",DeltaT
		*sqrt(InitialPlasmaDensity*ElementaryCharge*ElementaryCharge
		/VacuumPermittivity/ElectronMass));
	printf("... Delta t * Electron collision frequency -> %e\n",DeltaT
		*CollisionFrequencyElectrons);	
	printf("... Stability up to -> %e m^-3\n",1/(DeltaT*DeltaT
		*ElementaryCharge*ElementaryCharge/VacuumPermittivity
		/ElectronMass/4.0/Pi/Pi));	
	printf("... Inner electrode area -> %e m^2\n",InnerElectrodeArea);
	if (CoordinateSystem == 0) printf("... Initial Weight -> %e m^-3\n",
		InitialPlasmaDensity*GapSize/InitialNumberParticles/DeltaX);
	printf("... Total number of timesteps -> %ld\n",(int_m)MaxNumberTimeSteps);
	if (ACFlag == 1) printf("... Number of timesteps per RF cycle -> %ld\n",
		(int_m)NumberTimeStepsPerCycle);
	if (ACFlag == 1) printf("... Total number of RF cycles -> %ld\n",
		(int_m)MaxNumberCycles);	
	printf("... Number of timesteps RF per cycle -> %ld\n",
		(int_m)NumberTimeStepsPerCycle);	
	printf("... Number of timesteps before starting averaging diagnostics -> %ld\n",
		(int_m)NumberTimeStepsStartLastPeriodsAveraging);
	if (IEDFReportFlag == 1) printf("... Number of timesteps before starting IEDF diagnostics -> %ld\n",
		(int_m)NumberTimeStepsStartLastPeriodsIEDF);
	if (TrackElectronFlag == 1)	printf("... Number of timesteps before starting electron tracking -> %ld\n", 
		(int_m)NumberTimeStepsStartElectronTracking);
	printf("The run starts right now ...\n\n");	
}

/*******************************************************************************
 * Function prints simulation parameters on the screen during the run
 ******************************************************************************/
void PrintScreen(GRID *Grid, SPECIES *Species)
{
	int_m EstimatedDays,EstimatedHours,EstimatedMinutes,EstimatedSeconds;
	int_m ElapsedDays,ElapsedHours,ElapsedMinutes,ElapsedSeconds;

	printf("\n");
	printf("Time steps / Total number of time steps -> %ld / %ld\n",
		TimeStep,(int_m)MaxNumberTimeSteps);
	printf("Time -> %e s\n",TimeStep*DeltaT);
	if (ACFlag==1) printf("RF Cycles / Total number of RF cycles -> %ld / %ld\n",
		NumberPeriod,(int_m)MaxNumberCycles);
	printf("Averaged computation time per PIC cycle -> %e s\n",TimePerCycle);

	ElapsedTotalTime=(ComputationTime-StartRun)/CLOCKS_PER_SEC;
	EstimatedTotalTime=ElapsedTotalTime+TimePerCycle*((int_m)MaxNumberTimeSteps-TimeStep);

	EstimatedDays=EstimatedTotalTime/86400;
	EstimatedTotalTime=EstimatedTotalTime%86400;
	EstimatedHours=EstimatedTotalTime/3600;
	EstimatedTotalTime=EstimatedTotalTime%3600;
	EstimatedMinutes=EstimatedTotalTime/60;
	EstimatedTotalTime=EstimatedTotalTime%60;
	EstimatedSeconds=EstimatedTotalTime;
	printf("Estimated computation time (D:H:M:S) -> %ld:%ld:%ld:%ld\n",
		   EstimatedDays,EstimatedHours,EstimatedMinutes,EstimatedSeconds);
	
	ElapsedDays=ElapsedTotalTime/86400;
	ElapsedTotalTime=ElapsedTotalTime%86400;
	ElapsedHours=ElapsedTotalTime/3600;
	ElapsedTotalTime=ElapsedTotalTime%3600;
	ElapsedMinutes=ElapsedTotalTime/60;
	ElapsedTotalTime=ElapsedTotalTime%60;
	ElapsedSeconds=ElapsedTotalTime;
	printf("Elapsed computation time (D:H:M:S) -> %ld:%ld:%ld:%ld\n",
		   ElapsedDays,ElapsedHours,ElapsedMinutes,ElapsedSeconds);
	
	printf("Number of super electrons -> %ld\n",(*Species).Electrons.Number);
	printf("Number of super ions -> %ld\n",(*Species).Ions.Number);
/*	printf("Relative change of super ion number -> %e\n",DeltaParticle);	*/
	printf("Relative change of super ion number (int) -> %e\n",DeltaParticle_i);
	printf("Relative change of super ion number (pro) -> %e\n",DeltaParticle_p);
	printf("Relative change of super ion number (dif) -> %e\n",DeltaParticle_d);
	printf("Averaged electron density -> %e m^-3\n",AveragedElectronDensity);
	printf("Averaged ion density -> %e m^-3\n",AveragedIonDensity);
	printf("Self bias voltage -> %e V\n",VBias);
	printf("Left electrode voltage -> %e V\n",VElectrodeLeft);			
	printf("Right electrode voltage -> %e V\n",VElectrodeRight);			
	printf("Current -> %e A\n",Current);
	if (CoordinateSystem==0)
	{
		printf("Weight at discharge point -> %e A\n",Weight);
	}
	else if (CoordinateSystem==1)
	{
		printf("Weight at discharge point -> %e A\n",SphericalWeight[NumberGridPoints/2]);
	}
	else if (CoordinateSystem==2)
	{
	}	
			
	printf("\n");
}
