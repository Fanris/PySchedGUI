/*******************************************************************************
 * y a p i c 
 * Version 2.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function calculates Maxwell distribution (Box Muller Transform)
 ******************************************************************************/

void MaxwellDistribution(float_m *VX1_Lokal,float_m *VX2_Lokal,float_m *VX3_Lokal,float_m VTH_Lokal)
{	
	float_m r1,r2;
	float_m vv;
	float_m vx1;
	float_m vx2;
	float_m vx3;
	do {r1=sqrt(fabs(-2.*log(RandomNumber()+1.e-20)));} while(r1>15.);
	r2=2.0*Pi*RandomNumber();
	do {vv=sqrt(fabs(-2.*log(RandomNumber()+1.e-20)));} while(vv >15.);
	vx1= vv*cos(2.0*Pi*RandomNumber())*VTH_Lokal;
	vx2=r1*cos(r2)*VTH_Lokal;
	vx3=r1*sin(r2)*VTH_Lokal;
	*VX1_Lokal=vx1;
	*VX2_Lokal=vx2;
	*VX3_Lokal=vx3;
}

