/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

void GenerateSpecies(SPECIES *Species)
{
	int_m i;
	float_m vth;
	float_m CrossSectionSum;
	float_m CollisionParameter;
	float_m MaxCollisionParameter;
	float_m Energy;
	float_m CollisionFrequency;
	
	/* First electrons */	
	printf("Generating %d electrons ... \n",InitialNumberParticles);		
	(*Species).Electrons.Number=InitialNumberParticles;
	(*Species).Electrons.Charge=-ElementaryCharge;
	(*Species).Electrons.Mass=ElectronMass;
	(*Species).Electrons.InitialEnergy=InitialElectronTemperature*BoltzmannConstant/fabs((*Species).Electrons.Charge); /* in eV */
	(*Species).Electrons.Position=(float_m*)calloc(MaxNumberSuperParticles,sizeof(float_m));						
	(*Species).Electrons.PositionOld=(float_m*)calloc(MaxNumberSuperParticles,sizeof(float_m));								
	(*Species).Electrons.Velocity1=(float_m*)calloc(MaxNumberSuperParticles,sizeof(float_m));
	(*Species).Electrons.Velocity2=(float_m*)calloc(MaxNumberSuperParticles,sizeof(float_m));
	(*Species).Electrons.Velocity3=(float_m*)calloc(MaxNumberSuperParticles,sizeof(float_m));
	(*Species).Electrons.Flux1=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Species).Electrons.Density=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	vth=sqrt( fabs((*Species).Electrons.Charge)*(*Species).Electrons.InitialEnergy/(*Species).Electrons.Mass );

	for (i=0;i<(*Species).Electrons.Number;i++)
	{
		MaxwellDistribution(&(*Species).Electrons.Velocity1[i],&(*Species).Electrons.Velocity2[i], 
			&(*Species).Electrons.Velocity3[i],vth);
		/* Cartesian grid */
		if (CoordinateSystem==0)
		{
			if (HomogeneousInitialDensityFlag==1) 
			{
				(*Species).Electrons.Position[i]=GapSize*RandomNumber();
				(*Species).Electrons.PositionOld[i]=(*Species).Electrons.Position[i];	
			}
			else if (HomogeneousInitialDensityFlag==0)
			{
				do
				{			
					(*Species).Electrons.Position[i] = GapSize * ( 0.5+sqrt(-0.1*log(RandomNumber()))*cos(2.0*Pi*RandomNumber()) );
					(*Species).Electrons.PositionOld[i] = (*Species).Electrons.Position[i];
				}
				while ((*Species).Electrons.Position[i] <= 0 || (*Species).Electrons.Position[i] >= GapSize);				
			}
		}
		/* Spherical or cylindrical grid */		
		else if (CoordinateSystem==1||CoordinateSystem==2)
			(*Species).Electrons.Position[i]=InnerElectrodeRadius+GapSize*RandomNumber();
	}
	printf("Initializing electron collision processes ... \n");
	if (GasFlag==1)
	{
		(*Species).Electrons.ProcessE1Sigma=ArgonElectronScatteringSigma;
		(*Species).Electrons.ProcessE2Sigma=ArgonElectronIonizationSigma;
		(*Species).Electrons.ProcessE3Sigma=ArgonElectronExcitationSigma;
	}
	else if (GasFlag==2)
	{
		(*Species).Electrons.ProcessE1Sigma=HeliumElectronScatteringSigma;
		(*Species).Electrons.ProcessE2Sigma=HeliumElectronIonizationSigma;
		(*Species).Electrons.ProcessE3Sigma=HeliumElectronExcitationSigmaTrip;
		(*Species).Electrons.ProcessE4Sigma=HeliumElectronExcitationSigmaSing;
	}
		MaxCollisionParameter=0.0;
		for (i=0;i<(int_m)(1000*MaximumElEnergyXSect);i++) 
		{
			Energy=0.001*i;
				if (GasFlag==1)
				{
					CrossSectionSum=(*Species).Electrons.ProcessE1Sigma(Energy) 
						+(*Species).Electrons.ProcessE2Sigma(Energy)+(*Species).Electrons.ProcessE3Sigma(Energy);
				}
				if (GasFlag==2)
				{
					CrossSectionSum=(*Species).Electrons.ProcessE1Sigma(Energy)+(*Species).Electrons.ProcessE2Sigma(Energy) 
						+(*Species).Electrons.ProcessE3Sigma(Energy)+(*Species).Electrons.ProcessE4Sigma(Energy);
				}				
			CollisionParameter=sqrt(Energy/(*Species).Electrons.Mass*(2.0*fabs((*Species).Electrons.Charge)))*CrossSectionSum;
			if (CollisionParameter>MaxCollisionParameter)
			{
			MaxCollisionParameter =CollisionParameter;
			}
	}
	(*Species).Electrons.MaxCollisionParameter=MaxCollisionParameter;
	CollisionFrequency=GasDensity*MaxCollisionParameter;
	(*Species).Electrons.CollisionProbability=1.0-exp(-CollisionFrequency*DeltaT);
	(*Species).Electrons.CollisionExtraFactor=0.5;	
	printf("... Collision probability for electrons -> %e\n",(*Species).Electrons.CollisionProbability);
	CollisionFrequencyElectrons=CollisionFrequency;
	/* Then ions */
	if (GasFlag==1)
	{
		printf("Generating %d argon ions ... \n",InitialNumberParticles);
		(*Species).Ions.Mass=ArgonMassFactor*AtomicMassUnit; /* in kg */
		(*Species).Ions.Charge=ArgonIonAtomicNumber*ElementaryCharge;
	}
	else if (GasFlag==2)
	{
		printf ("Generating %d helium ions ... \n",InitialNumberParticles);	
		(*Species).Ions.Mass=HeliumMassFactor*AtomicMassUnit; /* in kg */
		(*Species).Ions.Charge=HeliumIonAtomicNumber*ElementaryCharge;
	}
	(*Species).Ions.Number=InitialNumberParticles;
	(*Species).Ions.InitialEnergy=InitialIonTemperature*BoltzmannConstant/(*Species).Ions.Charge; /* in eV */
	(*Species).Ions.Position=(float_m*)calloc(MaxNumberSuperParticles,sizeof(float_m));								
	(*Species).Ions.PositionOld=(float_m*)calloc(MaxNumberSuperParticles,sizeof(float_m));								
	(*Species).Ions.Velocity1=(float_m*)calloc(MaxNumberSuperParticles,sizeof(float_m));
	(*Species).Ions.Velocity2=(float_m*)calloc(MaxNumberSuperParticles,sizeof(float_m));
	(*Species).Ions.Velocity3=(float_m*)calloc(MaxNumberSuperParticles,sizeof(float_m));
	(*Species).Ions.Flux1=(float_m*)calloc(NumberGridPoints,sizeof(float_m));		
	(*Species).Ions.Density=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	vth=sqrt((*Species).Ions.Charge*(*Species).Ions.InitialEnergy/(*Species).Ions.Mass);
	
	for (i=0;i<(*Species).Ions.Number;i++)
	{
		MaxwellDistribution(&(*Species).Ions.Velocity1[i],&(*Species).Ions.Velocity2[i],&(*Species).Ions.Velocity3[i],vth);
		if (CoordinateSystem==0)
		{
			if (HomogeneousInitialDensityFlag==1) 
			{
				(*Species).Ions.Position[i]=GapSize*RandomNumber();
				(*Species).Ions.PositionOld[i]=(*Species).Ions.Position[i];
			}
			else if (HomogeneousInitialDensityFlag==0)
			{
				do
				{			
					(*Species).Ions.Position[i] = GapSize * ( 0.5+sqrt(-0.1*log(RandomNumber()))*cos(2.0*Pi*RandomNumber()) );
					(*Species).Ions.PositionOld[i] = (*Species).Ions.Position[i];
				}
				while ((*Species).Ions.Position[i] <= 0 || (*Species).Ions.Position[i] >= GapSize);
			}
		}
		else if (CoordinateSystem==1||CoordinateSystem==2)
			(*Species).Ions.Position[i]=InnerElectrodeRadius+GapSize*RandomNumber();
	}
	printf ( "Initializing ion collision processes ... \n");
	if (GasFlag==1)
	{
		(*Species).Ions.ProcessI1Sigma=ArgonIonScatteringSigma;
		(*Species).Ions.ProcessI2Sigma=ArgonIonChargeExchangeSigma;
	}
	else if (GasFlag==2)
	{
		(*Species).Ions.ProcessI1Sigma=HeliumIonScatteringSigma;
		(*Species).Ions.ProcessI2Sigma=HeliumIonChargeExchangeSigma;
	}
	MaxCollisionParameter=0.0;
	for (i=0;i<=(int_m)(1000*MaximumIonEnergyXSect);i++) 
	{
		Energy=0.001*i;
		CrossSectionSum=(*Species).Ions.ProcessI1Sigma(Energy)+(*Species).Ions.ProcessI2Sigma(Energy);
		CollisionParameter=sqrt(4.0*Energy/(*Species).Ions.Mass*(*Species).Ions.Charge)*CrossSectionSum;
		if (CollisionParameter>MaxCollisionParameter)
		{
			MaxCollisionParameter=CollisionParameter;
		}
	}
	(*Species).Ions.MaxCollisionParameter=MaxCollisionParameter;
	CollisionFrequency=GasDensity*MaxCollisionParameter;
	(*Species).Ions.CollisionProbability=1.0-exp(-CollisionFrequency*DeltaT);
	(*Species).Ions.CollisionExtraFactor=0.5;
	printf( "... Collision probability for ions -> %e\n",(*Species).Ions.CollisionProbability);
}