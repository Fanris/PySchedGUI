/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function calculates Maxwell distribution (Box Muller Transform)
 ******************************************************************************/
void InitializeParameters()
{	
	int_m x,t;
	Seed=getpid();
	TimeStep=0;
	NumberPeriod=0;
	Time=0.0;
	TimeStepResolvedDiagnostics=0;
	TimeStepCollisionEvents=0;
	TimeStepTrackedElectrons=0;
	CollisionFrequencyElectrons=0.0;
	Weight=0.0;
	InitialWeight=0.0;
	for (x=0;x<NumberGridPoints;x++)
	{
		SphericalWeight[x]=0.0;
		SphericalInitialWeight[x]=0.0;
	}
	np=InitialNumberParticles;
	npold=InitialNumberParticles;
	DeltaParticle_i=0.0;
	DeltaParticle_p=0.0;
	DeltaParticle_d=0.0;
	AdaptiveWeightNumberParticles=InitialNumberParticles; 
	TimePerCycle=0.0;
	EstimatedTotalTime=0;
	ElapsedTotalTime=0;	
	pel1=0;
	pel2=0;
	pel3=0;
	pel4=0;
	pion1=0;
	pion2=0;
	Sigma=0.0;
	SigmaOld=0.0;
	QBias=0.0;
	QBiasOld=0.0;
	QBiasOldOld=0.0;
	QBiasOldOldOld=0.0;
	QBiasOldOldOld=0.0;
	K=0.0;
	Alpha0=2.25*ExternalL/DeltaT/DeltaT+1.5*ExternalR/DeltaT+1/ExternalC;
	Alpha1=-6.0*ExternalL/DeltaT/DeltaT-2.0*ExternalR/DeltaT;	
	Alpha2=5.5*ExternalL/DeltaT/DeltaT+0.5*ExternalR/DeltaT;
	Alpha3=-2.0*ExternalL/DeltaT/DeltaT;
	Alpha4=0.25*ExternalL/DeltaT/DeltaT;
	IonEnergyBinWidth=(float_m)MaximumIonEnergy/((float_m)MaximumNumberIonEnergyBins-1);
	IonAngleBinWidth=(float_m)MaximumIonAngle/((float_m)MaximumNumberIonAngleBins-1);
	ElectronEnergyBinWidth=(float_m)MaximumElectronEnergy/((float_m)MaximumNumberElectronEnergyBins-1);	
	
	if (CoordinateSystem==0)
		InnerElectrodeArea=InnerElectrodeRadius*InnerElectrodeRadius*Pi;
	else if (CoordinateSystem==1) 
		InnerElectrodeArea=4.0*Pi*InnerElectrodeRadius*InnerElectrodeRadius;
	else if (CoordinateSystem==2) 
		InnerElectrodeArea=2.0*Pi*InnerElectrodeRadius*CylinderLength;	
	
	/* Initializing a few arrays for diagnostics */	
	for (x=0;x<NumberGridPoints;x++)
	{
		ElectronDensityAve[x]=0.0;
		IonDensityAve[x]=0.0;
		ChargeDensityAve[x]+=0.0;
		ReducedElectricField1Ave[x]=0.0;
		PotentialAve[x]=0.0;
		PowerDensityAve[x]=0.0;
		for (t=0;t<(int_m)NumberTimeStepsLastPeriodsResolved;t++)
		{
			ElectronDensityXT[x][t]=0.0;
			IonDensityXT[x][t]=0.0;
			ChargeDensityXT[x][t]=0.0;
			ReducedElectricField1XT[x][t]=0.0;
			PotentialXT[x][t]=0.0;
			TrackedElectronsXT[x][t]=0.0;
			DisplacementCurrent1XT[x][t]=0.0;
			CurrentDensity1XT[x][t]=0.0;
			PowerDensityXT[x][t]=0.0;
			EventIonizationXT[x][t]=0.0;
			EventExcitationXT[x][t]=0.0;
			ElectronFluxXT[x][t]=0.0;
			IonFluxXT[x][t]=0.0;
		}
	}
	
	for (x=0;x<MaximumNumberIonEnergyBins;x++)
	{
		for (t=0;t<MaximumNumberIonAngleBins;t++)
		{
			IEDFLeft[x][t]=0.0;
			IEDFRight[x][t]=0.0;
		}
	}
	
	for (x=0;x<MaximumNumberElectronEnergyBins;x++)
	{
		EEDFLeft[x]=0.0;
		EEDFCenter[x]=0.0;
		EEDFRight[x]=0.0;
	}	
}