/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function generates a spatial grid and initializes a number of array
 ******************************************************************************/

void GenerateGrid (GRID *Grid)
{	
	int_m i;
	printf("Generating a spatial grid with ");
	printf("%d ",NumberGridPoints);
	printf("grid points ... \n");
	i=0;
 	/* Allocation of grid arrays */
	(*Grid).Position=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Grid).Potential=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Grid).ElectricField1=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Grid).ElectricFieldOld1=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Grid).DisplacementCurrent1=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Grid).CurrentDensity1=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Grid).MagneticField1=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Grid).MagneticField2=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Grid).MagneticField3=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Grid).ChargeDensity=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Grid).EventIonization=(float_m*)calloc(NumberGridPoints,sizeof(float_m));	
	(*Grid).EventExcitation=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
	(*Grid).FastElectrons=(float_m*)calloc(NumberGridPoints, sizeof(float_m));
	(*Grid).PowerDensity=(float_m*)calloc(NumberGridPoints,sizeof(float_m));
 	/* Generate the spatial grid */
	if (CoordinateSystem==0)
	{
		for (i=0;i<NumberGridPoints;i++)
		{
			(*Grid).Position[i]=(float_m)i*DeltaX;
			(*Grid).ChargeDensity[i]=0.0;
			(*Grid).MagneticField1[i]=0.0;
			(*Grid).MagneticField2[i]=0.0;
			(*Grid).MagneticField3[i]=0.0;
		}
		Weight=(float_m)(InitialPlasmaDensity*GapSize/InitialNumberParticles/DeltaX);
		InitialWeight=(float_m)(InitialPlasmaDensity*GapSize/InitialNumberParticles/DeltaX);			
	}
	else if (CoordinateSystem==1)
	{
		for (i=0;i<NumberGridPoints;i++)
		{
			(*Grid).Position[i]=InnerElectrodeRadius+(float_m)i*DeltaX;
			(*Grid).ChargeDensity[i]=0.0;
			SphericalWeight[i]=(float_m)(InitialPlasmaDensity*((InnerElectrodeRadius+GapSize)
				*(InnerElectrodeRadius+GapSize)*(InnerElectrodeRadius+GapSize)
				-InnerElectrodeRadius*InnerElectrodeRadius*InnerElectrodeRadius)
				/(3.0*InitialNumberParticles*DeltaX*((*Grid).Position[i])*((*Grid).Position[i])));
			SphericalInitialWeight[i]=(float_m)(InitialPlasmaDensity*((InnerElectrodeRadius+GapSize)
				*(InnerElectrodeRadius+GapSize)*(InnerElectrodeRadius+GapSize)
				-InnerElectrodeRadius*InnerElectrodeRadius*InnerElectrodeRadius)
				/(3.0*InitialNumberParticles*DeltaX*((*Grid).Position[i])*((*Grid).Position[i])));
		}			
	}
	else if (CoordinateSystem==2)		
	{
	}
}