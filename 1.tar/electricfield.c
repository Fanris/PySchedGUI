/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function calculates electric field and electric potential
 ******************************************************************************/
void CalculateField(GRID *Grid)
{
	int_m i;
	float_m m;
	float_m a[NumberGridPoints];
	float_m b[NumberGridPoints];
	float_m c[NumberGridPoints];
	float_m d[NumberGridPoints];
	memset(a,0.0,sizeof(a));
	memset(b,0.0,sizeof(b));
	memset(c,0.0,sizeof(c));
	memset(d,0.0,sizeof(d));
	if (CoordinateSystem==0)
	{
		if (CurrentSourceFlag==0)
		{
			if (ExternalR>0.0)
			{
				VElectrodeLeft=(*Grid).Potential[0];
				VSourceLeft=VoltageSourceLeft();
				VElectrodeRight=(*Grid).Potential[NumberGridPoints-1];			
				VSourceRight=VoltageSourceRight();
				QBiasOldOldOld=QBiasOldOld;
				QBiasOldOld=QBiasOld;
				QBiasOld=QBias;				
				QBias=(VSourceLeft-VElectrodeLeft)/Alpha0-K;
				VBias=QBias/ExternalC;
				Current=(QBias-QBiasOld)/DeltaT;
				SigmaOld=Sigma;
				Sigma+=(QConv-QConvOld)/InnerElectrodeArea+Current/InnerElectrodeArea*DeltaT;
				K = (Alpha1*QBias+Alpha2*QBiasOld+Alpha3*QBiasOldOld+Alpha4*QBiasOldOldOld)/Alpha0;
				for (i=0;i<=NumberGridPoints -1;i++)
				{
					a[i]=1.0;
					b[i]=-2.0;
					c[i]=1.0;
					d[i]=-DeltaX*DeltaX/VacuumPermittivity*(*Grid).ChargeDensity[i];
				}
				a[0]=0.0;
				b[0]=-1-DeltaX/(Alpha0*VacuumPermittivity*InnerElectrodeArea);
				d[0]=-(0.5*(*Grid).ChargeDensity[0]*DeltaX+Sigma
					+(QConv-QConvOld)/InnerElectrodeArea 
					+(VSourceLeft/Alpha0-K)/InnerElectrodeArea)
					*DeltaX/VacuumPermittivity;
				d[NumberGridPoints-1]=VSourceRight;
				for(i=1;i<=NumberGridPoints-1;i++)
				{
					m=a[i]/b[i-1];
					b[i]-=m*c[i-1];  
					d[i]-=m*d[i-1];
				}
				for(i=NumberGridPoints-2;i>=0;i--)
				{
					(*Grid).Potential[i]=(d[i]-c[i]*(*Grid).Potential[i+1])/b[i];
				}	
			}
			else 
			{
				/* External circuit stuff */
				QBiasOld=QBias;
				QBias=QBias-(QConv-QConvOld-VacuumPermittivity*InnerElectrodeArea 
					*(ElectricField1-ElectricField1Old));	
				Current=(QBias-QBiasOld)/DeltaT;
		/*		if (TimeStep<100*NumberTimeStepsPerCycle) QBias=0.0*ExternalC;*/
				VBias=QBias/ExternalC;
				VElectrodeLeft=(*Grid).Potential[0];
				VSourceLeft=VoltageSourceLeft();
				VElectrodeRight=(*Grid).Potential[NumberGridPoints-1];			
				VSourceRight=VoltageSourceRight();
				for (i=1;i<NumberGridPoints -1;i++)
				{
					a[i]=1.0;
					b[i]=-2.0;
					c[i]=1.0;
					d[i]=-DeltaX*DeltaX/VacuumPermittivity*(*Grid).ChargeDensity[i];
				}
				b[0]=1.0;
				c[0]=0.0;
				d[0]=VSourceLeft-VBias;
				a[NumberGridPoints-1]=0.0;
				b[NumberGridPoints-1]=1.0;
				d[NumberGridPoints-1]=VSourceRight;
				for(i=1;i<NumberGridPoints-1;i++)
				{
					m=a[i]/b[i-1];
					b[i]-=m*c[i-1];  
					d[i]-=m*d[i-1];
				}
				(*Grid).Potential[NumberGridPoints-1]=d[NumberGridPoints-1]/b[NumberGridPoints-1];
				for(i=NumberGridPoints-1;i>=0;i--)
				{
					(*Grid).Potential[i]=(d[i]-c[i]*(*Grid).Potential[i+1])/b[i];
				}
			}
		}
		else if (CurrentSourceFlag==1)
		{
			SigmaOld=Sigma;
			Sigma=SigmaOld+CurrentDensitySourceLeft()*DeltaT+(QConv-QConvOld)/InnerElectrodeArea;
			VElectrodeLeft=(*Grid).Potential[0];
			Current=CurrentDensitySourceLeft()*InnerElectrodeArea;
			for (i=1;i<NumberGridPoints-1;i++)
			{
				a[i]=1.0;
				b[i]=-2.0;
				c[i]=1.0;
				d[i]=-DeltaX*DeltaX/VacuumPermittivity*(*Grid).ChargeDensity[i];
			}
			b[0]=-1.0;
			c[0]=1.0;
			d[0]=-DeltaX/VacuumPermittivity*(Sigma+0.5*DeltaX*(*Grid).ChargeDensity[0]);
			a[NumberGridPoints-1]=0.0;
			b[NumberGridPoints-1]=1.0;
			for(i=1;i<NumberGridPoints;i++)
			{
				m=a[i]/b[i-1];
				b[i]-=m*c[i-1];  
				d[i]-=m*d[i-1];
			}
			(*Grid).Potential[NumberGridPoints-1]=d[NumberGridPoints-1]/b[NumberGridPoints-1];
			for(i=NumberGridPoints-2;i>=0;i--)
			{
				(*Grid).Potential[i]=(d[i]-c[i]*(*Grid).Potential[i+1])/b[i];
			}	
		}
		/***********************************************************************	
		 * Calculate the electric field
		 **********************************************************************/
		for (i=0;i<=NumberGridPoints -1;i++)
		{
			(*Grid).ElectricFieldOld1[i]=(*Grid).ElectricField1[i];
		}
		(*Grid).ElectricField1[0]=((*Grid).Potential[0] 
			-(*Grid).Potential[1])/DeltaX-(*Grid).ChargeDensity[0] 
			*DeltaX/2.0/VacuumPermittivity;
		for (i=1;i<NumberGridPoints-1;i++)
		{
			(*Grid).ElectricField1[i]=((*Grid).Potential[i-1]-(*Grid).Potential[i+1])/2.0/DeltaX;
		}	
		(*Grid).ElectricField1[NumberGridPoints-1] 
			=((*Grid).Potential[NumberGridPoints-2] 
			-(*Grid).Potential[NumberGridPoints-1] )/DeltaX 
			+(*Grid).ChargeDensity[NumberGridPoints-1]*DeltaX 
			/2.0/VacuumPermittivity;
		ElectricField1Old=ElectricField1;
		ElectricField1=(*Grid).ElectricField1[0];
	}
	else if (CoordinateSystem==1)		
	{
		if (CurrentSourceFlag==0)
		{
			QBiasOld=QBias;
			QBias=QBias-(QConv-QConvOld
				-VacuumPermittivity*InnerElectrodeArea*(ElectricField1-ElectricField1Old));	
			Current=(QBias-QBiasOld)/DeltaT;
			VBias=QBias/ExternalC;
			VElectrodeLeft=(*Grid).Potential[0];
			VSourceLeft=VoltageSourceLeft();
			VElectrodeRight=(*Grid).Potential[NumberGridPoints-1];			
			VSourceRight=VoltageSourceRight();
			for (i=1;i<NumberGridPoints-1;i++)
			{
				a[i]=1.0-DeltaX/(*Grid).Position[i];
				b[i]=-2.0;
				c[i]=1+DeltaX/(*Grid).Position[i];
				d[i]=-DeltaX*DeltaX/VacuumPermittivity*(*Grid).ChargeDensity[i];
			}
			b[0]=1.0;
			c[0]=0.0;
			d[0]=VoltageSourceLeft()-QBias/ExternalC;
			a[NumberGridPoints-1]=0.0;
			b[NumberGridPoints-1]=1.0;
			d[NumberGridPoints-1]=VSourceRight;
			for(i=1;i<NumberGridPoints-1;i++)
			{
				m=a[i]/b[i-1];
				b[i]-=m*c[i-1];  
				d[i]-=m*d[i-1];
			}
			(*Grid).Potential[NumberGridPoints-1]=d[NumberGridPoints-1]/b[NumberGridPoints-1];
			for(i=NumberGridPoints-2;i>=0;i--)
			{
				(*Grid).Potential[i]=(d[i]-c[i]*(*Grid).Potential[i+1])/b[i];
			}
		}
		else if (CurrentSourceFlag==1)
		{
		}
		/***********************************************************************	
		 * Calculate the electric field
		 **********************************************************************/
		for (i=0;i<=NumberGridPoints-1;i++)
		{
			(*Grid).ElectricFieldOld1[i]=(*Grid).ElectricField1[i];
		}
		(*Grid).ElectricField1[0]=((InnerElectrodeRadius+0.5*DeltaX) 
			*(InnerElectrodeRadius+0.5*DeltaX)
			*((*Grid).Potential[0]-(*Grid).Potential[1])/DeltaX)
			/(InnerElectrodeRadius* InnerElectrodeRadius)
			-((InnerElectrodeRadius+0.5*DeltaX) 
			*(InnerElectrodeRadius+0.5*DeltaX)
			*(InnerElectrodeRadius+0.5*DeltaX) 
			-InnerElectrodeRadius*InnerElectrodeRadius*InnerElectrodeRadius)
			*(*Grid).ChargeDensity[0]/(3.0*VacuumPermittivity
			*InnerElectrodeRadius*InnerElectrodeRadius);
		for (i=1;i<NumberGridPoints-1;i++)
		{
			(*Grid).ElectricField1[i]=((*Grid).Potential[i-1]-(*Grid).Potential[i+1])/2.0/DeltaX;
		}	
		(*Grid).ElectricField1[NumberGridPoints-1]=
			((InnerElectrodeRadius+GapSize - 0.5 * DeltaX) 
			*(InnerElectrodeRadius+GapSize-0.5*DeltaX)
			*((*Grid).Potential[NumberGridPoints-2]
			-(*Grid).Potential[NumberGridPoints-1])/DeltaX)
			/((InnerElectrodeRadius+GapSize)*(InnerElectrodeRadius+GapSize))
			+((InnerElectrodeRadius+GapSize)*(InnerElectrodeRadius+GapSize) 
			*(InnerElectrodeRadius+GapSize)-((InnerElectrodeRadius+GapSize) 
			-0.5*DeltaX)
			*((InnerElectrodeRadius+GapSize)-0.5*DeltaX)
			*((InnerElectrodeRadius+GapSize)-0.5*DeltaX))
			*(*Grid).ChargeDensity[NumberGridPoints-1]/(3.0*VacuumPermittivity
			*(InnerElectrodeRadius+GapSize)*(InnerElectrodeRadius+GapSize));
		ElectricField1Old=ElectricField1;
		ElectricField1=(*Grid).ElectricField1[0];
	}
	else if (CoordinateSystem==2)		
	{
	}
}