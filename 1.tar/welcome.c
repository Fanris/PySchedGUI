/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

void Welcome()
{
	printf("\ny a p i c\n");
	printf("Version 3.0\n");
	printf("Copyright (C) 2010, 2011, 2012\n");
	printf("Thomas Mussenbrock\n");
	printf("Ruhr University Bochum\n");				
	printf("http://homepages.rub.de/thomas.mussenbrock\n\n");
}
