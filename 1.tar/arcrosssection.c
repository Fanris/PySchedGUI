/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * A bunch of collision cross section for argon
 ******************************************************************************/
float_m ArgonElectronScatteringSigma(float_m eps)
{
	/* WITH Ramsauer minimum */
	if (eps<0.2) return 1./pow(10,19+eps/.11);
	else return 9.07e-19*pow(eps,1.55)*pow(eps+70.,1.1)/pow(14.+eps,3.25);
	/* WITHOUT Ramsauer minimum */
	/* return 9.07e-19*pow(eps,1.55)*pow(eps+70.,1.1)/pow(14.+eps,3.25);*/
}

float_m ArgonElectronIonizationSigma(float_m eps)
{
	if (eps<ArgonIonizationEnergy) return 0.;
	else return ((1.3596e-18/eps)*log((eps+120.0/eps)/15.76)
		*(atan((eps*eps-9.76*eps+2.4)/(20.6*eps+206)) 
		+atan((2*eps-80.0)/(10.3*eps+103.0))));
}

float_m ArgonElectronExcitationSigma(float_m eps)
{
	if (eps<ArgonExcitationEnergy) return 0.;
	else return (3.85116e-19*log(eps/3.4015)-4.85227e-19)/eps;
}

float_m ArgonIonScatteringSigma(float_m eps)
{
	return 1.e-20*21.6/sqrt(eps);
}

float_m ArgonIonChargeExchangeSigma(float_m eps)
{
	return 1.e-20*52./pow(eps,0.08)/(1.+0.08/eps) 
	/pow(1.+eps/1000.,0.3);
}

