/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function sets external magnetic field
 ******************************************************************************/

void SetMagneticField(GRID *Grid)
{
	int_m i;
	float_m Pos;
	
	if (CoordinateSystem == 0)
	{
		if (BSourceShape == 0) /* Rectangular shape */
		switch (BSourcePolarization)
		{
			case 1:
				break;
			case 2:
				for (i = 0; i < NumberGridPoints ; i++)
				{
					Pos = i * DeltaX;
					if (Pos >= (BSourceCenter-0.5*BSourceWidth) &&
						Pos <= (BSourceCenter+0.5*BSourceWidth))
						(*Grid).MagneticField2[i] = BSourceMax;
				}				
				break;
			case 3:
				for (i = 0; i < NumberGridPoints ; i++)
				{
					Pos = i * DeltaX;
					if (Pos >= (BSourceCenter-0.5*BSourceWidth) &&
						Pos <= (BSourceCenter+0.5*BSourceWidth))
						(*Grid).MagneticField2[i] = BSourceMax;
				}								
				break;
			default:
				printf("Magnetic Field: Wrong polarization flag.");
				break;
		}
		if (BSourceShape == 1)  /* Quasi-Lorentzian */
			switch (BSourcePolarization)
		{
			case 1:
				break;
			case 2:
				for (i = 0; i < NumberGridPoints ; i++)
				{
					(*Grid).MagneticField2[i] = BSourceMax 
						* pow(BSourceGamma,BSourceBeta) / (pow(BSourceGamma,BSourceBeta)
							+ pow( (*Grid).Position[i]-BSourceAlpha,BSourceBeta));
				}				
				break;
			case 3:
				for (i = 0; i < NumberGridPoints ; i++)
				{
					Pos = i * DeltaX;
					if (Pos >= (BSourceCenter-0.5*BSourceWidth) &&
						Pos <= (BSourceCenter+0.5*BSourceWidth))
						(*Grid).MagneticField2[i] = BSourceMax;
				}								
				break;
			default:
				printf("Magnetic Field: Wrong polarization flag.");
				break;
		}
	}
}


