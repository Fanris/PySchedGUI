/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function does secondary electron emission from the electrodes
 ******************************************************************************/
void DoSecondaryElectronEmission(GRID *Grid,SPECIES *Species)
{
	int_m i;
	int_m Number;
	float_m InitialVelocity=2.6e-2;
	/* Left electrode */
	for (i=1;i<=NumberSecondaryElectronsLeft;i++)
	{
		if (RandomNumber()<=SecondaryElectronGamma)
		{
			(*Species).Electrons.Number+=1;
			Number=(*Species).Electrons.Number-1;			
			(*Species).Electrons.Position[Number]=(*Grid).Position[1];			
			(*Species).Electrons.Velocity1[Number]=InitialVelocity;
			(*Species).Electrons.Velocity2[Number]=0.0;
			(*Species).Electrons.Velocity3[Number]=0.0;
			if (CoordinateSystem == 0)
			{
				QConv-=(*Species).Electrons.Charge*DeltaX*InnerElectrodeArea*Weight;
			}
			else if (CoordinateSystem == 1)
			{						
				QConv-=DeltaX*(4.0*Pi*InnerElectrodeRadius*InnerElectrodeRadius)*SphericalWeight[0];
			}
			else if (CoordinateSystem == 2)
			{						
			}			
		}		
	}	
	/* Right electrode */	
	for (i=1;i<=NumberSecondaryElectronsRight;i++)
	{
		if (RandomNumber()<=SecondaryElectronGamma)
		{
			(*Species).Electrons.Number+=1;
			Number=(*Species).Electrons.Number-1;			
			(*Species).Electrons.Position[Number]=(*Grid).Position[NumberGridPoints-2];			
			(*Species).Electrons.Velocity1[Number]=-InitialVelocity;
			(*Species).Electrons.Velocity2[Number]=0.0;
			(*Species).Electrons.Velocity3[Number]=0.0;
			if (CoordinateSystem == 0)
			{
				QConv-=(*Species).Electrons.Charge*DeltaX*InnerElectrodeArea*Weight;
			}
			else if (CoordinateSystem == 1)
			{						
				QConv-=DeltaX*(4.0*Pi*(InnerElectrodeRadius+GapSize)*(InnerElectrodeRadius+GapSize))*SphericalWeight[NumberGridPoints-1];
			}
			else if (CoordinateSystem == 2)
			{						
			}						
		}
	}
	NumberSecondaryElectronsLeft=0;
	NumberSecondaryElectronsRight=0;
}