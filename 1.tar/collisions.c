/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function performs collisions
 ******************************************************************************/
void DoCollisions(GRID *Grid, SPECIES *Species)
{
	int_m i;
/*	int_m j;*/
	int_m k;
	int_m l;
	int_m m;
	int_m n;
/*	int_m NumberCollisions;*/
/*	int_m CollisionIndex[MaxNumberSuperParticles];*/
/*	float_m Temp;*/
	float_m Velocity;
	float_m Energy, ResidualEnergy;
	float_m SigmaTotal;
	float_m SigmaRandom;
	float_m SigmaSum;
	float_m V1, V2, V3, Vel;
	float_m VNeutral1, VNeutral2, VNeutral3;
	int_m Flag;
	float_m IonizationPosition, ExcitationPosition;
	int_m x;
	
	k=0;
	l=0;
	m=0;
	n=0;

	/* First do electron collisions */
/*	NumberCollisions = 0;*/
	/* Calculate number of collisions */
/*	NumberCollisions=(float_m) (*Species).Electrons.Number 
		* (*Species).Electrons.CollisionProbability;*/
/*	(*Species).Electrons.CollisionExtraFactor += (float_m) (*Species).Electrons.Number 
		* (*Species).Electrons.CollisionProbability;
	NumberCollisions = (*Species).Electrons.CollisionExtraFactor;
	(*Species).Electrons.CollisionExtraFactor -= NumberCollisions;
*/	
	/* Define indizes of colliding particles */
/*	memset( CollisionIndex, -1, sizeof( CollisionIndex ) );
	for (i = 0; i < NumberCollisions; i++)
	{
		Temp = RandomNumber() * (float_m) (*Species).Electrons.Number;
		if ( i == -1)
		{			
			i =  (int_m) Temp;
		}
		else
		{
			j = i;
			do
			{
				CollisionIndex[j] =  j;
				j++;
			} 	
			while ( CollisionIndex[j] != -1);		
		}
	}
*/	
	/* Now the collisions */
	for (i = 0; i < (*Species).Electrons.Number; i++)
	{
		/* Calculate a few parameters */
		if (RandomNumber()<(*Species).Electrons.CollisionProbability)
		{
		
		Velocity = (*Species).Electrons.Velocity1[i]
			* (*Species).Electrons.Velocity1[i]
			+ (*Species).Electrons.Velocity2[i]
			* (*Species).Electrons.Velocity2[i]
			+ (*Species).Electrons.Velocity3[i]
			* (*Species).Electrons.Velocity3[i];
		Velocity = sqrt(Velocity);			
		Energy = Velocity * Velocity * (*Species).Electrons.Mass 
			/ 2.0 / fabs((*Species).Electrons.Charge);
		SigmaTotal = (*Species).Electrons.MaxCollisionParameter / Velocity;
		SigmaRandom = SigmaTotal * RandomNumber();	
		SigmaSum = 0.0;

		if (GasFlag == 1)
		{
			/* Do electron scattering*/
			if (SigmaRandom <= (SigmaSum = 
							(*Species).Electrons.ProcessE1Sigma(Energy)))
			{	
				pel1++;
				V1 = (*Species).Electrons.Velocity1[i] / Velocity;
				V2 = (*Species).Electrons.Velocity2[i] / Velocity;
				V3 = (*Species).Electrons.Velocity3[i] / Velocity;
				Vel = Velocity;
				Flag = 1;
				NewVelocity( &(*Species), &V1, &V2, &V3, &Vel, &Energy, Flag);
				(*Species).Electrons.Velocity1[i] = V1;
				(*Species).Electrons.Velocity2[i] = V2;
				(*Species).Electrons.Velocity3[i] = V3;			
			}
			/* Do electron ionization */
			else if (Energy >= ArgonIonizationEnergy 
				&& SigmaRandom <= (SigmaSum 
				+= (*Species).Electrons.ProcessE2Sigma(Energy)))
			{
				pel2++;
				Energy = Energy - ArgonIonizationEnergy;
				ResidualEnergy = Energy / 2.0;
				Energy = Energy - ResidualEnergy;

				/* Generate electrons */
				k = (*Species).Electrons.Number + l;
				++l;
				V1 = (*Species).Electrons.Velocity1[i] / Velocity;
				V2 = (*Species).Electrons.Velocity2[i] / Velocity;
				V3 = (*Species).Electrons.Velocity3[i] / Velocity;
				Flag = 0;
				Vel = sqrt( 2.0 * fabs(ResidualEnergy) 
					* fabs((*Species).Electrons.Charge) 
					/ (*Species).Electrons.Mass);
				NewVelocity( &(*Species), &V1, &V2, &V3, &Vel, 
						&ResidualEnergy, Flag);
				(*Species).Electrons.Velocity1[k] = V1;
				(*Species).Electrons.Velocity2[k] = V2;
				(*Species).Electrons.Velocity3[k] = V3;
				(*Species).Electrons.Position[k] = 
					(*Species).Electrons.Position[i];

				/* Generate ions */
				m = (*Species).Ions.Number + n;
				++n;			
				(*Species).Ions.Position[m] = 
					(*Species).Electrons.Position[i];
				MaxwellDistribution(&VNeutral1,&VNeutral2,&VNeutral3,GasVelocity);								
				(*Species).Ions.Velocity1[m] = VNeutral1;
				(*Species).Ions.Velocity2[m] = VNeutral2;
				(*Species).Ions.Velocity3[m] = VNeutral3;
				
				/* Scatter incident electron */
				V1 = (*Species).Electrons.Velocity1[i] / Velocity;
				V2 = (*Species).Electrons.Velocity2[i] / Velocity;
				V3 = (*Species).Electrons.Velocity3[i] / Velocity;
				Flag = 0;
				Vel = sqrt( 2.0 * fabs(Energy) * fabs((*Species).Electrons.Charge) 
					   / (*Species).Electrons.Mass);				
				NewVelocity( &(*Species), &V1, &V2, &V3, &Vel, &Energy, Flag);
				(*Species).Electrons.Velocity1[i] = V1;
				(*Species).Electrons.Velocity2[i] = V2;
				(*Species).Electrons.Velocity3[i] = V3;
			
				/*******************************************************************
				 * Calculate spatial distribution of ionization events
				 ******************************************************************/
				if (EventIonizationFlag == 1 && TimeStep 
					>= (int_m)NumberTimeStepsStartLastPeriodsEvents)
				{
					IonizationPosition = (*Species).Electrons.Position[k];
					for (x=0; x<NumberGridPoints; x++)
					{
						if ((*Grid).Position[x]>IonizationPosition)
						{
							(*Grid).EventIonization[x-1] += 1 
								- ( (*Grid).Position[x] - IonizationPosition ); 
							(*Grid).EventIonization[x] += (*Grid).Position[x]
								- IonizationPosition;
							x = NumberGridPoints;
						}			
					}
				}
			}
			/* Do electron excitation */
			else if (Energy >= ArgonExcitationEnergy 
				&& SigmaRandom <= (SigmaSum 
					+= (*Species).Electrons.ProcessE3Sigma(Energy)))
			{
				pel3++;
				V1 = (*Species).Electrons.Velocity1[i] / Velocity;
				V2 = (*Species).Electrons.Velocity2[i] / Velocity;
				V3 = (*Species).Electrons.Velocity3[i] / Velocity;
				Flag = 0;
				Energy -= ArgonExcitationEnergy;
				Vel = sqrt( 2.0 * fabs(Energy) * fabs((*Species).Electrons.Charge) 
						   / (*Species).Electrons.Mass);			
				NewVelocity( &(*Species), &V1, &V2, &V3, &Vel, &Energy, Flag);
				(*Species).Electrons.Velocity1[i] = V1;
				(*Species).Electrons.Velocity2[i] = V2;
				(*Species).Electrons.Velocity3[i] = V3;	
				
				/*******************************************************************
				 * Calculate spatial distribution of excitation events
				 ******************************************************************/
				if (EventExcitationFlag == 1 && TimeStep 
					>= (int_m)NumberTimeStepsStartLastPeriodsEvents)
				{
					ExcitationPosition = (*Species).Electrons.Position[i];
					for (x=0; x<NumberGridPoints; x++)
					{
						if ((*Grid).Position[x]>ExcitationPosition)
						{
							(*Grid).EventExcitation[x-1] += 1 
							- ( (*Grid).Position[x] - ExcitationPosition ); 
							(*Grid).EventExcitation[x] += (*Grid).Position[x]
							- ExcitationPosition;
							x = NumberGridPoints;
						}			
					}
				}
			}		
		}		
		else if (GasFlag == 2)
		{
		/* Do electron scattering*/
			if (SigmaRandom <= (SigmaSum = 
						(*Species).Electrons.ProcessE1Sigma(Energy)))
			{	
				pel1++;
				V1 = (*Species).Electrons.Velocity1[i] / Velocity;
				V2 = (*Species).Electrons.Velocity2[i] / Velocity;
				V3 = (*Species).Electrons.Velocity3[i] / Velocity;
				Vel = Velocity;
				Flag = 1;
				NewVelocity( &(*Species), &V1, &V2, &V3, &Vel, &Energy, Flag);
				(*Species).Electrons.Velocity1[i] = V1;
				(*Species).Electrons.Velocity2[i] = V2;
				(*Species).Electrons.Velocity3[i] = V3;			
			}
			/* Do electron ionization */
			else if (Energy >= HeliumIonizationEnergy 
				&& SigmaRandom <= (SigmaSum 
				+= (*Species).Electrons.ProcessE2Sigma(Energy)))
			{
				pel2++;
				Energy = Energy - HeliumIonizationEnergy;
				ResidualEnergy = Energy / 2.0;
			/*	ResidualEnergy=2.0*tan(RandomNumber()*atan(Energy/20.0));*/
			/*	ResidualEnergy = Energy * RandomNumber();*/
				Energy = Energy - ResidualEnergy;

				/* Generate electrons */
				k = (*Species).Electrons.Number + l;
				++l;
				V1 = (*Species).Electrons.Velocity1[i] / Velocity;
				V2 = (*Species).Electrons.Velocity2[i] / Velocity;
				V3 = (*Species).Electrons.Velocity3[i] / Velocity;
				Flag = 0;
				Vel = sqrt( 2.0 * fabs(ResidualEnergy) 
					* fabs((*Species).Electrons.Charge) 
					/ (*Species).Electrons.Mass);
				NewVelocity( &(*Species), &V1, &V2, &V3, &Vel, 
							&ResidualEnergy, Flag);
				(*Species).Electrons.Velocity1[k] = V1;
				(*Species).Electrons.Velocity2[k] = V2;
				(*Species).Electrons.Velocity3[k] = V3;
				(*Species).Electrons.Position[k] = 
					(*Species).Electrons.Position[i];

				/* Generate ions */
				m = (*Species).Ions.Number + n;
				++n;			
				(*Species).Ions.Position[m] = 
					(*Species).Electrons.Position[i];
				MaxwellDistribution(&VNeutral1,&VNeutral2,&VNeutral3,GasVelocity);								
				(*Species).Ions.Velocity1[m] = VNeutral1;
				(*Species).Ions.Velocity2[m] = VNeutral2;
				(*Species).Ions.Velocity3[m] = VNeutral3;
				
				/* Scatter incident electron */
				V1 = (*Species).Electrons.Velocity1[i] / Velocity;
				V2 = (*Species).Electrons.Velocity2[i] / Velocity;
				V3 = (*Species).Electrons.Velocity3[i] / Velocity;
				Flag = 0;
				Vel = sqrt( 2.0 * fabs(Energy) * fabs((*Species).Electrons.Charge) 
						   / (*Species).Electrons.Mass);				
				NewVelocity( &(*Species), &V1, &V2, &V3, &Vel, &Energy, Flag);
				(*Species).Electrons.Velocity1[i] = V1;
				(*Species).Electrons.Velocity2[i] = V2;
				(*Species).Electrons.Velocity3[i] = V3;
			
				/*******************************************************************
				 * Calculate spatial distribution of ionization events
				 ******************************************************************/
				if (EventIonizationFlag == 1 && TimeStep 
					>= (int_m)NumberTimeStepsStartLastPeriodsEvents)
				{
					IonizationPosition = (*Species).Electrons.Position[k];
					for (x=0; x<NumberGridPoints; x++)
					{
						if ((*Grid).Position[x]>IonizationPosition)
						{
							(*Grid).EventIonization[x-1] += 1 
								- ( (*Grid).Position[x] - IonizationPosition ); 
							(*Grid).EventIonization[x] += (*Grid).Position[x]
								- IonizationPosition;
							x = NumberGridPoints;
						}			
					}
				}
			}
			/* Do electron excitation (Triplet) */
			else if (Energy >= HeliumExcitationEnergyTrip 
				&& SigmaRandom <= (SigmaSum 
					+= (*Species).Electrons.ProcessE3Sigma(Energy)))
			{
				pel3++;
				V1 = (*Species).Electrons.Velocity1[i] / Velocity;
				V2 = (*Species).Electrons.Velocity2[i] / Velocity;
				V3 = (*Species).Electrons.Velocity3[i] / Velocity;
				Flag = 0;
				Energy -= HeliumExcitationEnergyTrip;
				Vel = sqrt( 2.0 * fabs(Energy) * fabs((*Species).Electrons.Charge) 
						   / (*Species).Electrons.Mass);			
				NewVelocity( &(*Species), &V1, &V2, &V3, &Vel, &Energy, Flag);
				(*Species).Electrons.Velocity1[i] = V1;
				(*Species).Electrons.Velocity2[i] = V2;
				(*Species).Electrons.Velocity3[i] = V3;
				
				/*******************************************************************
				 * Calculate spatial distribution of excitation events
				 ******************************************************************/
				if (EventExcitationFlag == 1 && TimeStep 
					>= (int_m)NumberTimeStepsStartLastPeriodsEvents)
				{
					ExcitationPosition = (*Species).Electrons.Position[i];
					for (x=0; x<NumberGridPoints; x++)
					{
						if ((*Grid).Position[x]>ExcitationPosition)
						{
							(*Grid).EventExcitation[x-1] += 1 
							- ( (*Grid).Position[x] - ExcitationPosition ); 
							(*Grid).EventExcitation[x] += (*Grid).Position[x]
							- ExcitationPosition;
							x = NumberGridPoints;
						}			
					}
				}
			}
			/* Do electron excitation (Singlet) */
			else if (Energy >= HeliumExcitationEnergySing 
				&& SigmaRandom <= (SigmaSum 
					+= (*Species).Electrons.ProcessE4Sigma(Energy)))
			{
				pel4++;
				V1 = (*Species).Electrons.Velocity1[i] / Velocity;
				V2 = (*Species).Electrons.Velocity2[i] / Velocity;
				V3 = (*Species).Electrons.Velocity3[i] / Velocity;
				Flag = 0;
				Energy -= HeliumExcitationEnergySing;
				Vel = sqrt( 2.0 * fabs(Energy) * fabs((*Species).Electrons.Charge) 
						   / (*Species).Electrons.Mass);	
				NewVelocity( &(*Species), &V1, &V2, &V3, &Vel, &Energy, Flag);
				(*Species).Electrons.Velocity1[i] = V1;
				(*Species).Electrons.Velocity2[i] = V2;
				(*Species).Electrons.Velocity3[i] = V3;
				
				/*******************************************************************
				 * Calculate spatial distribution of excitation events
				 ******************************************************************/
				if (EventExcitationFlag == 1 && TimeStep 
					>= (int_m)NumberTimeStepsStartLastPeriodsEvents)
				{
					ExcitationPosition = (*Species).Electrons.Position[i];
					for (x=0; x<NumberGridPoints; x++)
					{
						if ((*Grid).Position[x]>ExcitationPosition)
						{
							(*Grid).EventExcitation[x-1] += 1 
							- ( (*Grid).Position[x] - ExcitationPosition ); 
							(*Grid).EventExcitation[x] += (*Grid).Position[x]
							- ExcitationPosition;
							x = NumberGridPoints;
						}			
					}
				}
			}
		}
		}
	}
	
	/* Then do ion collisions */
/*	NumberCollisions = 0;*/
	/* Calculate number of collisions */	
/*	NumberCollisions=(float_m) (*Species).Ions.Number 
		* (*Species).Ions.CollisionProbability;*/
	
/*	(*Species).Ions.CollisionExtraFactor += (float_m) (*Species).Ions.Number 
	* (*Species).Ions.CollisionProbability;
	NumberCollisions = (*Species).Ions.CollisionExtraFactor;
	(*Species).Ions.CollisionExtraFactor -= NumberCollisions;
	
*/	
	/* Define indizes of colliding particles */
/*	memset( CollisionIndex, -1, sizeof( CollisionIndex ) );
	for (i = 0; i < NumberCollisions; i++)
	{
		Temp = RandomNumber() * (float_m) (*Species).Ions.Number;
		if ( i == -1)
		{			
			i = (int_m) Temp;
		}
		else
		{
			j = i;
			do
			{
				CollisionIndex[j] = j;
				j++;
			} 	
			while ( CollisionIndex[j] != -1);		
		}
	}
	*/
	/* Now the collisions */
	for (i = 0; i < (*Species).Ions.Number; i++)
	{
		if (RandomNumber()<(*Species).Ions.CollisionProbability)
		{

		/* Calculate a few parameters */
		MaxwellDistribution(&VNeutral1, &VNeutral2, &VNeutral3, GasVelocity);
		V1 = (*Species).Ions.Velocity1[i] - VNeutral1;
		V2 = (*Species).Ions.Velocity2[i] - VNeutral2;
		V3 = (*Species).Ions.Velocity3[i] - VNeutral3;	
		Velocity = sqrt(V1*V1+V2*V2+V3*V3); 
		Energy = Velocity * Velocity * (*Species).Ions.Mass 
			/ 4.0 / fabs((*Species).Ions.Charge);
		SigmaTotal = (*Species).Ions.MaxCollisionParameter / Velocity;
		SigmaRandom = SigmaTotal * RandomNumber();	
		SigmaSum = 0.0;
		
		/* Do ion scattering*/
		if (SigmaRandom <= (SigmaSum = (*Species).Ions.ProcessI1Sigma(Energy)))
		{	
			pion1++;
			V1 /= Velocity;
			V2 /= Velocity;
			V3 /= Velocity;
			Vel = Velocity;
			Flag = 2;
			NewVelocity( &(*Species), &V1, &V2, &V3, &Vel, &Energy, Flag);
			(*Species).Ions.Velocity1[i] = V1 + VNeutral1;
			(*Species).Ions.Velocity2[i] = V2 + VNeutral2;
			(*Species).Ions.Velocity3[i] = V3 + VNeutral3;
		}
		/* Do ion charge exchange */
		else if (SigmaRandom <= (SigmaSum 
								 += (*Species).Ions.ProcessI2Sigma(Energy)))
		{
			pion2++;
			(*Species).Ions.Velocity1[i] = VNeutral1;
			(*Species).Ions.Velocity2[i] = VNeutral2;
			(*Species).Ions.Velocity3[i] = VNeutral3;
		}
	}
	}
	(*Species).Electrons.Number += l;
	(*Species).Ions.Number += n;
}	

/*******************************************************************************
 * Function calculates new velocity after collision
 ******************************************************************************/
void NewVelocity(SPECIES *Species, float_m *V1Local, float_m *V2Local, 
	float_m *V3Local, float_m *VelLocal, float_m *EnergyLocal, int_m Flag)
{
	float_m up1, up2, up3, mag;
	float_m r11, r12, r13, r21, r22, r23, r31, r32, r33;
	float_m phi;
	float_m sinphi;
	float_m cosphi;
	float_m sinchi;
	float_m coschi;
	float_m v1 = *V1Local;
	float_m v2 = *V2Local;
	float_m v3 = *V3Local;
	float_m vel = *VelLocal;
	float_m en = *EnergyLocal;
	
	if (Flag == 2)
	{
		coschi = sqrt( RandomNumber() );
	}
	else
	{
		if (en < 1e-30) coschi = 1.0;
		else coschi = 1.0 - 2.0 * RandomNumber();
	}		
	
	sinchi = sqrt(fabs(1.0 - coschi * coschi));
	phi = 2.0 * Pi * RandomNumber();
	cosphi = cos(phi);
	sinphi = sin(phi);

	if (Flag == 1)
	{
		vel = vel * sqrt(1.0 - 2.0 * (*Species).Electrons.Mass 
						 * (1 - coschi) / (*Species).Ions.Mass);
	}
	
	r13 = v1;
	r23 = v2;
	r33 = v3;

	if (r33 == 1.0)
	{
		up1 = 0;
		up2 = 1;
		up3 = 0;
	}
	else
	{
		up1 = 0;
		up2 = 0;
		up3 = 1;
	}
	
	r12 = r23 * up3 - r33 * up2;
	r22 = r33 * up1 - r13 * up3;
	r32 = r13 * up2 - r23 * up1;
	mag = sqrt(r12 * r12 + r22 * r22 + r32 * r32);
	r12 = r12 / mag;
	r22 = r22 / mag;
	r32 = r32 / mag;
	r11 = r22 * r33 - r32 * r23;
	r21 = r32 * r13 - r12 * r33;
	r31 = r12 * r23 - r22 * r13;
	
	if (Flag == 2)
	{	
	/*	vel *= coschi;*/
		
		v1 = vel * coschi * (r11 * sinchi * cosphi + 
									  r12 * sinchi * sinphi + r13 * coschi);
		v2 = vel * coschi * (r21 * sinchi * cosphi + 
									  r22 * sinchi * sinphi + r23 * coschi); 
		v3 = vel * coschi * (r31 * sinchi * cosphi + 
									  r32 * sinchi * sinphi + r33 * coschi);		
	}
	else
	{
		v1 = vel * (r11 * sinchi * cosphi + 
					r12 * sinchi * sinphi + r13 * coschi);
		v2 = vel * (r21 * sinchi * cosphi + 
					r22 * sinchi * sinphi + r23 * coschi); 
		v3 = vel * (r31 * sinchi * cosphi + 
					r32 * sinchi * sinphi + r33 * coschi);
	}
	*V1Local = v1;
	*V2Local = v2;
	*V3Local = v3;		
}
