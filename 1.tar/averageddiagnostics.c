/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function does the time averaged diagnostics
 ******************************************************************************/
void LastPeriodsAveragedDiagnostics(GRID *Grid,SPECIES *Species)
{	
	int x;
	for (x=0;x<NumberGridPoints;x++)
	{
		ElectronDensityAve[x]+=(*Species).Electrons.Density[x]/NumberTimeStepsLastPeriodsAveraging;
		ElectronFluxAve[x]+=(*Species).Electrons.Flux1[x]/NumberTimeStepsLastPeriodsAveraging;
		IonDensityAve[x]+=(*Species).Ions.Density[x]/NumberTimeStepsLastPeriodsAveraging;
		IonFluxAve[x]+=(*Species).Ions.Flux1[x]/NumberTimeStepsLastPeriodsAveraging;
		ChargeDensityAve[x]+=(*Grid).ChargeDensity[x]/NumberTimeStepsLastPeriodsAveraging;
		ElectricField1Ave[x]+=(*Grid).ElectricField1[x]/NumberTimeStepsLastPeriodsAveraging;
		ReducedElectricField1Ave[x]+=(*Grid).ElectricField1[x]/GasDensity*1e21/NumberTimeStepsLastPeriodsAveraging;
		PotentialAve[x]+=(*Grid).Potential[x]/NumberTimeStepsLastPeriodsAveraging;
		CurrentDensity1Ave[x]+=(*Grid).CurrentDensity1[x]/NumberTimeStepsLastPeriodsAveraging;
		DisplacementCurrent1Ave[x]+=(*Grid).DisplacementCurrent1[x]/NumberTimeStepsLastPeriodsAveraging;
		PowerDensityAve[x]+=((*Grid).CurrentDensity1[x]*(*Grid).ElectricField1[x])/NumberTimeStepsLastPeriodsAveraging;
	}
}