/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function calculates charge density on the grid after charge assignment
 ******************************************************************************/
void CalculateChargeDensity(GRID *Grid, SPECIES *Species)
{
	int_m i;
	int_m j;
	int_m TrackedElectron=0;
	int_m GridPoint=0;
	float_m Distance=0.0;
	float_m LeftValue;
	float_m CenterValue;
	float_m RightValue;
	float_m Velocity2;
	float_m Energy;
	
	for (i=0;i<NumberGridPoints;i++)
	{
		(*Species).Electrons.Density[i]=0.0;
		(*Species).Ions.Density[i]=0.0;
		(*Grid).FastElectrons[i]=0.0;
	}

	if (CoordinateSystem==0)
	{
/*		#pragma omp parallel for private(GridPoint,Distance) reduction (+:&(*Species).Electrons.Density) */
		for (i = 0; i < (*Species).Electrons.Number; i++)
		{
			GridPoint=(int_m)((*Species).Electrons.Position[i]/DeltaX);
			Distance=(*Species).Electrons.Position[i]/DeltaX-(float_m)GridPoint;
			(*Species).Electrons.Density[GridPoint]+=(1.0-Distance)*Weight;
			(*Species).Electrons.Density[GridPoint+1]+=Distance*Weight;			
			/***************************************************************
			 * Tracking fast electrons
			 **************************************************************/				
			if (FastElectronsFlag==1) 
			{
				Velocity2=(*Species).Electrons.Velocity1[i]*(*Species).Electrons.Velocity1[i]
					+(*Species).Electrons.Velocity2[i]*(*Species).Electrons.Velocity2[i]
					+(*Species).Electrons.Velocity3[i]*(*Species).Electrons.Velocity3[i];
				Energy=Velocity2*(*Species).Electrons.Mass/2.0/fabs((*Species).Electrons.Charge);
				if (Energy>=FastElectronsThreshold)
				{
					(*Grid).FastElectrons[GridPoint]+=(1.0-Distance)*Weight;
					(*Grid).FastElectrons[GridPoint+1]+=Distance*Weight;
					if (TrackElectronFlag==1&&TimeStep==(int_m)NumberTimeStepsStartElectronTracking)
					{
						if (TrackedElectron<(int_m)NumberTrackedElectrons)
						{
							TrackedElectronIndex[TrackedElectron]=i;
							TrackedElectron++;
						}
					}					
				}				
			}
		}
		for (i = 0; i < (*Species).Ions.Number; i++)
		{
			GridPoint=(int_m)((*Species).Ions.Position[i]/DeltaX);
			Distance=(*Species).Ions.Position[i]/DeltaX-(float_m)GridPoint;			
			(*Species).Ions.Density[GridPoint]+=(1.0-Distance)*Weight;
			(*Species).Ions.Density[GridPoint+1]+=Distance*Weight;
		}
	}
	else if (CoordinateSystem==1)		
	{
		for (i=0;i<(*Species).Electrons.Number; i++)
		{			
			GridPoint=(int_m)(((*Species).Electrons.Position[i]-InnerElectrodeRadius)/DeltaX);
			Distance=((*Species).Electrons.Position[i]-InnerElectrodeRadius)/DeltaX-(float_m)GridPoint;		
			(*Species).Electrons.Density[GridPoint]+=(1.0-Distance)*SphericalWeight[GridPoint];
			(*Species).Electrons.Density[GridPoint+1]+=Distance*SphericalWeight[GridPoint+1];
			/***************************************************************
			 * Tracking fast electrons
			 **************************************************************/				
			if (FastElectronsFlag == 1) 
			{
				Velocity2 = (*Species).Electrons.Velocity1[i]*(*Species).Electrons.Velocity1[i]
					+(*Species).Electrons.Velocity2[i]*(*Species).Electrons.Velocity2[i]
					+(*Species).Electrons.Velocity3[i]*(*Species).Electrons.Velocity3[i];
				Energy=Velocity2*(*Species).Electrons.Mass/2.0/fabs((*Species).Electrons.Charge);
				if (Energy>=FastElectronsThreshold)
				{
					(*Grid).FastElectrons[GridPoint]+=(1.0-Distance)*SphericalWeight[GridPoint];
					(*Grid).FastElectrons[GridPoint+1]+=Distance*SphericalWeight[GridPoint+1];
				}				
			}
		}
		for (i=0;i<(*Species).Ions.Number;i++)
		{
			GridPoint=(int_m)(((*Species).Ions.Position[i]-InnerElectrodeRadius)/DeltaX);
			Distance=((*Species).Ions.Position[i]-InnerElectrodeRadius)/DeltaX-(float_m)GridPoint;
			(*Species).Ions.Density[GridPoint]+=(1.0-Distance)*SphericalWeight[GridPoint];
			(*Species).Ions.Density[GridPoint+1]+=Distance*SphericalWeight[GridPoint+1];
		}		
	}
	else if (CoordinateSystem==2)		
	{
	}	

	(*Species).Electrons.Density[0]*=2.0;
	(*Species).Electrons.Density[NumberGridPoints-1]*=2.0;
	(*Species).Ions.Density[0]*=2.0;
	(*Species).Ions.Density[NumberGridPoints-1]*=2.0;
				
	/* Smoothing of the individual particle densities */
	if (SmoothingFlagDensities==1)
	{
		for (j=0;j<=50;j++)
		{
			/* First electrons */
			LeftValue=(*Species).Electrons.Density[0];
			CenterValue=(*Species).Electrons.Density[1];
			RightValue=(*Species).Electrons.Density[2];
			(*Species).Electrons.Density[0]=(3.0*LeftValue+CenterValue)/4.0;
			for(i=1;i<NumberGridPoints;i++)
			{
				(*Species).Electrons.Density[i]=(LeftValue+2.0*CenterValue+RightValue)/4.0;
				LeftValue=CenterValue;
				CenterValue=RightValue;
				if (i<NumberGridPoints-2)
				{
					RightValue=(*Species).Electrons.Density[i+2];
				}
			}  
			(*Species).Electrons.Density[NumberGridPoints-1]=(3.0*CenterValue+LeftValue)/4.0;
			/* Then ions */		
			LeftValue=(*Species).Ions.Density[0];
			CenterValue=(*Species).Ions.Density[1];
			RightValue=(*Species).Ions.Density[2];
			(*Species).Ions.Density[0]=(3.0*LeftValue+CenterValue)/4.0;
			for(i=1;i<NumberGridPoints;i++)
			{
				(*Species).Ions.Density[i]=(LeftValue+2.0*CenterValue+RightValue)/4.0;
				LeftValue=CenterValue;
				CenterValue=RightValue;
				if (i<NumberGridPoints-2)
				{
					RightValue=(*Species).Ions.Density[i+2];
				}
			}  
			(*Species).Ions.Density[NumberGridPoints-1]=(3.0*CenterValue+LeftValue)/4.0;	
		}	
	}
	
	/* Calculating the charge density on the grid */
	for (i=0;i<NumberGridPoints;i++)
	{
		(*Grid).ChargeDensity[i]=(*Species).Electrons.Charge*(*Species).Electrons.Density[i]
			+(*Species).Ions.Charge*(*Species).Ions.Density[i];
	}
	
	/* Smooting of the charge density */
	if (SmoothingFlagChargeDensity==1)
	{
		for (j=0;j<=50;j++)
		{
			LeftValue=(*Grid).ChargeDensity[0];
			CenterValue=(*Grid).ChargeDensity[1];
			RightValue=(*Grid).ChargeDensity[2];
			(*Grid).ChargeDensity[0]=(3.0*LeftValue+CenterValue)/4.0;
			for(i=1;i<NumberGridPoints;i++)
			{
				(*Grid).ChargeDensity[i]=(LeftValue+2.0*CenterValue+RightValue)/4.0;
				LeftValue=CenterValue;
				CenterValue=RightValue;
				if (i<NumberGridPoints-2)
				{
					RightValue=(*Grid).ChargeDensity[i+2];
				}
			}
			(*Grid).ChargeDensity[NumberGridPoints-1]=(3.0*CenterValue+LeftValue)/4.0;
		}	
	}
}