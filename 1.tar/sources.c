/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function defines the voltage source
 ******************************************************************************/
float_m VoltageSourceLeft()
{
	return VSourceDCLeft+VSourceAmplitudeLeft1*sin(2.0*Pi*VSourceFrequencyLeft1*Time+VSourcePhaseShiftLeft1/100*2.0*Pi)
	                    +VSourceAmplitudeLeft2*sin(2.0*Pi*VSourceFrequencyLeft2*Time+VSourcePhaseShiftLeft2/100*2.0*Pi)
						+VSourceAmplitudeLeft3*sin(2.0*Pi*VSourceFrequencyLeft3*Time+VSourcePhaseShiftLeft3/100*2.0*Pi);
}
float_m VoltageSourceRight()
{
	return VSourceDCRight+VSourceAmplitudeRight1*sin(2.0*Pi*VSourceFrequencyRight1*Time+VSourcePhaseShiftRight1/100*2.0*Pi)
						 +VSourceAmplitudeRight2*sin(2.0*Pi*VSourceFrequencyRight2*Time+VSourcePhaseShiftRight2/100*2.0*Pi);
}
/*******************************************************************************
 * Function defines the current density source
 ******************************************************************************/
float_m CurrentDensitySourceLeft()
{
	return JSourceAmplitudeLeft1*sin(2.0*Pi*JSourceFrequencyLeft1*Time+JSourcePhaseShiftLeft1/100*2.0*Pi);
}