/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * Function writes history report to file
 ******************************************************************************/
void ReportDataConvergence(GRID *Grid, SPECIES *Species)
{
	FILE *FP;
	int_m i=0;
	printf ( "Writing convergence report to file ... \n");
	FP = fopen("ReportDataConvergence.out", "a");
	fprintf (FP,"%e \t", TimeStep * DeltaT);
	fprintf (FP,"%ld \t", (*Species).Electrons.Number);
	fprintf (FP,"%ld \t", (*Species).Ions.Number);
	AveragedElectronDensity = 0.0; 
	AveragedIonDensity = 0.0;
	if (TimeStep == 0)
		{
			AveragedElectronDensity=InitialPlasmaDensity;
			AveragedIonDensity=InitialPlasmaDensity;
		}
	for (i=0; i<NumberGridPoints; i++)
	{
		AveragedElectronDensity += (*Species).Electrons.Density[i];
		AveragedIonDensity += (*Species).Ions.Density[i];			
	}
	AveragedElectronDensity /=NumberGridPoints;
	AveragedIonDensity /= NumberGridPoints;
	fprintf (FP,"%e \t", AveragedElectronDensity);		
	fprintf (FP,"%e \t", AveragedIonDensity);
	fprintf (FP,"%e \t", VSourceLeft);		
	fprintf (FP,"%e \t", VBias);
	fprintf (FP,"%e \t", VElectrodeLeft);	
	fprintf (FP,"%e \t", VElectrodeRight);
	fprintf (FP,"%e \n", Current);
	fclose(FP);	
}

/*******************************************************************************
 * Function writes space time report to file
 ******************************************************************************/
void ReportDataXT(GRID *Grid)
{
	int_m x, t;
	FILE *FP1, *FP2, *FP3, *FP4, *FP5; 
	FILE *FP6, *FP7, *FP8, *FP9, *FP10;
	FILE *FP11, *FP12;	
	printf ( "Writing space time report to file ...\n");
	FP1 = fopen("ReportDataElectronDensityXT.out", "w");
	FP2 = fopen("ReportDataIonDensityXT.out", "w");
	FP3 = fopen("ReportDataReducedElectricField1XT.out", "w");
	FP4 = fopen("ReportDataPotentialXT.out", "w");
	if (EventIonizationFlag == 1) FP5 = fopen("ReportDataEventIonizationXT.out", "w");
	if (FastElectronsFlag == 1) FP6 = fopen("ReportDataFastElectronDensityXT.out", "w");	
	FP7 = fopen("ReportDataT.out", "w");
	FP8 = fopen("ReportDataChargeDensityXT.out", "w");
	if (EventExcitationFlag == 1) FP9 = fopen("ReportDataEventExcitationXT.out", "w");
	FP10 = fopen("ReportDataPowerDensityXT.out", "w");
	FP11 = fopen("ReportDataElectronFluxXT.out", "w");
	FP12 = fopen("ReportDataIonFluxXT.out", "w");	
	
	if (CoordinateSystem == 0)
	{
		for (t = 0; t < (int_m)NumberTimeStepsLastPeriodsResolved; t++)
		{
			for (x = 0; x < NumberGridPoints; x++)
			{
				fprintf ( FP1, "%e \t", ElectronDensityXT[x][t] );
				fprintf ( FP2, "%e \t", IonDensityXT[x][t] );
				fprintf ( FP3, "%e \t", ReducedElectricField1XT[x][t] );
				fprintf ( FP4, "%e \t", PotentialXT[x][t] );
				if (EventIonizationFlag == 1) 
				{
					fprintf ( FP5, "%e \t", EventIonizationXT[x][t] );
				}
				if (FastElectronsFlag == 1) 
				{
					fprintf ( FP6, "%e \t", FastElectronsXT[x][t] );
				}
				fprintf ( FP8, "%e \t", ChargeDensityXT[x][t] );
				if (EventExcitationFlag == 1) 
				{
					fprintf ( FP9, "%e \t", EventExcitationXT[x][t] );
				}
				fprintf ( FP10, "%e \t", PowerDensityXT[x][t] );
				fprintf ( FP11, "%e \t", ElectronFluxXT[x][t] );
				fprintf ( FP12, "%e \t", IonFluxXT[x][t] );				
			}
			fprintf (FP7, "%e \t", t * DeltaT * NTSPCToSNTSPC );
			fprintf (FP7, "%e \t", CurrentT[t] );			
			fprintf (FP7, "%e \t", BiasT[t] );
			fprintf (FP7, "%e \t", VoltageElectrodeLeftT[t] );			
			fprintf (FP7, "%e \t", VoltageElectrodeRightT[t] );			
						
			fprintf (FP1, "\n");
			fprintf (FP2, "\n");
			fprintf (FP3, "\n");
			fprintf (FP4, "\n");
			if (EventIonizationFlag == 1) fprintf (FP5, "\n");
			if (FastElectronsFlag == 1) fprintf (FP6, "\n");
			fprintf (FP7, "\n");
			fprintf (FP8, "\n");
			fprintf (FP9, "\n");
			fprintf (FP10, "\n");						
			fprintf (FP11, "\n");
			fprintf (FP12, "\n");
		}
	}
	else if (CoordinateSystem == 1)
	{
		for (t = 0; t < (int_m)NumberTimeStepsLastPeriodsResolved; t++)
		{
			for (x = 0; x < NumberGridPoints; x++)
			{
				fprintf ( FP1, "%e \t", ElectronDensityXT[x][t] );
				fprintf ( FP2, "%e \t", IonDensityXT[x][t] );
				fprintf ( FP3, "%e \t", ReducedElectricField1XT[x][t] );
				fprintf ( FP4, "%e \t", PotentialXT[x][t] );
				if (EventIonizationFlag == 1) 
				{
					fprintf ( FP5, "%e \t", EventIonizationXT[x][t] );										
				}
				if (FastElectronsFlag == 1) 
				{
					fprintf ( FP6, "%e \t", FastElectronsXT[x][t] );														
				}
				fprintf ( FP8, "%e \t", ChargeDensityXT[x][t] );
				if (EventExcitationFlag == 1) 
				{
					fprintf ( FP9, "%e \t", EventExcitationXT[x][t] );
				}
				fprintf ( FP10, "%e \t", PowerDensityXT[x][t] );
				fprintf ( FP11, "%e \t", ElectronFluxXT[x][t] );
				fprintf ( FP12, "%e \t", IonFluxXT[x][t] );								
			}
			fprintf (FP7, "%e \t", t * DeltaT * NTSPCToSNTSPC );
			fprintf (FP7, "%e \t", CurrentT[t] );			
			fprintf (FP7, "%e \t", BiasT[t] );
			fprintf (FP7, "%e \t", VoltageElectrodeLeftT[t] );			
			fprintf (FP7, "%e \t", VoltageElectrodeRightT[t] );			

			fprintf (FP1, "\n");
			fprintf (FP2, "\n");
			fprintf (FP3, "\n");
			fprintf (FP4, "\n");
			if (EventIonizationFlag == 1) fprintf (FP5, "\n");
			if (FastElectronsFlag == 1) fprintf (FP6, "\n");
			fprintf (FP7, "\n");
			fprintf (FP8, "\n");
			fprintf (FP9, "\n");
			fprintf (FP10, "\n");						
			fprintf (FP11, "\n");
			fprintf (FP12, "\n");			
		}		
	}
	else if (CoordinateSystem == 2)
	{
	}
	fclose(FP1);
	fclose(FP2);
	fclose(FP3);
	fclose(FP4);
	if (EventIonizationFlag == 1) fclose(FP5);
	if (FastElectronsFlag == 1) fclose(FP6);
	fclose(FP7);
	fclose(FP8);
	fclose(FP9);
	fclose(FP10);
	fclose(FP11);	
	fclose(FP12);	
}

/*******************************************************************************
 * Function writes tracked electrons report to file
 ******************************************************************************/
void ReportDataTrackedElectrons(GRID *Grid)
{
	int_m x, t;
	FILE *FP1;
	printf ( "Writing tracked electrons report to file ...\n");
	FP1 = fopen("ReportDataTrackedElectronsXT.out", "w");
	
	if (CoordinateSystem == 0)
	{
		for (t = 0; t < (int_m)NumberTimeStepsLastPeriodsResolved; t++)
		{
			for (x = 0; x < NumberGridPoints; x++)
			{
				fprintf ( FP1, "%e \t", TrackedElectronsXT[x][t] );
			}
			fprintf (FP1, "\n");
		}
	}
	else if (CoordinateSystem == 1)
	{
		for (t = 0; t < (int_m)NumberTimeStepsLastPeriodsResolved; t++)
		{
			for (x = 0; x < NumberGridPoints; x++)
			{
				fprintf ( FP1, "%e \t", TrackedElectronsXT[x][t] );
			}
			fprintf (FP1, "\n");
		}		
	}
	else if (CoordinateSystem == 2)
	{
	}
	fclose(FP1);
}


/*******************************************************************************
 * Function writes grid report to file
 ******************************************************************************/
void ReportDataGrid(GRID *Grid, SPECIES *Species)
{
	int_m i;
	FILE *FP;	
	printf ( "Writing grid report to file ...\n");
	FP = fopen("ReportDataGrid.out", "w");
	for (i = 0; i < NumberGridPoints; i++)
	{
		/* Cartesian grid */
		if (CoordinateSystem == 0)
		{
			fprintf (FP,"%e \t", i * DeltaX);
			fprintf (FP,"%e \t", (*Grid).Potential[i]);
			fprintf (FP,"%e \t", (*Grid).ElectricField1[i]);
			fprintf (FP,"%e \t", (*Grid).CurrentDensity1[i]);
			fprintf (FP,"%e \t", (*Grid).DisplacementCurrent1[i]);			
			fprintf (FP,"%e \t", (*Grid).ChargeDensity[i]);
			fprintf (FP,"%e \t", (*Species).Electrons.Density[i]);
			fprintf (FP,"%e \t", (*Species).Electrons.Flux1[i]);
			fprintf (FP,"%e \t", (*Species).Ions.Density[i]);
			fprintf (FP,"%e \t", (*Species).Ions.Flux1[i]);
			fprintf (FP,"%e \t", (*Grid).MagneticField1[i]);
			fprintf (FP,"%e \t", (*Grid).MagneticField2[i]);
			fprintf (FP,"%e \t", (*Grid).MagneticField3[i]);
			fprintf (FP,"%e \t", (*Grid).ElectricField1[i] / GasDensity * 1e21);
			fprintf (FP,"\n");			
		}
		else if (CoordinateSystem == 1)
		{			
			fprintf (FP,"%e \t", i * DeltaX + InnerElectrodeRadius);
			fprintf (FP,"%e \t", (*Grid).Potential[i]);
			fprintf (FP,"%e \t", (*Grid).ElectricField1[i]);
			fprintf (FP,"%e \t", (*Grid).CurrentDensity1[i]);
			fprintf (FP,"%e \t", (*Grid).DisplacementCurrent1[i]);			
			fprintf (FP,"%e \t", (*Grid).ChargeDensity[i]);
			fprintf (FP,"%e \t", (*Species).Electrons.Density[i]);
			fprintf (FP,"%e \t", (*Species).Electrons.Flux1[i]);
			fprintf (FP,"%e \t", (*Species).Ions.Density[i]);
			fprintf (FP,"%e \t", (*Species).Ions.Flux1[i]);
			fprintf (FP,"%e \t", (*Grid).MagneticField1[i]);
			fprintf (FP,"%e \t", (*Grid).MagneticField2[i]);
			fprintf (FP,"%e \t", (*Grid).MagneticField3[i]);
			fprintf (FP,"%e \t", (*Grid).ElectricField1[i] / GasDensity * 1e21);
			fprintf (FP,"\n");			
		}
		else if (CoordinateSystem == 2)
		{			
		}		
	}
	fclose(FP);
}

/*******************************************************************************
 * Function writes grid averaged report to file
 ******************************************************************************/
void ReportDataGridAve(GRID *Grid, SPECIES *Species)
{
	int_m i;
	FILE *FP;
	printf("Writing averaged grid data to file ... \n");
	FP = fopen("ReportDataGridAve.out", "w");
	for (i = 0; i < NumberGridPoints; i++)
	{
		/* Cartesian grid */
		if (CoordinateSystem == 0)
		{
			fprintf (FP,"%e \t", i * DeltaX);
			fprintf (FP,"%e \t", PotentialAve[i]);
			fprintf (FP,"%e \t", ElectricField1Ave[i]);
			fprintf (FP,"%e \t", CurrentDensity1Ave[i]);
			fprintf (FP,"%e \t", DisplacementCurrent1Ave[i]);
			fprintf (FP,"%e \t", ChargeDensityAve[i]);
			fprintf (FP,"%e \t", ElectronDensityAve[i]);
			fprintf (FP,"%e \t", ElectronFluxAve[i]);			
			fprintf (FP,"%e \t", IonDensityAve[i]);
			fprintf (FP,"%e \t", IonFluxAve[i]);
			fprintf (FP,"%e \t", ReducedElectricField1Ave[i]);
			fprintf (FP,"%e \t", PowerDensityAve[i]);
			fprintf (FP,"\n");			
		}
		else if (CoordinateSystem == 1)
		{
			fprintf (FP,"%e \t", i * DeltaX + InnerElectrodeRadius);
			fprintf (FP,"%e \t", PotentialAve[i]);
			fprintf (FP,"%e \t", ElectricField1Ave[i]);
			fprintf (FP,"%e \t", CurrentDensity1Ave[i]);
			fprintf (FP,"%e \t", DisplacementCurrent1Ave[i]);
			fprintf (FP,"%e \t", ChargeDensityAve[i]);
			fprintf (FP,"%e \t", ElectronDensityAve[i]);
			fprintf (FP,"%e \t", ElectronFluxAve[i]);			
			fprintf (FP,"%e \t", IonDensityAve[i]);
			fprintf (FP,"%e \t", IonFluxAve[i]);
			fprintf (FP,"%e \t", ReducedElectricField1Ave[i]);
			fprintf (FP,"%e \t", PowerDensityAve[i]);
			fprintf (FP,"\n");			
		}
		else if (CoordinateSystem == 2)
		{
		}
	}
	fclose(FP);
}

/*******************************************************************************
 * Function writes EEDF to files
 ******************************************************************************/
void ReportDataEEDF()
{
	int_m e;
	FILE *FP1, *FP2, *FP3;		
	printf ( "Writing EEDF report to file ... \n");
	FP1 = fopen("ReportDataEEDFLeft.out", "w");
	FP2 = fopen("ReportDataEEDFCenter.out", "w");
	FP3 = fopen("ReportDataEEDFRight.out", "w");
	
	
	for ( e = 0; e < MaximumNumberElectronEnergyBins; e++)
	{
		fprintf (FP1, "%e \t %e\n", e*ElectronEnergyBinWidth, EEDFLeft[e]);
		fprintf (FP2, "%e \t %e\n", e*ElectronEnergyBinWidth, EEDFCenter[e]);
		fprintf (FP3, "%e \t %e\n", e*ElectronEnergyBinWidth, EEDFRight[e]);
	}
	
		
	fclose(FP1);
	fclose(FP2);
	fclose(FP3);
}

/*******************************************************************************
 * Function writes IEDF and IADF to files
 ******************************************************************************/
void ReportDataIEDF()
{
	int_m e, a;
	float_m temp1, temp2;
	FILE *FP1, *FP2, *FP3, *FP4;		
	printf ( "Writing IEDF report to file ... \n");
	FP1 = fopen("ReportDataIEDFLeft.out", "w");
	FP2 = fopen("ReportDataIEDFRight.out", "w");
	FP3 = fopen("ReportDataIEDF.out", "w");
	FP4 = fopen("ReportDataIADF.out", "w");	

	for ( e = 0; e < MaximumNumberIonEnergyBins; e++ )
	{
		for ( a = 0; a < MaximumNumberIonAngleBins; a++ )
		{
			fprintf (FP1, "%e\t",IEDFLeft[e][a]);
			fprintf (FP2, "%e\t",IEDFRight[e][a]);
		} 
		fprintf (FP1,"\n");					 
		fprintf (FP2,"\n");
	}
	
	for (e = 0; e < MaximumNumberIonEnergyBins; e++)
	{
		temp1 = 0.0;
		temp2 = 0.0;
		for (a = 0; a < MaximumNumberIonAngleBins; a++)
		{
			temp1 += IEDFLeft[e][a];
			temp2 += IEDFRight[e][a];
		}		
		fprintf (FP3, "%e \t %e \t %e\n", e*IonEnergyBinWidth, temp1, temp2);
	}

	for (a = 0; a < MaximumNumberIonAngleBins; a++)
	{
		temp1 = 0.0;
		temp2 = 0.0;
		for ( e = 0; e < MaximumNumberIonEnergyBins; e++)
		{
			temp1 += IEDFLeft[e][a];
			temp2 += IEDFRight[e][a];
		}
		fprintf (FP4, "%e \t %e \t %e\n", a*IonAngleBinWidth, temp1, temp2);
	}

	fclose(FP1);
	fclose(FP2);
	fclose(FP3);
	fclose(FP4);
}

/*******************************************************************************
 * Write number of collisions to file
 ******************************************************************************/
void ReportNumberCollisions()
{
	FILE *FP;
	printf ( "Writing number of collision report to file ... \n");
	FP = fopen("ReportDataCollisions.out", "a");
	fprintf (FP,"%e \t", TimeStep * DeltaT);
	fprintf (FP,"%ld \t", pel1);
	fprintf (FP,"%ld \t", pel2);
	fprintf (FP,"%ld \t", pel3);
	fprintf (FP,"%ld \t", pel4);
	fprintf (FP,"%ld \t", pion1);				
	fprintf (FP,"%ld \n", pion2);
	fclose(FP);	
}


/*******************************************************************************
 * Function writes cross sections to files
 ******************************************************************************/
void ReportCrossSections(SPECIES *Species)
{
	int_m i;
	FILE *FP1, *FP2;
	float_m Energy;		
	printf ( "Writing cross sections to files ... \n");
	FP1 = fopen("ReportDataElectronCrossSections.out", "w");
	FP2 = fopen("ReportDataIonCrossSections.out", "w");
	
	if (GasFlag == 1)
	{
		for ( i = 0; i < 10000; i++ )
		{
			Energy = 0.1*(float_m)i;
			fprintf (FP1, "%e \t %e \t %e \t %e \n", Energy, 
				 ArgonElectronScatteringSigma(Energy),
				 ArgonElectronIonizationSigma(Energy),
				 ArgonElectronExcitationSigma(Energy));
		}
		for ( i = 0; i < 10000; i++ )
		{
			Energy = (float_m)i;
			fprintf (FP2, "%e \t %e \t %e\n",
				 Energy,ArgonIonScatteringSigma(Energy),
				 ArgonIonChargeExchangeSigma(Energy));
		}	
	}
	else if (GasFlag == 2)
	{
		for ( i = 0; i < 10000; i++ )
		{
			Energy = 0.1*(float_m)i;
			fprintf (FP1, "%e \t %e \t %e \t %e \t %e \n", Energy, 
				 	HeliumElectronScatteringSigma(Energy),
					 HeliumElectronIonizationSigma(Energy),
					 HeliumElectronExcitationSigmaTrip(Energy),
					 HeliumElectronExcitationSigmaSing(Energy));
		}
		for ( i = 0; i < 10000; i++ )
		{
			Energy = (float_m)i;
			fprintf (FP2, "%e \t %e \t %e\n",
					 Energy,HeliumIonScatteringSigma(Energy),
					 HeliumIonChargeExchangeSigma(Energy));
		}
	}
	fclose(FP1);
	fclose(FP2);
}

/*******************************************************************************
 * Calculate sheath data and write sheath report
 ******************************************************************************/
void ReportDataSheath(GRID *Grid)
{
	FILE *FP1;
	int_m x, t, GPB, x1, x2, sLeft, sRight, i, j;
	int_m SmoothingFactor;
	float_m LeftValue, CenterValue, RightValue;
	float_m TempL, TempR;
	float_m I1Left, I2Left;
	float_m I1Right, I2Right;
	float_m ChargeLeft, ChargeRight;
	float_m MaxElectronDensity;
	
	SmoothingFactor = 50;
	TempR=0.0;
	TempL=0.0;
	
	printf ( "Writing sheath report to file ... \n");

	for (t = 0; t < (int_m)NumberTimeStepsLastPeriodsResolved; t++)
	{
		GPB = 0;
		MaxElectronDensity = 0.0;
		
		for (x = 0; x < NumberGridPoints; x++)
		{
			if (ElectronDensityXT[x][t] > MaxElectronDensity)
			{
				MaxElectronDensity = ElectronDensityXT[x][t];
				GPB = x;
			}
		}
				
		I1Left = 0.0;
		I2Left = 0.0;
		I1Right = 0.0;
		I2Right = 0.0;
		ChargeLeft = 0.0;
		ChargeRight = 0.0;
		x1 = 0;	
		x2 = 0;
		
		sLeft = 0;

		do {
			I1Left = 0.0;
			I2Left = 0.0;
			
			for (x1=0; x1<= sLeft; x1++)
			{
				I1Left += DeltaX * ElectronDensityXT[x1][t];
			}
			for (x2 = GPB; x2>=sLeft; x2--)
			{
				I2Left += DeltaX 
				* (IonDensityXT[x2][t] - ElectronDensityXT[x2][t]);
			}
			sLeft ++;
		} while (I1Left <= I2Left);
		sLeft = sLeft - 1;

		SheathVoltageLeft[t] =  PotentialXT[sLeft][t] - PotentialXT[0][t];
		SheathIonFluxLeft[t] = IonFluxXT[sLeft][t];
		
		for (x = 0; x < sLeft; x++)
		{
			ChargeLeft += DeltaX * ChargeDensityXT[x][t];
		}
		SheathChargeLeft[t] = ChargeLeft;
			
		sRight = NumberGridPoints-1;

		do {
			I1Right = 0.0;
			I2Right = 0.0;
			
			for (x1=NumberGridPoints-1; x1>= sRight; x1--)
			{
				I1Right += DeltaX * ElectronDensityXT[x1][t];
			}
			for (x2= GPB; x2<=sRight; x2++)
			{
				I2Right += DeltaX 
				* (IonDensityXT[x2][t] - ElectronDensityXT[x2][t]);
			}
			sRight --;
		} while (I1Right <= I2Right);
		sRight = sRight + 1;

		for (x=NumberGridPoints-1; x >= sRight; x--)
		{
			ChargeRight += DeltaX * ChargeDensityXT[x][t];
		}
		SheathChargeRight[t] = ChargeRight;
		
		if (CoordinateSystem == 0)
		{
			SheathWidthLeft[t] = sLeft*DeltaX;
			SheathWidthRight[t] = sRight*DeltaX;
		}
		else if (CoordinateSystem == 1 || CoordinateSystem == 2)
		{
			SheathWidthLeft[t] = sLeft*DeltaX + InnerElectrodeRadius;
			SheathWidthRight[t] = sRight*DeltaX + InnerElectrodeRadius;
		}

		SheathVoltageRight[t] =  
			PotentialXT[sRight][t] - PotentialXT[(int_m)NumberGridPoints-1][t];
		SheathIonFluxRight[t] = IonFluxXT[sRight][t];
	}

	/* Smoothing sheath width left */
	for (j = 0; j < SmoothingFactor; j++)
	{
		LeftValue = SheathWidthLeft[0];
		CenterValue = SheathWidthLeft[1];
		RightValue = SheathWidthLeft[2];
		TempL = SheathWidthLeft[0];
		TempR = SheathWidthLeft[(int_m)NumberTimeStepsLastPeriodsResolved-1];
		
		SheathWidthLeft[0] 
			= (TempR + 2.0 * LeftValue + CenterValue ) /4.0; 
		for(i = 1; i < (int_m)NumberTimeStepsLastPeriodsResolved; i++)
		{
			SheathWidthLeft[i] 
				= ( LeftValue + 2.0 * CenterValue + RightValue) / 4.0;
			LeftValue = CenterValue;
			CenterValue = RightValue;
			if (i < (int_m)NumberTimeStepsLastPeriodsResolved - 2)
			{
				RightValue = SheathWidthLeft[i+2];
			}
		}  
		SheathWidthLeft[(int_m)NumberTimeStepsLastPeriodsResolved-1] 
			= ( LeftValue + 2.0 * CenterValue + TempL ) / 4.0;
	}

	/* Smoothing sheath width right */
	for (j = 0; j < SmoothingFactor; j++)
	{
		LeftValue = SheathWidthRight[0];
		CenterValue = SheathWidthRight[1];
		RightValue = SheathWidthRight[2];
		TempL = SheathWidthRight[0];
		TempR = SheathWidthRight[(int_m)NumberTimeStepsLastPeriodsResolved-1];
		
		SheathWidthRight[0]	= (TempR + 2.0 * LeftValue + CenterValue ) /4.0; 
		for(i = 1; i < (int_m)NumberTimeStepsLastPeriodsResolved; i++)
		{
			SheathWidthRight[i] 
				= ( LeftValue + 2.0 * CenterValue + RightValue) / 4.0;
			LeftValue = CenterValue;
			CenterValue = RightValue;
			if (i < (int_m)NumberTimeStepsLastPeriodsResolved - 2)
			{
				RightValue = SheathWidthRight[i+2];
			}
		}  
		SheathWidthRight[(int_m)NumberTimeStepsLastPeriodsResolved-1] 
			= ( LeftValue + 2.0 * CenterValue + TempL ) / 4.0;
	}

	/* Smoothing sheath charge left */
	for (j = 0; j < SmoothingFactor; j++)
	{
		LeftValue = SheathChargeLeft[0];
		CenterValue = SheathChargeLeft[1];
		RightValue = SheathChargeLeft[2];
		TempL = SheathChargeLeft[0];
		TempR = SheathChargeLeft[(int_m)NumberTimeStepsLastPeriodsResolved-1];
		
		SheathChargeLeft[0] 
			= ( TempR + 2.0 * LeftValue + CenterValue) /4.0; 
		for(i = 1; i < (int_m)NumberTimeStepsLastPeriodsResolved; i++)
		{
			SheathChargeLeft[i] 
				= ( LeftValue + 2.0 * CenterValue + RightValue) / 4.0;
			LeftValue = CenterValue;
			CenterValue = RightValue;
			if (i < (int_m)NumberTimeStepsLastPeriodsResolved - 2)
			{
				RightValue = SheathChargeLeft[i+2];
			}
		}  
		SheathChargeLeft[(int_m)NumberTimeStepsLastPeriodsResolved-1] 
			= ( LeftValue + 2.0 * CenterValue + TempL ) / 4.0;
	}

	/* Smoothing sheath charge right */
	for (j = 0; j < SmoothingFactor; j++)
	{
		LeftValue = SheathChargeRight[0];
		CenterValue = SheathChargeRight[1];
		RightValue = SheathChargeRight[2];
		TempL = SheathChargeRight[0];
		TempR = SheathChargeRight[(int_m)NumberTimeStepsLastPeriodsResolved-1];
		
		SheathChargeRight[0] 
			= ( TempR + 2.0 * LeftValue + CenterValue)  /4.0; 
		for(i = 1; i < (int_m)NumberTimeStepsLastPeriodsResolved; i++)
		{
			SheathChargeRight[i] 
				= ( LeftValue + 2.0 * CenterValue + RightValue) / 4.0;
			LeftValue = CenterValue;
			CenterValue = RightValue;
			if (i < (int_m)NumberTimeStepsLastPeriodsResolved - 2)
			{
				RightValue = SheathChargeRight[i+2];
			}
		}
		
		SheathChargeRight[(int_m)NumberTimeStepsLastPeriodsResolved-1] 
			= ( LeftValue + 2.0 * CenterValue + TempL ) / 4.0;
	}
	
	/* Smoothing sheath ion flux left */
	for (j = 0; j < SmoothingFactor; j++)
	{
		LeftValue = SheathIonFluxLeft[0];
		CenterValue = SheathIonFluxLeft[1];
		RightValue = SheathIonFluxLeft[2];
		TempL = SheathIonFluxLeft[0];
		TempR = SheathIonFluxLeft[(int_m)NumberTimeStepsLastPeriodsResolved-1];
		
		SheathIonFluxLeft[0] 
		= ( TempR + 2.0 * LeftValue + CenterValue) /4.0; 
		for(i = 1; i < (int_m)NumberTimeStepsLastPeriodsResolved; i++)
		{
			SheathIonFluxLeft[i] 
			= ( LeftValue + 2.0 * CenterValue + RightValue) / 4.0;
			LeftValue = CenterValue;
			CenterValue = RightValue;
			if (i < (int_m)NumberTimeStepsLastPeriodsResolved - 2)
			{
				RightValue = SheathIonFluxLeft[i+2];
			}
		}  
		SheathIonFluxLeft[(int_m)NumberTimeStepsLastPeriodsResolved-1] 
		= ( LeftValue + 2.0 * CenterValue + TempL ) / 4.0;
	}
	
	/* Smoothing sheath ion flux right */
	for (j = 0; j < SmoothingFactor; j++)
	{
		LeftValue = SheathIonFluxRight[0];
		CenterValue = SheathIonFluxRight[1];
		RightValue = SheathIonFluxRight[2];
		TempL = SheathIonFluxRight[0];
		TempR = SheathIonFluxRight[(int_m)NumberTimeStepsLastPeriodsResolved-1];
		
		SheathIonFluxRight[0] 
		= ( TempR + 2.0 * LeftValue + CenterValue)  /4.0; 
		for(i = 1; i < (int_m)NumberTimeStepsLastPeriodsResolved; i++)
		{
			SheathIonFluxRight[i] 
			= ( LeftValue + 2.0 * CenterValue + RightValue) / 4.0;
			LeftValue = CenterValue;
			CenterValue = RightValue;
			if (i < (int_m)NumberTimeStepsLastPeriodsResolved - 2)
			{
				RightValue = SheathIonFluxRight[i+2];
			}
		}
		SheathIonFluxRight[(int_m)NumberTimeStepsLastPeriodsResolved-1] 
		= ( LeftValue + 2.0 * CenterValue + TempL ) / 4.0;
	}
	
	
	
	
	
	
	FP1 = fopen("ReportDataSheath.out", "w");			
	for (t = 0; t < (int_m)NumberTimeStepsLastPeriodsResolved; t++)
	{
		fprintf (FP1,"%e \t", t * DeltaT  * NTSPCToSNTSPC);
		fprintf (FP1,"%e \t", SheathWidthLeft[t]);
		fprintf (FP1,"%e \t", SheathWidthRight[t]);
		fprintf (FP1,"%e \t", SheathVoltageLeft[t]);
		fprintf (FP1,"%e \t", SheathVoltageRight[t]);
		fprintf (FP1,"%e \t", SheathChargeLeft[t]);
		fprintf (FP1,"%e \t", SheathChargeRight[t]);
		fprintf (FP1,"%e \t", SheathIonFluxLeft[t]);		
		fprintf (FP1,"%e \n", SheathIonFluxRight[t]);
	}
	fclose(FP1);
}

/*******************************************************************************
 * Function writes Fourier spectra to files
 ******************************************************************************/
void ReportFourierSpectra()
{
	int_m n, t, Steps;
	float_m An, Bn;
	float_m Frequency;
	float_m CurrentAmplitude, CurrentAmplitudeNorm;
	float_m TwoPi;
	FILE *FP1;
	printf ( "Writing Fourier spectra to file ... \n");
	FP1 = fopen("ReportDataFourierSpectra.out", "w");
 
	CurrentAmplitudeNorm = 0.0;
	TwoPi = 2.0*Pi;
	Steps = StoredNumberTimeStepsPerCycle;
	
	if (CurrentSourceFlag == 0)
	{
		Frequency = VSourceFrequencyLeft1;
	}
	else if (CurrentSourceFlag == 1)
	{			
		Frequency = JSourceFrequencyLeft1;
	}
	
	for ( n = 0; n <= NumberHarmonics; n++ )
	{
		An = 0.0;
		Bn = 0.0;

		for (t=0; t < Steps; t++)
		{

			if (t != Steps-1)
			{
				An += 0.5 * StoredDeltaT*(CurrentT[t] * cos(TwoPi * n * Frequency * t * StoredDeltaT)
					+ CurrentT[t+1] * cos(TwoPi * n * Frequency * (t+1) * StoredDeltaT));
				Bn += 0.5 * StoredDeltaT*(CurrentT[t] * sin(TwoPi * n * Frequency * t * StoredDeltaT)
					+ CurrentT[t+1] * sin(TwoPi * n * Frequency * (t+1) * StoredDeltaT));
			}
			else
			{
				An += 0.5 * StoredDeltaT*(CurrentT[t] * cos(TwoPi * n * Frequency * t * StoredDeltaT)
					+ CurrentT[0] * cos(TwoPi * n * Frequency * (0.0) * StoredDeltaT));
				Bn += 0.5 * StoredDeltaT*(CurrentT[t] * sin(TwoPi * n * Frequency * t * StoredDeltaT)
					+ CurrentT[0] * sin(TwoPi * n * Frequency * (0.0) * StoredDeltaT));
			}


		}

		An *= 2.0/PeriodLength;
		Bn *= 2.0/PeriodLength;
			
		if (n==0)
		{
			An *= 0.5;
		}
		
		CurrentAmplitude = sqrt(An*An+Bn*Bn);

		if (n==1) CurrentAmplitudeNorm = CurrentAmplitude; 

		fprintf (FP1, "%ld\t %e\t %e\t %e\t %e\t %e\n", n, 
			n*VSourceFrequencyLeft1, CurrentAmplitude, 
				CurrentAmplitude/CurrentAmplitudeNorm, An, Bn);
	}	
	fclose(FP1);
}

