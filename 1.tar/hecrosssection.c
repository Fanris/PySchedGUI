/*******************************************************************************
 * y a p i c 
 * Version 3.0
 * Copyright (C) 2010, 2011, 2012
 * Thomas Mussenbrock
 * Ruhr University Bochum
 * http://homepages.rub.de/thomas.mussenbrock
 ******************************************************************************/
#include "yapic.h"

/*******************************************************************************
 * A bunch of collision cross sections for helium
 ******************************************************************************/

float_m HeliumElectronScatteringSigma(float_m energy)
{
	int_m i=0;
	float_m crossx;
	
	if (TabXSectFlag==1)
	{
		if (energy<=EnergyElEla[0])
			return XSectElEla[0];
		else if (energy > MaximumElEnergyXSect)
			return XSectElEla[NumberXSectDataA-1];
		else
		{		
			while (energy >= EnergyElEla[i]) i++;
			crossx=XSectElEla[i-1]+(XSectElEla[i]-XSectElEla[i-1]) 
				/(EnergyElEla[i]-EnergyElEla[i-1]) 
				*(energy-EnergyElEla[i-1]); 
			return crossx;
		}
	}
	else
		return (8.5e-19/(pow(energy+10.0,1.1)));
}

float_m HeliumElectronIonizationSigma(float_m energy)
{
	int_m i=0;
	float_m crossx;
		
	if (TabXSectFlag==1)
	{
		if (energy <= EnergyElIon[0]) return 0.0;
		else if (energy>MaximumElEnergyXSect)
			return XSectElIon[NumberXSectDataB-1];
		else
		{
			while (energy >= EnergyElIon[i]) i++;
			crossx=XSectElIon[i-1]+(XSectElIon[i]-XSectElIon[i-1]) 
				/(EnergyElIon[i]-EnergyElIon[i-1]) 
				*(energy-EnergyElIon[i-1]); 
			return crossx;
		}
	}
	else
	{
		if(energy<HeliumIonizationEnergy)
			return 0.0;
		else
			return (1e-17*(energy-HeliumIonizationEnergy)/((energy +50)*pow(energy+300.0,1.2)));
	}
}

float_m HeliumElectronExcitationSigmaTrip(float_m energy)
{
	int_m i=0;
	float_m crossx;

	if (TabXSectFlag==1)
	{
		if (energy<=EnergyElExcTrip[0]) return 0.0;
		else if (energy>MaximumElEnergyXSect)
			return XSectElExcTrip[NumberXSectDataC-1];
		else
		{
			while (energy >= EnergyElExcTrip[i]) i++;
			crossx=XSectElExcTrip[i-1] 
				+(XSectElExcTrip[i]-XSectElExcTrip[i-1]) 
				/(EnergyElExcTrip[i]-EnergyElExcTrip[i-1]) 
				*(energy-EnergyElExcTrip[i-1]); 
			return crossx;
		}
	}
	else
	{
		if(energy<=HeliumExcitationEnergyTrip)
			return 0.0;
		else if (HeliumExcitationEnergyTrip<=energy&&energy<27.0)
			return (2.08e-22*(energy-HeliumExcitationEnergyTrip));
		else
			return (3.4e-19/(energy +200));	
	}	
}

float_m HeliumElectronExcitationSigmaSing(float_m energy)
{
	int_m i=0;
	float_m crossx;	

	if (TabXSectFlag==1)
	{
		if (energy<=EnergyElExcSing[0])
			return 0.0;
		else if (energy>MaximumElEnergyXSect)
			return XSectElExcSing[NumberXSectDataD-1];
		else
		{
			while (energy>=EnergyElExcSing[i]) i++;
			crossx=XSectElExcSing[i-1] 
				+(XSectElExcSing[i]-XSectElExcSing[i-1]) 
				/(EnergyElExcSing[i]-EnergyElExcSing[i-1]) 
				*(energy-EnergyElExcSing[i-1]); 
			return crossx;
		}
	}
	else
		return 0.0;
}

float_m HeliumIonScatteringSigma(float_m energy)
{
	int_m i=0;
	float_m emin=1.0;
	float_m crossx;	
	
	if (TabXSectFlag==1)
	{
		if (energy<=EnergyIonEla[0])
			return XSectIonEla[0];
		else if (energy>MaximumIonEnergyXSect)
			return XSectIonEla[NumberXSectDataE-1];
		else
		{
			while (energy>=EnergyIonEla[i]) i++;
			crossx=XSectIonEla[i-1]+(XSectIonEla[i]-XSectIonEla[i-1]) 
				/(EnergyIonEla[i]-EnergyIonEla[i-1]) 
				*(energy-EnergyIonEla[i-1]); 
			return crossx;
		}
 }
	else
	{
		if(energy<emin)
			energy=emin;
		crossx=3.6463e-19/sqrt(energy)-7.9897e-21;
		if(crossx<0)
			return 0.0;
		else	
			return crossx;
	}
}

float_m HeliumIonChargeExchangeSigma(float_m energy)
{
	int_m i=0;
	float_m emin=1.0;
	float_m cutoff=377.8;
	float_m crossx;	
	
	if (TabXSectFlag == 1)
	{
		if (energy<=EnergyIonCex[0])
			return XSectIonCex[0];
		else if (energy>MaximumIonEnergyXSect)
			return XSectIonCex[NumberXSectDataF-1];
		else
		{
			while (energy>=EnergyIonCex[i]) i++;
			crossx=XSectIonCex[i-1]+(XSectIonCex[i]-XSectIonCex[i-1]) 
				/(EnergyIonCex[i]-EnergyIonCex[i-1]) 
				*(energy-EnergyIonCex[i-1]); 
			return crossx;
		}
	}
	else
	{
		if(energy<emin)
			energy=emin;
		if(energy<cutoff)
			crossx=1.2996e-19-7.8872e-23*energy+1.9873e-19/sqrt(energy);
		else
			crossx=(1.5554e-18*log(energy)/energy)+8.6407e-20;
		return crossx;	
	}
}

/*******************************************************************************
 * Read Cross section data from files
 ******************************************************************************/
void ReadXSections()
{
	int_m i;
	FILE *XSectData;	

	printf("Load cross section data from files ... \n");	
			
	XSectData=fopen("HeXSectBiagi71ElEla.tab","r");
	if (XSectData==NULL) printf("Error opening file ... \n");
	else
	{
		for (i=0;i<NumberXSectDataA;i++)
		{
			fscanf(XSectData,"%lf %lf",&EnergyElEla[i],&XSectElEla[i]);
		}
	}
	fclose(XSectData);

	XSectData=fopen("HeXSectBiagi71ElIon.tab","r");
	if (XSectData==NULL) printf("Error opening file ... \n");
	else
	{
		for (i=0;i<NumberXSectDataB;i++)
		{
			fscanf(XSectData,"%lf %lf",&EnergyElIon[i],&XSectElIon[i]);
		}
	}
	fclose(XSectData);

	XSectData=fopen("HeXSectBiagi71ElExcTrip.tab","r");
	if (XSectData==NULL) printf("Error opening file ... \n");
	else
	{
		for (i=0;i<NumberXSectDataC;i++)
		{
			fscanf(XSectData,"%lf %lf",&EnergyElExcTrip[i],&XSectElExcTrip[i]);
		}
	}
	fclose(XSectData);

	XSectData=fopen("HeXSectBiagi71ElExcSing.tab","r");
	if (XSectData==NULL) printf("Error opening file ... \n");
	else
	{
		for (i=0;i<NumberXSectDataD;i++)
		{
			fscanf(XSectData,"%lf %lf",&EnergyElExcSing[i],&XSectElExcSing[i]);
		}
	}
	fclose(XSectData);

	XSectData=fopen("HeXSectTurnerIonEla.tab","r");
	if (XSectData==NULL) printf("Error opening file ... \n");
	else
	{
		for (i=0;i<NumberXSectDataE;i++)
		{
			fscanf(XSectData,"%lf %lf",&EnergyIonEla[i],&XSectIonEla[i]);
		}
	}
	fclose(XSectData);

	XSectData=fopen("HeXSectTurnerIonCex.tab","r");
	if (XSectData==NULL) printf("Error opening file ... \n");
	else
	{
		for (i=0;i<NumberXSectDataF;i++)
		{
			fscanf(XSectData,"%lf %lf",&EnergyIonCex[i],&XSectIonCex[i]);
		}
	}
	fclose(XSectData);
}